package com.example.projcam;

import android.content.Intent;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** 项目内文档编辑：支持文字 + 照片（类似简易 Word） */
public class DocActivity extends Activity {

    private File projectDir;
    private Docs.Doc doc;
    private WebView web;
    private TextView editableName;
    private boolean saving;
    private final Handler ui = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Night.init(this);
        String dir = getIntent().getStringExtra("dir");
        String docId = getIntent().getStringExtra("docId");
        if (dir == null || docId == null) {
            finish();
            return;
        }
        projectDir = new File(dir);
        for (Docs.Doc d : Docs.list(projectDir)) {
            if (d.id.equals(docId)) doc = d;
        }
        if (doc == null) {
            finish();
            return;
        }
        applyImmersive();
        build();
        loadPage();
    }

    private void applyImmersive() {
        Window w = getWindow();
        w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        w.setStatusBarColor(0x00000000);
        int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | (Night.dark ? 0 : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        w.getDecorView().setSystemUiVisibility(flags);
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private int statusBarHeight() {
        int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
        return id > 0 ? getResources().getDimensionPixelSize(id) : dp(24);
    }

    private TextView chip(String text, int size) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(size);
        t.setTextColor(Night.sub);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(10), dp(8), dp(10), dp(8));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Night.soft);
        bg.setCornerRadius(dp(10));
        t.setBackground(bg);
        return t;
    }

    private void build() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Night.page);
        root.setPadding(dp(12), statusBarHeight() + dp(8), dp(12), 0);

        // 顶栏
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);

        TextView back = new TextView(this);
        back.setText("‹");
        back.setTextSize(26);
        back.setTextColor(Night.accent);
        back.setGravity(Gravity.CENTER);
        back.setLayoutParams(new LinearLayout.LayoutParams(dp(34), dp(38)));
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveThenFinish();
            }
        });
        bar.addView(back);

        editableName = new TextView(this);
        editableName.setText(doc.name);
        editableName.setTextSize(16);
        editableName.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        editableName.setTextColor(Night.main);
        editableName.setSingleLine(true);
        editableName.setEllipsize(android.text.TextUtils.TruncateAt.END);
        editableName.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        editableName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                askRename();
            }
        });
        bar.addView(editableName);

        // 顶栏右侧：插入照片 + 保存
        TextView photoTop = new TextView(this);
        photoTop.setText("＋ 照片");
        photoTop.setTextSize(12);
        photoTop.setTextColor(0xFFFFFFFF);
        photoTop.setGravity(Gravity.CENTER);
        photoTop.setPadding(dp(12), dp(8), dp(12), dp(8));
        GradientDrawable pbg = new GradientDrawable();
        pbg.setColor(Night.accent);
        pbg.setCornerRadius(dp(16));
        photoTop.setBackground(pbg);
        photoTop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pickPhoto();
            }
        });
        bar.addView(photoTop);

        TextView save = new TextView(this);
        save.setText("保存");
        save.setTextSize(12);
        save.setTextColor(Night.accent);
        save.setGravity(Gravity.CENTER);
        save.setPadding(dp(12), dp(8), dp(12), dp(8));
        GradientDrawable sbg = new GradientDrawable();
        sbg.setColor(Night.soft);
        sbg.setCornerRadius(dp(16));
        save.setBackground(sbg);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        slp.leftMargin = dp(8);
        save.setLayoutParams(slp);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveThenFinish(true);
            }
        });
        bar.addView(save);
        root.addView(bar);

        // 排版工具条：一张圆角卡片，横向滑动；按「文字样式 / 列表 / 结构」分组
        LinearLayout toolCard = new LinearLayout(this);
        toolCard.setOrientation(LinearLayout.HORIZONTAL);
        toolCard.setGravity(Gravity.CENTER_VERTICAL);
        GradientDrawable tcbg = new GradientDrawable();
        tcbg.setColor(Night.dark ? 0xFF202733 : 0xFFFFFFFF);
        tcbg.setCornerRadius(dp(14));
        tcbg.setStroke(dp(1), Night.hair);
        toolCard.setBackground(tcbg);
        toolCard.setPadding(dp(6), dp(4), dp(6), dp(4));
        LinearLayout.LayoutParams tclp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tclp.topMargin = dp(8);
        tclp.bottomMargin = dp(6);
        toolCard.setLayoutParams(tclp);

        android.widget.HorizontalScrollView tb = new android.widget.HorizontalScrollView(this);
        tb.setHorizontalScrollBarEnabled(false);
        tb.setFillViewport(true);
        LinearLayout.LayoutParams tblp = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        tb.setLayoutParams(tblp);

        LinearLayout tools = new LinearLayout(this);
        tools.setOrientation(LinearLayout.HORIZONTAL);
        tools.setGravity(Gravity.CENTER_VERTICAL);

        addTool(tools, "¶", "正文：恢复正常段落", "formatBlock", "<div>");
        addTool(tools, "H1", "标题：设为一级标题", "formatBlock", "<h2>");
        addTool(tools, "H2", "小标题：设为二级标题", "formatBlock", "<h3>");
        addGap(tools);
        addTool(tools, "B", "加粗：把选中文字加粗", "bold", null);
        addTool(tools, "I", "斜体：把选中文字变斜体", "italic", null);
        addGap(tools);
        addTool(tools, "☰", "圆点列表：变成项目符号列表", "insertUnorderedList", null);
        addTool(tools, "①", "编号列表：变成 1.2.3. 列表", "insertOrderedList", null);
        addGap(tools);
        addTool(tools, "▬", "分隔线：插入一条横线", "inserthorizontalrule", null);

        tb.addView(tools);
        toolCard.addView(tb);
        root.addView(toolCard);

        // 编辑区
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSupportZoom(false);
        web.setBackgroundColor(Night.dark ? 0xFF1A2028 : 0xFFFFFFFF);
        LinearLayout.LayoutParams wlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        wlp.topMargin = dp(2);
        root.addView(web, wlp);

        setContentView(root);
    }

    private void addGap(LinearLayout parent) {
        View v = new View(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(1), dp(18));
        lp.leftMargin = dp(6);
        lp.rightMargin = dp(6);
        v.setLayoutParams(lp);
        v.setBackgroundColor(Night.hair);
        parent.addView(v);
    }

    private void addTool(LinearLayout parent, final String icon, final String hint,
                         final String cmd, final String arg) {
        TextView t = new TextView(this);
        t.setText(icon);
        t.setTextSize(icon.length() == 1 && "BI¶".contains(icon) ? 17 : 13);
        if ("BI".contains(icon)) t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        t.setTextColor(Night.main);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, 0, 0, 0);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Night.soft);
        bg.setCornerRadius(dp(10));
        t.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(40), dp(38));
        lp.rightMargin = dp(6);
        t.setLayoutParams(lp);
        t.setContentDescription(hint);

        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String js = arg == null
                        ? "document.execCommand('" + cmd + "',false,null);"
                        : "document.execCommand('" + cmd + "',false,'" + arg + "');";
                web.evaluateJavascript("document.getElementById('editor').focus();" + js, null);
            }
        });
        t.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Toast.makeText(DocActivity.this, hint, Toast.LENGTH_SHORT).show();
                return true;
            }
        });
        parent.addView(t);
    }

    private String pageHtml() {
        String ink = Night.dark ? "#E8ECF3" : "#1B2230";
        String bg = Night.dark ? "#1A2028" : "#FFFFFF";
        String body = Docs.read(doc.file);
        return "<!DOCTYPE html><html><head><meta name=\"viewport\" "
                + "content=\"width=device-width,initial-scale=1\">"
                + "<style>body{margin:0;padding:14px 16px 60vh;background:" + bg + ";color:" + ink
                + ";font-family:-apple-system,'Noto Sans CJK SC',sans-serif;font-size:16px;"
                + "line-height:1.7;-webkit-user-select:text;}"
                + "#editor{outline:none;min-height:60vh;}"
                + "#editor img{max-width:100%;border-radius:10px;margin:10px 0;display:block;}"
                + "h2{font-size:20px;margin:18px 0 8px;}h3{font-size:17px;margin:14px 0 6px;}"
                + "hr{border:none;border-top:1px solid " + (Night.dark ? "#2E3A47" : "#E3E8F2")
                + ";margin:2px 0;}"
                + "ul,ol{padding-left:22px;}"
                + "</style></head><body>"
                + "<div id=\"editor\" contenteditable=\"true\" spellcheck=\"false\">"
                + body
                + "</div>"
                + "<script>function insertImg(src){var e=document.getElementById('editor');"
                + "e.focus();var img='<div><img src=\"'+src+'\" style=\"max-width:100%\"></div>"
                + "<div><br></div>';document.execCommand('insertHTML',false,img);}"
                + "</script></body></html>";
    }

    private void loadPage() {
        web.loadDataWithBaseURL(null, pageHtml(), "text/html", "UTF-8", null);
    }

    @Override
    public void onBackPressed() {
        saveThenFinish();
    }

    @Override
    protected void onResume() {
        super.onResume();
        Life.onResume();
        // 如果是从后台真正回到 App，先退回主页做指纹验证
        if (Life.pending && MainActivity.lockOn(this)) {
            Life.pending = false;
            MainActivity.resetLock();
            Intent mi = new Intent(this, MainActivity.class);
            mi.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(mi);
            finish();
            return;
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        Life.onPause();
        saveSilently(false);
    }

    private void saveThenFinish() {
        saveThenFinish(false);
    }

    private void saveThenFinish(final boolean toast) {
        web.evaluateJavascript("(function(){var e=document.getElementById('editor');"
                + "return e?e.innerHTML:'';})()", new android.webkit.ValueCallback<String>() {
            @Override
            public void onReceiveValue(String value) {
                persist(value);
                if (toast) Toast.makeText(DocActivity.this, "已保存", Toast.LENGTH_SHORT).show();
                ui.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        finish();
                    }
                }, 60);
            }
        });
    }

    private void saveSilently(final boolean toast) {
        if (web == null) return;
        web.evaluateJavascript("(function(){var e=document.getElementById('editor');"
                + "return e?e.innerHTML:'';})()", new android.webkit.ValueCallback<String>() {
            @Override
            public void onReceiveValue(String value) {
                persist(value);
                if (toast) Toast.makeText(DocActivity.this, "已保存", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void persist(String jsonValue) {
        if (saving) return;
        String body = jsonValue;
        if (body == null) body = "";
        if (body.startsWith("\"") && body.endsWith("\"")) {
            try {
                body = new org.json.JSONArray("[" + body + "]").getString(0);
            } catch (Exception e) {
                body = body.substring(1, body.length() - 1);
            }
        }
        Docs.write(doc.file, body);
        Docs.touch(projectDir, doc);
    }

    private void askRename() {
        final EditText input = new EditText(this);
        input.setText(doc.name);
        input.setSelection(input.getText().length());
        input.setTextColor(Night.main);
        input.setHintTextColor(Night.faint);
        input.setSingleLine(true);
        new AlertDialog.Builder(this)
                .setTitle("文档名称")
                .setView(input)
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String n = input.getText().toString().trim();
                        if (n.length() == 0) return;
                        doc.name = n;
                        Docs.rename(projectDir, doc, n);
                        editableName.setText(n);
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private List<File> projectPhotos() {
        List<File> out = new ArrayList<>();
        File[] fs = projectDir.listFiles();
        if (fs == null) return out;
        for (File f : fs) {
            if (f.isFile() && f.getName().endsWith(".jpg")) out.add(f);
        }
        java.util.Collections.sort(out, new java.util.Comparator<File>() {
            @Override
            public int compare(File a, File b) {
                return Long.compare(b.lastModified(), a.lastModified());
            }
        });
        return out;
    }

    /** 缩略图网格选图，点哪张插哪张 */
    private void pickPhoto() {
        final List<File> photos = projectPhotos();
        if (photos.isEmpty()) {
            Toast.makeText(this, "这个项目还没有照片", Toast.LENGTH_SHORT).show();
            return;
        }

        int cols = 3;
        GridView grid = new GridView(this);
        grid.setNumColumns(cols);
        grid.setHorizontalSpacing(dp(4));
        grid.setVerticalSpacing(dp(4));
        grid.setPadding(dp(10), dp(6), dp(10), dp(6));
        grid.setAdapter(new PhotoPickAdapter(photos, cols));

        new AlertDialog.Builder(this)
                .setTitle("选择要插入的照片")
                .setView(grid)
                .setNegativeButton("取消", null)
                .show();
    }

    private class PhotoPickAdapter extends android.widget.BaseAdapter {
        final List<File> items;
        final int cols;

        PhotoPickAdapter(List<File> items, int cols) {
            this.items = items;
            this.cols = cols;
        }

        @Override
        public int getCount() {
            return items.size();
        }

        @Override
        public Object getItem(int position) {
            return items.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            final File f = items.get(position);
            android.widget.FrameLayout cell = new android.widget.FrameLayout(DocActivity.this);
            int size = (getResources().getDisplayMetrics().widthPixels
                    - dp(10 + 10 + 4 * (cols - 1))) / cols;
            cell.setLayoutParams(new GridView.LayoutParams(size, size));

            ImageView iv = new ImageView(DocActivity.this);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setLayoutParams(new android.widget.FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            iv.setImageBitmap(decodeThumb(f, size));
            cell.addView(iv);

            if (convertView != null) {
                // 简单复用：不复用图，直接重建（数量通常不多）
            }
            cell.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    insertPhoto(f);
                }
            });
            return cell;
        }
    }

    private Bitmap decodeThumb(File f, int size) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(f.getAbsolutePath(), o);
            int scale = 1;
            while (o.outWidth / scale > size || o.outHeight / scale > size) scale *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = scale;
            return BitmapFactory.decodeFile(f.getAbsolutePath(), o2);
        } catch (Throwable t) {
            return null;
        }
    }

    private void insertPhoto(final File file) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    BitmapFactory.Options o = new BitmapFactory.Options();
                    o.inJustDecodeBounds = true;
                    BitmapFactory.decodeFile(file.getAbsolutePath(), o);
                    int scale = 1;
                    while (o.outWidth / scale > 1280) scale *= 2;

                    BitmapFactory.Options o2 = new BitmapFactory.Options();
                    o2.inSampleSize = scale;
                    Bitmap bmp = BitmapFactory.decodeFile(file.getAbsolutePath(), o2);
                    if (bmp == null) return;
                    if (bmp.getWidth() > 1280) {
                        bmp = Bitmap.createScaledBitmap(bmp, 1280,
                                bmp.getHeight() * 1280 / bmp.getWidth(), true);
                    }
                    ByteArrayOutputStream bo = new ByteArrayOutputStream();
                    bmp.compress(Bitmap.CompressFormat.JPEG, 75, bo);
                    bmp.recycle();
                    final String b64 = Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP);
                    bo.close();

                    ui.post(new Runnable() {
                        @Override
                        public void run() {
                            if (web != null) web.evaluateJavascript(
                                    "insertImg('data:image/jpeg;base64," + b64 + "')", null);
                        }
                    });
                } catch (Exception ignored) {
                }
            }
        }).start();
    }
}
