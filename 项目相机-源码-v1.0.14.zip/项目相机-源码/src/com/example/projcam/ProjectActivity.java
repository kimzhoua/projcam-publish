package com.example.projcam;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** 项目内页：照片网格 + 拍照入口 */
public class ProjectActivity extends Activity {

    private File dir;
    private GridView grid;
    private TextView countText;
    private final List<File> photos = new ArrayList<>();
    private ThumbAdapter adapter;
    private File pendingShot;
    private android.net.Uri pendingUri;
    private static final int REQ_SYS_CAMERA = 4101;

    // 多选
    private boolean selecting;
    private final java.util.Set<File> selected = new java.util.HashSet<>();
    private TextView selAll, selDelete, selCancel, actExport, actSelect, shootBtn;
    private LinearLayout selectBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Night.init(this);
        String path = getIntent().getStringExtra("dir");
        if (path == null) {
            finish();
            return;
        }
        dir = new File(path);
        applyImmersive();
        build();
        reload();
    }

    private void applyImmersive() {
        Window w = getWindow();
        w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        w.setStatusBarColor(0x00000000);
        int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | (Night.dark ? 0 : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        w.getDecorView().setSystemUiVisibility(flags);
    }

    @Override
    protected void onResume() {
        super.onResume();
        reload();
    }

    private int dp(int v) {
        return (int) android.util.TypedValue.applyDimension(
                android.util.TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private int statusBarHeight() {
        int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
        return id > 0 ? getResources().getDimensionPixelSize(id) : dp(24);
    }

    private GradientDrawable rounded(int color, float radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp((int) radiusDp));
        return d;
    }

    private void build() {
        FrameLayout outer = new FrameLayout(this);
        outer.setBackgroundColor(Night.page);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), statusBarHeight() + dp(10), dp(16), 0);

        // 顶栏
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);

        TextView back = new TextView(this);
        back.setText("‹");
        back.setTextSize(26);
        back.setTextColor(Night.accent);
        back.setGravity(Gravity.CENTER);
        back.setLayoutParams(new LinearLayout.LayoutParams(dp(34), dp(38)));
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        bar.addView(back);

        TextView title = new TextView(this);
        title.setText(Store.nameOf(dir));
        title.setTextSize(18);
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        title.setTextColor(Night.main);
        title.setSingleLine(true);
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        title.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        bar.addView(title);

        countText = new TextView(this);
        countText.setTextSize(11);
        countText.setTextColor(Night.faint);
        countText.setPadding(0, 0, dp(8), 0);
        bar.addView(countText);

        actExport = new TextView(this);
        actExport.setText("导出");
        actExport.setTextSize(12);
        actExport.setTextColor(Night.accent);
        actExport.setPadding(dp(8), dp(6), dp(8), dp(6));
        actExport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                askExport();
            }
        });
        bar.addView(actExport);

        actSelect = new TextView(this);
        actSelect.setText("选择");
        actSelect.setTextSize(12);
        actSelect.setTextColor(Night.accent);
        actSelect.setPadding(dp(8), dp(6), dp(4), dp(6));
        actSelect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setSelecting(true);
            }
        });
        bar.addView(actSelect);
        root.addView(bar);

        // 多选工具条（默认隐藏）
        selectBar = new LinearLayout(this);
        selectBar.setOrientation(LinearLayout.HORIZONTAL);
        selectBar.setGravity(Gravity.CENTER_VERTICAL);
        selectBar.setVisibility(View.GONE);
        LinearLayout.LayoutParams sbLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(40));
        selectBar.setLayoutParams(sbLp);

        selAll = new TextView(this);
        selAll.setText("全选");
        selAll.setTextSize(13);
        selAll.setTextColor(Night.accent);
        selAll.setPadding(dp(4), dp(8), dp(16), dp(8));
        selAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selected.size() == photos.size()) selected.clear();
                else selected.addAll(photos);
                updateSelectBar();
                adapter.notifyDataSetChanged();
            }
        });
        selectBar.addView(selAll);

        TextView spacer = new TextView(this);
        spacer.setLayoutParams(new LinearLayout.LayoutParams(0, 1, 1f));
        selectBar.addView(spacer);

        selDelete = new TextView(this);
        selDelete.setTextSize(13);
        selDelete.setTextColor(Night.danger);
        selDelete.setPadding(dp(12), dp(8), dp(12), dp(8));
        selDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                askDeleteSelected();
            }
        });
        selectBar.addView(selDelete);

        selCancel = new TextView(this);
        selCancel.setText("取消");
        selCancel.setTextSize(13);
        selCancel.setTextColor(Night.sub);
        selCancel.setPadding(dp(12), dp(8), dp(4), dp(8));
        selCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setSelecting(false);
            }
        });
        selectBar.addView(selCancel);
        root.addView(selectBar);

        // 照片网格
        grid = new GridView(this);
        grid.setNumColumns(3);
        int gap = dp(4);
        grid.setHorizontalSpacing(gap);
        grid.setVerticalSpacing(gap);
        grid.setPadding(0, dp(8), 0, dp(96));
        grid.setClipToPadding(false);
        adapter = new ThumbAdapter();
        grid.setAdapter(adapter);
        // 滑动多选：多选模式下按住并拖动，手指划过的整段都会被选中/取消
        grid.setOnTouchListener(new View.OnTouchListener() {
            private int anchor = -1;
            private boolean addMode = true;
            private int lastPos = -1;

            @Override
            public boolean onTouch(View v, android.view.MotionEvent e) {
                if (!selecting) return false;
                int pos = grid.pointToPosition((int) e.getX(), (int) e.getY());
                switch (e.getActionMasked()) {
                    case android.view.MotionEvent.ACTION_DOWN:
                        anchor = pos;
                        lastPos = pos;
                        if (pos >= 0 && pos < photos.size()) {
                            addMode = !selected.contains(photos.get(pos));
                            applyTo(pos, addMode);
                        }
                        return true;
                    case android.view.MotionEvent.ACTION_MOVE:
                        if (pos >= 0 && pos != lastPos && anchor >= 0) {
                            lastPos = pos;
                            int from = Math.min(anchor, pos);
                            int to = Math.max(anchor, pos);
                            for (int i = from; i <= to && i < photos.size(); i++) {
                                applyTo(i, addMode);
                            }
                        }
                        return true;
                    case android.view.MotionEvent.ACTION_UP:
                    case android.view.MotionEvent.ACTION_CANCEL:
                        anchor = -1;
                        lastPos = -1;
                        return true;
                }
                return false;
            }

            private void applyTo(int index, boolean add) {
                if (index < 0 || index >= photos.size()) return;
                File f = photos.get(index);
                if (add) {
                    if (!selected.contains(f)) selected.add(f);
                    else return; // 状态没变就不刷新，减少重绘
                } else {
                    if (!selected.remove(f)) return;
                }
                updateSelectBar();
                adapter.refreshCell(index);
            }
        });

        grid.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(android.widget.AdapterView<?> parent, View view, int position, long id) {
                File f = photos.get(position);
                if (selecting) {
                    if (selected.contains(f)) selected.remove(f);
                    else selected.add(f);
                    updateSelectBar();
                    adapter.refreshCell(position);
                } else {
                    showPhoto(f);
                }
            }
        });
        grid.setOnItemLongClickListener(new android.widget.AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(android.widget.AdapterView<?> parent, View view, int position, long id) {
                if (!selecting) {
                    setSelecting(true);
                    selected.add(photos.get(position));
                    updateSelectBar();
                    adapter.notifyDataSetChanged();
                }
                return true;
            }
        });
        root.addView(grid, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        outer.addView(root);

        // 悬浮拍照按钮
        TextView shoot = new TextView(this);
        shootBtn = shoot;
        shoot.setText("📷  拍照");
        shoot.setTextSize(15);
        shoot.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        shoot.setTextColor(0xFFFFFFFF);
        shoot.setGravity(Gravity.CENTER);
        GradientDrawable sb = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                Night.dark ? new int[]{0xFF3E63D8, 0xFF5C86FF} : new int[]{0xFF2F6BFF, 0xFF4F8DFF});
        sb.setCornerRadius(dp(28));
        shoot.setBackground(sb);
        FrameLayout.LayoutParams slp = new FrameLayout.LayoutParams(dp(140), dp(54),
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        slp.bottomMargin = dp(24);
        shoot.setLayoutParams(slp);
        shoot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (useSystemCamera()) {
                    shootWithSystemCamera();
                } else {
                    Intent it = new Intent(ProjectActivity.this, CameraActivity.class);
                    it.putExtra("dir", dir.getAbsolutePath());
                    startActivity(it);
                }
            }
        });
        outer.addView(shoot);

        setContentView(outer);
    }

    private void setSelecting(boolean on) {
        selecting = on;
        if (!on) selected.clear();
        if (selectBar != null) selectBar.setVisibility(on ? View.VISIBLE : View.GONE);
        if (actExport != null) actExport.setVisibility(on ? View.GONE : View.VISIBLE);
        if (actSelect != null) actSelect.setVisibility(on ? View.GONE : View.VISIBLE);
        if (shootBtn != null) shootBtn.setVisibility(on ? View.GONE : View.VISIBLE);
        updateSelectBar();
        if (adapter != null) adapter.notifyDataSetChanged();
    }

    private void updateSelectBar() {
        if (selDelete != null) selDelete.setText("删除 (" + selected.size() + ")");
    }

    private void askDeleteSelected() {
        if (selected.isEmpty()) {
            Toast.makeText(this, "先选几张要删的照片", Toast.LENGTH_SHORT).show();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("删除 " + selected.size() + " 张照片")
                .setMessage("删除后无法恢复，确定吗？")
                .setPositiveButton("删除", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        for (File f : new java.util.ArrayList<>(selected)) {
                            //noinspection ResultOfMethodCallIgnored
                            f.delete();
                            Notes.remove(dir, f);
                        }
                        selected.clear();
                        setSelecting(false);
                        reload();
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    /** 批量导出到系统相册（App 内存储不变，属于主动复制出来） */
    private void askExport() {
        if (photos.isEmpty()) {
            Toast.makeText(this, "这个项目还没有照片", Toast.LENGTH_SHORT).show();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("导出 " + photos.size() + " 张照片")
                .setMessage("「" + Store.nameOf(dir) + "」的照片会复制到系统相册"
                        + "（Pictures/项目相机），App 里的原件保留。")
                .setPositiveButton("导出", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        exportAll();
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void exportAll() {
        final List<File> list = new ArrayList<>(photos);
        new Thread(new Runnable() {
            @Override
            public void run() {
                int ok = 0;
                if (Build.VERSION.SDK_INT >= 29) {
                    String folder = "Pictures/项目相机/" + safeName(Store.nameOf(dir));
                    for (File f : list) {
                        try {
                            android.content.ContentValues v = new android.content.ContentValues();
                            v.put(android.provider.MediaStore.Images.Media.DISPLAY_NAME, f.getName());
                            v.put(android.provider.MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                            v.put(android.provider.MediaStore.Images.Media.RELATIVE_PATH, folder);
                            android.net.Uri uri = getContentResolver().insert(
                                    android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
                            if (uri == null) continue;
                            java.io.OutputStream os = getContentResolver().openOutputStream(uri);
                            java.io.FileInputStream in = new java.io.FileInputStream(f);
                            byte[] buf = new byte[8192];
                            int n;
                            while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
                            in.close();
                            os.close();
                            ok++;
                        } catch (Throwable ignored) {
                        }
                    }
                }
                final int done = ok;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (done > 0) {
                            Toast.makeText(ProjectActivity.this,
                                    "已导出 " + done + " 张到 相册/Pictures/项目相机",
                                    Toast.LENGTH_LONG).show();
                        } else {
                            // 低版本或导出失败：直接多图分享
                            shareAll(list);
                        }
                    }
                });
            }
        }).start();
    }

    private String safeName(String name) {
        if (name == null || name.length() == 0) return "未命名项目";
        return name.replaceAll("[\\\\/:*?\"<>|]", "_");
    }

    private void shareAll(List<File> list) {
        try {
            ArrayList<android.net.Uri> uris = new ArrayList<>();
            for (File f : list) uris.add(PhotoProvider.uriFor(f));
            Intent send = new Intent(Intent.ACTION_SEND_MULTIPLE);
            send.setType("image/jpeg");
            send.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(send, "导出照片"));
        } catch (Throwable t) {
            Toast.makeText(this, "导出失败：" + t.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private boolean useSystemCamera() {
        return getSharedPreferences("projcam", MODE_PRIVATE)
                .getBoolean("use_system_camera", true);
    }

    /** 调系统相机拍一张：先借用 MediaStore 临时条目当输出，拍完立刻搬进项目并删掉临时条目 */
    private void shootWithSystemCamera() {
        try {
            pendingShot = Store.newPhoto(dir);
            Intent it = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
            pendingUri = null;

            if (Build.VERSION.SDK_INT >= 29) {
                // 走 MediaStore：厂商相机对自家媒体库的输出最配合，不容易写出空文件/坏文件
                android.content.ContentValues v = new android.content.ContentValues();
                v.put(android.provider.MediaStore.Images.Media.DISPLAY_NAME,
                        "projcam_tmp_" + System.currentTimeMillis() + ".jpg");
                v.put(android.provider.MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                v.put(android.provider.MediaStore.Images.Media.RELATIVE_PATH,
                        "DCIM/.projcam_tmp");
                // 注意：不能设 IS_PENDING=1，一加/OPPO 相机会认为目标不可写而直接不拍
                pendingUri = getContentResolver().insert(
                        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            }
            if (pendingUri == null) {
                pendingUri = PhotoProvider.uriFor(pendingShot);
            }

            it.putExtra(android.provider.MediaStore.EXTRA_OUTPUT, pendingUri);
            it.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);

            if (it.resolveActivity(getPackageManager()) == null) {
                startInnerCamera();
                return;
            }
            startActivityForResult(it, REQ_SYS_CAMERA);
        } catch (Throwable t) {
            Toast.makeText(this, "调不起系统相机：" + t.getMessage(), Toast.LENGTH_SHORT).show();
            pendingShot = null;
            pendingUri = null;
        }
    }

    private void startInnerCamera() {
        Intent inner = new Intent(ProjectActivity.this, CameraActivity.class);
        inner.putExtra("dir", dir.getAbsolutePath());
        startActivity(inner);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, final Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_SYS_CAMERA) return;

        final File target = pendingShot;
        final android.net.Uri src = pendingUri;
        pendingShot = null;
        pendingUri = null;

        if (src == null || target == null) {
            Toast.makeText(this, "系统相机没有返回可用的输出，请重试", Toast.LENGTH_SHORT).show();
            return;
        }

        new Thread(new Runnable() {
            @Override
            public void run() {
                boolean ok = copyToProject(src, target);
                cleanupTemp(src);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (ok) {
                            Toast.makeText(ProjectActivity.this, "已保存到项目",
                                    Toast.LENGTH_SHORT).show();
                        } else {
                            // 相机什么都没写：看看有没有回传缩略图可以救
                            boolean saved = false;
                            if (data != null) {
                                Object extra = data.getParcelableExtra("data");
                                if (extra instanceof android.graphics.Bitmap) {
                                    try {
                                        java.io.FileOutputStream fos = new java.io.FileOutputStream(target);
                                        ((android.graphics.Bitmap) extra)
                                                .compress(android.graphics.Bitmap.CompressFormat.JPEG, 92, fos);
                                        fos.close();
                                        saved = target.length() > 0;
                                    } catch (Throwable ignored) {
                                    }
                                }
                            }
                            if (saved) {
                                Toast.makeText(ProjectActivity.this,
                                        "已保存到项目（该相机只回传了小图）", Toast.LENGTH_LONG).show();
                            } else {
                                if (target.exists()) target.delete();
                                Toast.makeText(ProjectActivity.this,
                                        "系统相机没有写出照片，已切到 App 内相机",
                                        Toast.LENGTH_LONG).show();
                                startInnerCamera();
                            }
                        }
                        reload();
                    }
                });
            }
        }).start();
    }

    /** 把相机写出的内容搬进项目目录，并确认它真能解码成画面 */
    private boolean copyToProject(android.net.Uri src, File target) {
        try {
            java.io.InputStream in = getContentResolver().openInputStream(src);
            if (in == null) return false;
            java.io.FileOutputStream out = new java.io.FileOutputStream(target);
            byte[] buf = new byte[8192];
            int n;
            long total = 0;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
                total += n;
            }
            out.close();
            in.close();
            if (total < 1024) return false;

            // 有些相机输出 HEIF/HEVC 却挂在 .jpg 上，先按图片通用方式转成标准 JPEG
            if (!isJpeg(target)) {
                if (!transcodeToJpeg(target)) return false;
            }
            // 真正解码一次，确认不是坏图/全黑占位
            android.graphics.BitmapFactory.Options o = new android.graphics.BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            android.graphics.BitmapFactory.decodeFile(target.getAbsolutePath(), o);
            return o.outWidth > 0 && o.outHeight > 0;
        } catch (Throwable t) {
            return false;
        }
    }

    private boolean isJpeg(File f) {
        try {
            java.io.FileInputStream in = new java.io.FileInputStream(f);
            byte[] head = new byte[3];
            int n = in.read(head);
            in.close();
            return n == 3 && (head[0] & 0xFF) == 0xFF && (head[1] & 0xFF) == 0xD8
                    && (head[2] & 0xFF) == 0xFF;
        } catch (Throwable t) {
            return false;
        }
    }

    /** 用系统解码器把 HEIF 等格式重新编码成 JPEG（API 28+） */
    private boolean transcodeToJpeg(File f) {
        if (Build.VERSION.SDK_INT < 28) return false;
        try {
            android.graphics.Bitmap bmp = null;
            if (Build.VERSION.SDK_INT >= 28) {
                android.graphics.ImageDecoder.Source s = android.graphics.ImageDecoder.createSource(f);
                bmp = android.graphics.ImageDecoder.decodeBitmap(s);
            }
            if (bmp == null) {
                bmp = android.graphics.BitmapFactory.decodeFile(f.getAbsolutePath());
            }
            if (bmp == null || bmp.getWidth() <= 0) return false;
            java.io.FileOutputStream out = new java.io.FileOutputStream(f);
            bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 95, out);
            out.close();
            bmp.recycle();
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    /** 删掉借用的 MediaStore 临时条目，让照片只留在项目里 */
    private void cleanupTemp(android.net.Uri uri) {
        if (uri == null) return;
        if (!"content".equals(uri.getScheme())) return;
        try {
            getContentResolver().delete(uri, null, null);
        } catch (Throwable ignored) {
        }
    }

    private void reload() {
        photos.clear();
        photos.addAll(Store.photos(dir));
        if (adapter != null) adapter.notifyDataSetChanged();
        if (countText != null) countText.setText(photos.isEmpty() ? " 空" : " " + photos.size() + " 张");
    }

    private class ThumbAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return photos.size();
        }

        @Override
        public Object getItem(int position) {
            return photos.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            int size = (getResources().getDisplayMetrics().widthPixels - dp(16) * 2 - dp(8)) / 3;
            Holder h;
            if (convertView == null) {
                FrameLayout cell = new FrameLayout(ProjectActivity.this);
                cell.setLayoutParams(new GridView.LayoutParams(size, size));

                ImageView iv = new ImageView(ProjectActivity.this);
                iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
                iv.setLayoutParams(new FrameLayout.LayoutParams(size, size));
                iv.setBackground(rounded(Night.dark ? 0xFF232B36 : 0xFFEDF1F7, 10));
                cell.addView(iv);

                TextView note = new TextView(ProjectActivity.this);
                note.setText("✎");
                note.setTextSize(10);
                note.setTextColor(0xFFFFFFFF);
                note.setGravity(Gravity.CENTER);
                note.setBackground(rounded(0xCC000000, 5));
                FrameLayout.LayoutParams nlp = new FrameLayout.LayoutParams(dp(18), dp(18),
                        Gravity.TOP | Gravity.START);
                nlp.leftMargin = dp(4);
                nlp.topMargin = dp(4);
                note.setLayoutParams(nlp);
                note.setVisibility(View.GONE);
                cell.addView(note);

                View veil = new View(ProjectActivity.this);
                veil.setBackgroundColor(0x332F6BFF);
                veil.setLayoutParams(new FrameLayout.LayoutParams(size, size));
                veil.setVisibility(View.GONE);
                cell.addView(veil);

                TextView tick = new TextView(ProjectActivity.this);
                tick.setText("✓");
                tick.setTextSize(12);
                tick.setTextColor(0xFFFFFFFF);
                tick.setGravity(Gravity.CENTER);
                FrameLayout.LayoutParams tlp = new FrameLayout.LayoutParams(dp(20), dp(20),
                        Gravity.TOP | Gravity.END);
                tlp.rightMargin = dp(4);
                tlp.topMargin = dp(4);
                tick.setLayoutParams(tlp);
                tick.setVisibility(View.GONE);
                cell.addView(tick);

                h = new Holder();
                h.img = iv;
                h.note = note;
                h.veil = veil;
                h.tick = tick;
                h.size = size;
                cell.setTag(h);
                convertView = cell;
            } else {
                h = (Holder) convertView.getTag();
            }

            File f = photos.get(position);
            h.img.setImageBitmap(thumb(f, h.size));
            h.note.setVisibility(Notes.get(dir, f).length() > 0 ? View.VISIBLE : View.GONE);
            bindSelection(h, selecting && selected.contains(f), selecting);
            return convertView;
        }

        private void bindSelection(Holder h, boolean on, boolean showTick) {
            h.tick.setVisibility(showTick ? View.VISIBLE : View.GONE);
            h.tick.setBackground(on ? rounded(Night.accent, 9) : rounded(0x66000000, 9));
            h.veil.setVisibility(on ? View.VISIBLE : View.GONE);
        }

        void refreshCell(int index) {
            int child = index - grid.getFirstVisiblePosition();
            View v = grid.getChildAt(child);
            if (v != null && v.getTag() instanceof Holder) {
                Holder h = (Holder) v.getTag();
                File f = photos.get(index);
                bindSelection(h, selecting && selected.contains(f), selecting);
            }
        }
    }

    private static class Holder {
        ImageView img;
        TextView note;
        View veil;
        TextView tick;
        int size;
    }

    /** 缩略图缓存：同一张图不重复解码，避免滑动时卡顿 */
    private static android.util.LruCache<String, android.graphics.Bitmap> thumbCache;

    private android.graphics.Bitmap thumb(File f, int size) {
        if (thumbCache == null) {
            int max = (int) (Runtime.getRuntime().maxMemory() / 8);
            thumbCache = new android.util.LruCache<String, android.graphics.Bitmap>(max) {
                @Override
                protected int sizeOf(String key, android.graphics.Bitmap value) {
                    return value.getByteCount();
                }
            };
        }
        String key = f.getAbsolutePath() + "#" + size;
        android.graphics.Bitmap b = thumbCache.get(key);
        if (b != null) return b;
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(f.getAbsolutePath(), o);
            int sample = 1;
            int min = Math.min(o.outWidth, o.outHeight);
            while (min / sample > size * 1.4f) sample *= 2;

            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            b = BitmapFactory.decodeFile(f.getAbsolutePath(), o2);
            if (b != null) {
                android.graphics.Bitmap scaled = android.graphics.Bitmap.createScaledBitmap(b, size, size, true);
                if (scaled != b) b.recycle();
                b = scaled;
                thumbCache.put(key, b);
            }
        } catch (Throwable ignored) {
        }
        return b;
    }

    /** 全屏查看：分享 / 删除 */
    private void showPhoto(final File f) {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackgroundColor(0xFF000000);

        ImageView iv = new ImageView(this);
        iv.setAdjustViewBounds(true);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inSampleSize = 2;
            iv.setImageBitmap(BitmapFactory.decodeFile(f.getAbsolutePath(), o));
        } catch (Throwable ignored) {
        }
        box.addView(iv, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        final TextView noteView = new TextView(this);
        String note = Notes.get(dir, f);
        noteView.setText(note);
        noteView.setTextSize(13);
        noteView.setTextColor(0xFFFFFFFF);
        noteView.setBackgroundColor(0xCC000000);
        noteView.setPadding(dp(16), dp(10), dp(16), dp(10));
        noteView.setVisibility(note.length() > 0 ? View.VISIBLE : View.GONE);
        box.addView(noteView);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER);
        actions.setPadding(0, dp(10), 0, dp(18));

        TextView noteBtn = new TextView(this);
        noteBtn.setText("备注");
        noteBtn.setTextSize(14);
        noteBtn.setTextColor(0xFF7FA5FF);
        noteBtn.setPadding(dp(20), dp(10), dp(20), dp(10));
        noteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                askNote(f, noteView);
            }
        });
        actions.addView(noteBtn);

        TextView share = new TextView(this);
        share.setText("分享");
        share.setTextSize(14);
        share.setTextColor(0xFF7FA5FF);
        share.setPadding(dp(24), dp(10), dp(24), dp(10));
        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sharePhoto(f);
            }
        });
        actions.addView(share);

        TextView del = new TextView(this);
        del.setText("删除");
        del.setTextSize(14);
        del.setTextColor(0xFFFF7B72);
        del.setPadding(dp(24), dp(10), dp(24), dp(10));
        del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                askDelete(f);
            }
        });
        actions.addView(del);

        TextView close = new TextView(this);
        close.setText("关闭");
        close.setTextSize(14);
        close.setTextColor(0xFF96A0B0);
        close.setPadding(dp(24), dp(10), dp(24), dp(10));
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        actions.addView(close);
        box.addView(actions);

        dialog.setContentView(box);
        Window w = dialog.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(0xFF000000));
            w.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        }
        dialog.show();
    }

    /** 编辑这张照片的备注 */
    private void askNote(final File f, final TextView noteView) {
        final android.widget.EditText edit = new android.widget.EditText(this);
        edit.setText(Notes.get(dir, f));
        edit.setSelection(edit.getText().length());
        edit.setHint("例如：客厅插座位置 / 已核对");
        edit.setMinLines(2);
        LinearLayout wrap = new LinearLayout(this);
        wrap.setPadding(dp(20), dp(6), dp(20), dp(2));
        wrap.addView(edit, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        new AlertDialog.Builder(this)
                .setTitle("照片备注")
                .setView(wrap)
                .setPositiveButton("保存", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        String text = edit.getText().toString();
                        Notes.set(dir, f, text);
                        String saved = Notes.get(dir, f);
                        noteView.setText(saved);
                        noteView.setVisibility(saved.length() > 0 ? View.VISIBLE : View.GONE);
                        if (adapter != null) adapter.notifyDataSetChanged();
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void sharePhoto(File f) {
        try {
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("image/jpeg");
            send.putExtra(Intent.EXTRA_STREAM, PhotoProvider.uriFor(f));
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(send, "分享照片"));
        } catch (Throwable t) {
            Toast.makeText(this, "分享失败：" + t, Toast.LENGTH_SHORT).show();
        }
    }

    private void askDelete(final File f) {
        new AlertDialog.Builder(this)
                .setTitle("删除这张照片")
                .setMessage("删除后无法恢复，确定吗？")
                .setPositiveButton("删除", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        f.delete();
                        reload();
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }
}
