package com.example.projcam;

import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.ImageFormat;
import android.hardware.Camera;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.util.List;

/** 项目内拍照：预览 + 快门，照片直接写进当前项目目录（不进系统相簿） */
public class CameraActivity extends Activity implements SurfaceHolder.Callback {

    private static final int REQ_CAMERA = 3001;

    private File dir;
    private SurfaceView preview;
    private SurfaceHolder holder;
    private Camera camera;
    private TextView counter;
    private TextView shutter;
    private boolean taking;
    private boolean finished;
    private int shotCount;
    private int previewWidth, previewHeight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Night.init(this);
        String path = getIntent().getStringExtra("dir");
        if (path == null) {
            finish();
            return;
        }
        dir = new File(path);
        Window w = getWindow();
        w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        build();
        if (checkSelfPermission(android.Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.CAMERA}, REQ_CAMERA);
        }
    }

    private int dp(int v) {
        return (int) android.util.TypedValue.applyDimension(
                android.util.TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private void build() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF000000);

        preview = new SurfaceView(this);
        root.addView(preview, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        holder = preview.getHolder();
        holder.addCallback(this);
        holder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);

        // 顶栏：返回 + 计数
        LinearLayoutBar();

        TextView top = new TextView(this);
        top.setText("‹");
        top.setTextSize(26);
        top.setTextColor(0xFFFFFFFF);
        top.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams tlp = new FrameLayout.LayoutParams(dp(40), dp(40),
                Gravity.TOP | Gravity.START);
        tlp.topMargin = dp(28);
        tlp.leftMargin = dp(10);
        top.setLayoutParams(tlp);
        top.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        root.addView(top);

        counter = new TextView(this);
        counter.setText("0");
        counter.setTextSize(12);
        counter.setTextColor(0xFFFFFFFF);
        counter.setGravity(Gravity.CENTER);
        counter.setBackground(rounded(0x66000000, 12));
        counter.setPadding(dp(10), dp(4), dp(10), dp(4));
        FrameLayout.LayoutParams clp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.END);
        clp.topMargin = dp(32);
        clp.rightMargin = dp(14);
        counter.setLayoutParams(clp);
        root.addView(counter);

        // 快门
        shutter = new TextView(this);
        shutter.setText("");
        shutter.setBackground(rounded(0xFFFFFFFF, 36));
        FrameLayout.LayoutParams slp = new FrameLayout.LayoutParams(dp(72), dp(72),
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        slp.bottomMargin = dp(30);
        shutter.setLayoutParams(slp);
        shutter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                takePicture();
            }
        });
        root.addView(shutter);

        TextView hint = new TextView(this);
        hint.setText("照片只保存在本项目，不进系统相册");
        hint.setTextSize(11);
        hint.setTextColor(0x99FFFFFF);
        FrameLayout.LayoutParams hlp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        hlp.bottomMargin = dp(108);
        hint.setLayoutParams(hlp);
        root.addView(hint);

        setContentView(root);
        shotCount = Store.photos(dir).size();
        updateCounter();
    }

    /** 占位：无需额外处理 */
    private void LinearLayoutBar() {
    }

    private android.graphics.drawable.GradientDrawable rounded(int color, float r) {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp((int) r));
        return d;
    }

    private void updateCounter() {
        if (counter != null) counter.setText(String.valueOf(shotCount));
    }

    // ---------------- 相机 ----------------

    private boolean surfaceReady() {
        return holder != null && holder.getSurface() != null && holder.getSurface().isValid();
    }

    private void openCamera() {
        if (camera != null || finished) return;
        try {
            camera = Camera.open();
            // 快门声开关：部分机型（日韩版）系统强制有快门声，这里失败也不影响拍照
            try {
                boolean sound = getSharedPreferences("projcam", MODE_PRIVATE)
                        .getBoolean("shutter_sound", true);
                camera.enableShutterSound(sound);
            } catch (Throwable ignored) {
            }
        } catch (Throwable t) {
            Toast.makeText(this, "无法启动相机：" + t.getMessage(), Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        try {
            Camera.Parameters p = camera.getParameters();
            List<String> focusModes = p.getSupportedFocusModes();
            if (focusModes != null && focusModes.contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE)) {
                p.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE);
            } else if (focusModes != null && focusModes.contains(Camera.Parameters.FOCUS_MODE_AUTO)) {
                p.setFocusMode(Camera.Parameters.FOCUS_MODE_AUTO);
            }
            p.setPictureFormat(ImageFormat.JPEG);
            // 预览尺寸选接近 1280 宽
            Camera.Size best = null;
            for (Camera.Size s : p.getSupportedPreviewSizes()) {
                if (best == null || Math.abs(s.width - 1280) < Math.abs(best.width - 1280)) best = s;
            }
            if (best != null) {
                previewWidth = best.width;
                previewHeight = best.height;
                p.setPreviewSize(best.width, best.height);
            }
            camera.setParameters(p);
            camera.setDisplayOrientation(90);
            camera.setPreviewDisplay(holder);
            camera.startPreview();
        } catch (Throwable t) {
            try {
                camera.release();
            } catch (Throwable ignored) {
            }
            camera = null;
            Toast.makeText(this, "相机初始化失败：" + t.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void releaseCamera() {
        if (camera != null) {
            try {
                camera.stopPreview();
            } catch (Throwable ignored) {
            }
            try {
                camera.release();
            } catch (Throwable ignored) {
            }
            camera = null;
        }
    }

    private void takePicture() {
        if (camera == null || taking) return;
        taking = true;
        try {
            camera.autoFocus(null);
        } catch (Throwable ignored) {
        }
        try {
            camera.takePicture(null, null, new Camera.PictureCallback() {
                @Override
                public void onPictureTaken(byte[] data, Camera cam) {
                    savePhoto(data);
                    taking = false;
                    if (cam != null) {
                        try {
                            cam.startPreview();
                        } catch (Throwable ignored) {
                        }
                    }
                }
            });
        } catch (Throwable t) {
            taking = false;
            Toast.makeText(this, "拍照失败：" + t.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void savePhoto(byte[] data) {
        try {
            File f = Store.newPhoto(dir);
            FileOutputStream fos = new FileOutputStream(f);
            fos.write(data);
            fos.close();
            shotCount++;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    updateCounter();
                    Toast.makeText(CameraActivity.this, "已保存到项目", Toast.LENGTH_SHORT).show();
                }
            });
        } catch (Throwable t) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(CameraActivity.this, "保存失败：" + t.getMessage(),
                            Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQ_CAMERA) {
            boolean ok = results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED;
            if (!ok) {
                Toast.makeText(this, "没有相机权限，无法拍照", Toast.LENGTH_LONG).show();
                finish();
            } else if (surfaceReady()) {
                openCamera();
            }
        }
    }

    @Override
    public void surfaceCreated(SurfaceHolder h) {
        if (checkSelfPermission(android.Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            openCamera();
        }
    }

    @Override
    public void surfaceChanged(SurfaceHolder h, int format, int width, int height) {
        if (camera == null && surfaceReady()
                && checkSelfPermission(android.Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            openCamera();
            return;
        }
        if (camera != null) {
            try {
                camera.stopPreview();
                camera.setPreviewDisplay(h);
                camera.startPreview();
            } catch (Throwable ignored) {
            }
        }
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder h) {
        releaseCamera();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (surfaceReady()
                && checkSelfPermission(android.Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            openCamera();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        releaseCamera();
    }

    @Override
    protected void onDestroy() {
        finished = true;
        releaseCamera();
        super.onDestroy();
    }
}
