package com.example.projcam;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Base64;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.X509EncodedKeySpec;

/**
 * 应用内在线更新。
 *
 * <p>清单是单文件自包含签名：{"payload":"<清单原文>","sig":"<RSA-SHA256>"}。
 * 只有验签通过才会使用清单；下载完成后校验 sha256，不一致拒绝安装。
 */
public class OtaManager {

    private static final String MANIFEST_URL =
            "https://cdn.jsdelivr.net/gh/kimzhoua/projcam-publish@main/dist/update.json";

    private static final String MANIFEST_PUBKEY =
            "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA+IwWupZK5kkPnX9SOhWTWO1GEl5qxXG2Ewkr9lx1YtV14Ll3lKwG26nm+4GI2i3Gip+tIr3u4jPwWKbZnk9KvKBd2gnZZbYsylSf3N2U0dUN6y9CFcCfsGg4lMom/pc7r8Kco+QxUUzh2N6ZT0W7BkvzzqWws80V7btWg/t5LizDFTRtc1wdbk3rzaRnAiAEhPkyPgIM08sNQ25Oha5bk8KTrAfRgWf8LABAiIKfBEej2/sDwnJ+gnCpigWhHUXbD7RxS0wkfNw1OFHr5VNmOl8Jcc3r8wWZS8/n9GOS4TzOEVcfLvx1zV7HD2ScWwoclVkYnX4qJIiMm3w2y7tIQwIDAQAB";

    private final Activity activity;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private long downloadId = -1L;
    private String expectSha256;
    private boolean receiverRegistered;

    public OtaManager(Activity activity) {
        this.activity = activity;
    }

    private volatile String lastError = "";

    public void checkUpdate(final boolean manual) {
        if (manual) Toast.makeText(activity, "正在检查更新…", Toast.LENGTH_SHORT).show();
        new Thread(new Runnable() {
            @Override
            public void run() {
                String payload = null;
                for (String candidate : candidates(MANIFEST_URL)) {
                    boolean viaApi = candidate.startsWith("https://api.github.com/");
                    String wrapper = httpGet(candidate,
                            viaApi ? "application/vnd.github.raw,*/*" : "application/json,*/*");
                    if (wrapper == null) {
                        lastError = lastHttp != null ? lastHttp : "网络异常";
                        continue;
                    }
                    if (!wrapper.contains("payload")) {
                        lastError = "清单格式异常";
                        continue;
                    }
                    String body;
                    String sig;
                    try {
                        JSONObject w = new JSONObject(wrapper);
                        body = w.optString("payload", "");
                        sig = w.optString("sig", "");
                    } catch (Exception e) {
                        continue;
                    }
                    if (body.length() == 0) {
                        lastError = "清单为空";
                        continue;
                    }
                    if (!verify(body, sig)) {
                        lastError = "清单签名校验未通过";
                        continue;
                    }
                    payload = body;
                    break;
                }
                if (payload == null) {
                    ui.post(new Runnable() {
                        @Override
                        public void run() {
                            if (manual) {
                                Toast.makeText(activity,
                                        "检查更新失败：" + (lastError.length() > 0 ? lastError : "网络异常"),
                                        Toast.LENGTH_LONG).show();
                            }
                        }
                    });
                    return;
                }
                JSONObject obj;
                try {
                    obj = new JSONObject(payload);
                } catch (Exception e) {
                    return;
                }
                final int newCode = obj.optInt("versionCode", 0);
                final String newName = obj.optString("versionName", "");
                final String apkUrl = obj.optString("apkUrl", "");
                final String notes = obj.optString("notes", "");
                final String sha = obj.optString("sha256", "");
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        if (newCode > installedVersionCode() && apkUrl.length() > 0) {
                            showDialog(newName, newCode, apkUrl, notes, sha);
                        } else if (manual) {
                            Toast.makeText(activity,
                                    "已是最新版本 v" + installedVersionName(),
                                    Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        }).start();
    }

    private void showDialog(final String newName, final int newCode, final String apkUrl,
                            String notes, final String sha256) {
        String message = "当前版本 v" + installedVersionName()
                + "\n新版本 v" + newName + "（" + newCode + "）";
        if (notes != null && notes.length() > 0) message += "\n\n更新说明：\n" + notes;
        new AlertDialog.Builder(activity)
                .setTitle("发现新版本")
                .setMessage(message)
                .setPositiveButton("下载并安装", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        download(apkUrl, newName, sha256);
                    }
                })
                .setNegativeButton("以后再说", null)
                .show();
    }

    private void download(String apkUrl, String versionName, String sha256) {
        expectSha256 = sha256;
        try {
            DownloadManager.Request req = new DownloadManager.Request(Uri.parse(apkUrl));
            req.setTitle("项目相机 v" + versionName);
            req.setDescription("正在下载新版本，完成后会提示安装");
            req.setMimeType("application/vnd.android.package-archive");
            req.setNotificationVisibility(
                    DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,
                    "项目相机-v" + versionName + ".apk");
            DownloadManager dm = (DownloadManager) activity.getSystemService(Context.DOWNLOAD_SERVICE);
            if (dm == null) {
                Toast.makeText(activity, "系统下载服务不可用", Toast.LENGTH_SHORT).show();
                return;
            }
            registerReceiver();
            downloadId = dm.enqueue(req);
            Toast.makeText(activity, "已开始下载，完成后自动提示安装", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(activity, "下载失败：" + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            long id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L);
            if (id != downloadId) return;
            DownloadManager dm = (DownloadManager) activity.getSystemService(Context.DOWNLOAD_SERVICE);
            if (dm == null) return;
            final Uri uri = dm.getUriForDownloadedFile(id);
            if (uri == null) {
                Toast.makeText(activity, "下载失败，请重试", Toast.LENGTH_SHORT).show();
                return;
            }
            final String expect = expectSha256;
            if (expect == null || expect.length() == 0) {
                install(uri);
                return;
            }
            new Thread(new Runnable() {
                @Override
                public void run() {
                    final boolean ok = expect.equalsIgnoreCase(sha256Of(uri));
                    ui.post(new Runnable() {
                        @Override
                        public void run() {
                            if (ok) install(uri);
                            else Toast.makeText(activity,
                                    "安装包校验失败，已取消安装", Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }).start();
        }
    };

    private void registerReceiver() {
        if (receiverRegistered) return;
        IntentFilter filter = new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE);
        // 下载完成广播由系统下载服务发出，Android 13+ 必须显式声明导出
        if (Build.VERSION.SDK_INT >= 33) {
            activity.registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED);
        } else {
            activity.registerReceiver(receiver, filter);
        }
        receiverRegistered = true;
    }

    public void release() {
        if (receiverRegistered) {
            try {
                activity.unregisterReceiver(receiver);
            } catch (Exception ignored) {
            }
            receiverRegistered = false;
        }
    }

    private void install(final Uri uri) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                && !activity.getPackageManager().canRequestPackageInstalls()) {
            new AlertDialog.Builder(activity)
                    .setTitle("需要允许安装应用")
                    .setMessage("系统限制未知来源安装，请允许本应用安装应用后再试")
                    .setPositiveButton("去设置", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            try {
                                activity.startActivity(new Intent(
                                        Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                                        Uri.parse("package:" + activity.getPackageName())));
                            } catch (Exception ignored) {
                            }
                        }
                    })
                    .setNegativeButton("取消", null)
                    .show();
            return;
        }
        Intent it = new Intent(Intent.ACTION_VIEW);
        it.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        it.setDataAndType(uri, "application/vnd.android.package-archive");
        activity.startActivity(it);
    }

    private static String[] candidates(String url) {
        String ts = String.valueOf(System.currentTimeMillis());
        String api = url.replace("https://cdn.jsdelivr.net/gh/", "https://api.github.com/repos/")
                .replace("@main/", "/contents/") + "?ref=main";
        String raw = url.replace("https://cdn.jsdelivr.net/gh/", "https://raw.githubusercontent.com/")
                .replace("@main/", "/main/");
        String busted = url + (url.contains("?") ? "&" : "?") + "_=" + ts;
        // 国内网络对 raw / api 常不可达，补镜像源兜底；实测可用：jsDelivr、ghproxy
        String ghproxy = "https://ghproxy.net/" + raw;
        // raw 是权威源，放第一位；jsDelivr/ghproxy 有缓存延迟，只能兜底
        return new String[]{raw, api, ghproxy, busted, url};
    }

    private boolean verify(String body, String sigBase64) {
        if (sigBase64 == null || sigBase64.trim().length() == 0) return false;
        try {
            byte[] der = Base64.decode(MANIFEST_PUBKEY, Base64.DEFAULT);
            PublicKey pub = KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(der));
            Signature sig = Signature.getInstance("SHA256withRSA");
            sig.initVerify(pub);
            sig.update(body.getBytes("UTF-8"));
            return sig.verify(Base64.decode(sigBase64.trim(), Base64.DEFAULT));
        } catch (Exception e) {
            return false;
        }
    }

    private String sha256Of(Uri uri) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            InputStream in = activity.getContentResolver().openInputStream(uri);
            if (in == null) return "";
            byte[] buf = new byte[8192];
            int len;
            while ((len = in.read(buf)) != -1) md.update(buf, 0, len);
            in.close();
            byte[] d = md.digest();
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return "";
        }
    }

    private static volatile String lastHttp;

    private static String httpGet(String address, String accept) {
        HttpURLConnection conn = null;
        try {
            URL url = new URL(address);
            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(12000);
            conn.setReadTimeout(18000);
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) IPCalc");
            conn.setRequestProperty("Accept", accept);
            conn.setRequestProperty("Accept-Encoding", "identity");
            int code = conn.getResponseCode();
            if (code != 200) {
                lastHttp = "HTTP " + code;
                return null;
            }
            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(conn.getInputStream(), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) sb.append(line).append('\n');
            reader.close();
            return sb.toString();
        } catch (Exception e) {
            lastHttp = "连接失败（" + e.getClass().getSimpleName() + "）";
            return null;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private int installedVersionCode() {
        try {
            PackageInfo info = activity.getPackageManager().getPackageInfo(
                    activity.getPackageName(), 0);
            return info.versionCode;
        } catch (Exception e) {
            return 0;
        }
    }

    private String installedVersionName() {
        try {
            PackageInfo info = activity.getPackageManager().getPackageInfo(
                    activity.getPackageName(), 0);
            return info.versionName;
        } catch (Exception e) {
            return "";
        }
    }
}
