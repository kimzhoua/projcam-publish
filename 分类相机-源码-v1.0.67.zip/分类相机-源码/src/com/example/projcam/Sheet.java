package com.example.projcam;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.Typeface;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/** 统一的长按菜单样式：卡片式动作列表（替代系统默认的白底小弹窗） */
final class Sheet {

    interface OnPick {
        void onPick(int which);
    }

    private static int dp(Context c, float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                c.getResources().getDisplayMetrics());
    }

    private static GradientDrawable rounded(int color, float radius, Context c, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(c, radius));
        if (stroke != 0) d.setStroke(dp(c, 1), stroke);
        return d;
    }

    static void show(final Context ctx, String title, String[] items, final OnPick cb) {
        FrameLayout wrap = new FrameLayout(ctx);
        wrap.setPadding(dp(ctx, 18), dp(ctx, 20), dp(ctx, 18), dp(ctx, 20));

        LinearLayout card = new LinearLayout(ctx);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(rounded(Night.card, 22, ctx, Night.hair));
        card.setPadding(0, dp(ctx, 14), 0, dp(ctx, 8));

        TextView head = new TextView(ctx);
        head.setText(title);
        head.setTextSize(15.5f);
        head.setTypeface(Typeface.DEFAULT_BOLD);
        head.setTextColor(Night.main);
        head.setSingleLine(true);
        head.setEllipsize(android.text.TextUtils.TruncateAt.END);
        head.setPadding(dp(ctx, 20), dp(ctx, 4), dp(ctx, 20), dp(ctx, 12));
        card.addView(head);

        View line = new View(ctx);
        line.setBackgroundColor(Night.hair);
        line.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(ctx, 1)));
        card.addView(line);

        final Dialog[] dlg = new Dialog[1];

        for (int i = 0; i < items.length; i++) {
            final int which = i;
            TextView row = new TextView(ctx);
            boolean danger = items[i].contains("删除");
            row.setText(items[i]);
            row.setTextSize(14.5f);
            row.setTextColor(danger ? Night.danger : Night.main);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(ctx, 20), 0, dp(ctx, 20), 0);
            row.setLayoutParams(new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(ctx, 48)));
            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        if (dlg[0] != null) dlg[0].dismiss();
                    } catch (Throwable ignored) {
                    }
                    cb.onPick(which);
                }
            });
            card.addView(row);

            if (i != items.length - 1) {
                View div = new View(ctx);
                div.setBackgroundColor(Night.hair);
                LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, dp(ctx, 1));
                dlp.leftMargin = dp(ctx, 20);
                div.setLayoutParams(dlp);
                card.addView(div);
            }
        }

        View line2 = new View(ctx);
        line2.setBackgroundColor(Night.hair);
        LinearLayout.LayoutParams l2lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(ctx, 1));
        l2lp.topMargin = dp(ctx, 6);
        line2.setLayoutParams(l2lp);
        card.addView(line2);

        TextView cancel = new TextView(ctx);
        cancel.setText("取消");
        cancel.setTextSize(14f);
        cancel.setTextColor(Night.sub);
        cancel.setGravity(Gravity.CENTER);
        cancel.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(ctx, 46)));
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (dlg[0] != null) dlg[0].dismiss();
            }
        });
        card.addView(cancel);

        wrap.addView(card, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        Dialog d = new Dialog(ctx);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.setContentView(wrap);
        Window win = d.getWindow();
        if (win != null) {
            win.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            win.setLayout((int) (ctx.getResources().getDisplayMetrics().widthPixels * 0.9f),
                    ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        dlg[0] = d;
        d.show();
    }
}
