package com.example.projcam;

import android.content.Context;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * 项目仓库：每个项目是 files/projects/p_<毫秒>/ 目录，里面 meta.json + 若干 jpg。
 * 全部位于应用私有目录，系统相册扫不到。
 */
final class Store {

    static File root(Context c) {
        File r = new File(c.getFilesDir(), "projects");
        if (!r.exists()) r.mkdirs();
        return r;
    }

    static File archiveRoot(Context c) {
        File r = new File(c.getFilesDir(), "archive");
        if (!r.exists()) r.mkdirs();
        return r;
    }

    /** 归档：把项目目录移到 files/archive/ */
    static boolean archive(Context c, File dir) {
        try {
            File target = new File(archiveRoot(c), dir.getName());
            if (target.exists()) {
                target = new File(archiveRoot(c), dir.getName() + "_" + System.currentTimeMillis());
            }
            return dir.renameTo(target);
        } catch (Throwable t) {
            return false;
        }
    }

    /** 取消归档：移回 files/projects/ */
    static boolean unarchive(Context c, File dir) {
        try {
            File target = new File(root(c), dir.getName());
            if (target.exists()) {
                target = new File(root(c), dir.getName() + "_" + System.currentTimeMillis());
            }
            return dir.renameTo(target);
        } catch (Throwable t) {
            return false;
        }
    }

    /** 归档项目列表（按时间倒序） */
    static List<Project> listArchived(Context c) {
        List<Project> out = new ArrayList<>();
        File[] dirs = archiveRoot(c).listFiles();
        if (dirs == null) return out;
        for (File d : dirs) {
            if (!d.isDirectory()) continue;
            Project p = new Project();
            p.dir = d;
            p.name = nameOf(d);
            p.created = d.lastModified();
            List<File> photos = photos(d);
            p.count = photos.size();
            p.cover = photos.isEmpty() ? null : photos.get(0);
            out.add(p);
        }
        Collections.sort(out, new Comparator<Project>() {
            @Override
            public int compare(Project a, Project b) {
                return Long.compare(b.created, a.created);
            }
        });
        return out;
    }

    static final class Project {
        File dir;
        String name;
        long created;
        int count;
        File cover;
    }

    static List<Project> list(Context c) {
        List<Project> out = new ArrayList<>();
        File[] dirs = root(c).listFiles();
        if (dirs == null) return out;
        for (File d : dirs) {
            if (!d.isDirectory()) continue;
            Project p = new Project();
            p.dir = d;
            p.name = nameOf(d);
            p.created = d.lastModified();
            List<File> photos = photos(d);
            p.count = photos.size();
            p.cover = photos.isEmpty() ? null : photos.get(0);
            out.add(p);
        }
        Collections.sort(out, new Comparator<Project>() {
            @Override
            public int compare(Project a, Project b) {
                return Long.compare(b.created, a.created);
            }
        });
        return out;
    }

    static Project create(Context c, String name) {
        File d = new File(root(c), "p_" + System.currentTimeMillis());
        d.mkdirs();
        Project p = new Project();
        p.dir = d;
        p.name = name;
        p.created = System.currentTimeMillis();
        p.count = 0;
        writeMeta(d, name);
        return p;
    }

    static String nameOf(File dir) {
        try {
            File meta = new File(dir, "meta.json");
            if (meta.exists()) {
                JSONObject o = new JSONObject(readAll(meta));
                String n = o.optString("name");
                if (n.length() > 0) return n;
            }
        } catch (Throwable ignored) {
        }
        return "未命名项目";
    }

    static void rename(File dir, String name) {
        writeMeta(dir, name);
    }

    private static void writeMeta(File dir, String name) {
        try {
            JSONObject o = new JSONObject();
            o.put("name", name);
            o.put("created", System.currentTimeMillis());
            FileOutputStream fos = new FileOutputStream(new File(dir, "meta.json"));
            fos.write(o.toString().getBytes("UTF-8"));
            fos.close();
        } catch (Throwable ignored) {
        }
    }

    private static String readAll(File f) throws Exception {
        java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
        java.io.FileInputStream fis = new java.io.FileInputStream(f);
        byte[] buf = new byte[1024];
        int n;
        while ((n = fis.read(buf)) > 0) bos.write(buf, 0, n);
        fis.close();
        return new String(bos.toByteArray(), "UTF-8");
    }

    static void delete(File dir) {
        deleteTree(dir);
    }

    private static void deleteTree(File f) {
        if (f == null || !f.exists()) return;
        if (f.isDirectory()) {
            File[] kids = f.listFiles();
            if (kids != null) for (File k : kids) deleteTree(k);
        }
        f.delete();
    }

    static List<File> photos(File dir) {
        List<File> out = new ArrayList<>();
        File[] fs = dir.listFiles();
        if (fs == null) return out;
        for (File f : fs) {
            if (f.isFile() && f.getName().toLowerCase().endsWith(".jpg")) out.add(f);
        }
        Collections.sort(out, new Comparator<File>() {
            @Override
            public int compare(File a, File b) {
                return Long.compare(b.lastModified(), a.lastModified());
            }
        });
        return out;
    }

    static File newPhoto(File dir) {
        return new File(dir, "img_" + System.currentTimeMillis() + ".jpg");
    }
}
