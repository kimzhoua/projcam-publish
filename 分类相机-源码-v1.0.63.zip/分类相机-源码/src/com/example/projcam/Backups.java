package com.example.projcam;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

/** 整个 App 的数据备份 / 恢复：全部项目（照片、文档、备注、回收站）+ 部分设置 */
final class Backups {

    static File dir(Context c) {
        File d = new File(c.getCacheDir(), "backup");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    static File projectsDir(Context c) {
        return new File(c.getFilesDir(), "projects");
    }

    /** 导出指定项目的数据为一个 zip */
    static File exportAll(Context c, List<File> dirs) throws Exception {
        String stamp = new java.text.SimpleDateFormat("yyyyMMdd-HHmm",
                java.util.Locale.CHINA).format(new java.util.Date());
        File out = new File(dir(c), "分类相机备份-" + stamp + ".zip");

        ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(out));
        int count = 0;
        for (File d : dirs) {
            if (!d.isDirectory()) continue;
            count++;
            addDir(zos, d, "projects/" + d.getName() + "/");
        }
        zos.putNextEntry(new ZipEntry("prefs.json"));
        zos.write(prefsJson(c).getBytes("UTF-8"));
        zos.closeEntry();

        zos.putNextEntry(new ZipEntry("manifest.json"));
        JSONObject m = new JSONObject();
        m.put("app", "分类相机");
        m.put("time", System.currentTimeMillis());
        m.put("projects", count);
        zos.write(m.toString().getBytes("UTF-8"));
        zos.closeEntry();
        zos.close();
        return out;
    }

    static File exportAll(Context c) throws Exception {
        List<File> all = new ArrayList<>();
        File[] fs = projectsDir(c).listFiles();
        if (fs != null) {
            for (File f : fs) if (f.isDirectory()) all.add(f);
        }
        return exportAll(c, all);
    }

    private static void addDir(ZipOutputStream zos, File dir, String prefix) throws Exception {
        File[] fs = dir.listFiles();
        if (fs == null) return;
        for (File f : fs) {
            if (f.isDirectory()) {
                addDir(zos, f, prefix + f.getName() + "/");
            } else {
                zos.putNextEntry(new ZipEntry(prefix + f.getName()));
                FileInputStream in = new FileInputStream(f);
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) zos.write(buf, 0, n);
                in.close();
                zos.closeEntry();
            }
        }
    }

    /** 只备份显示类设置，锁与密码不备份，避免新机被锁住 */
    private static String prefsJson(Context c) {
        SharedPreferences sp = c.getSharedPreferences("projcam", Context.MODE_PRIVATE);
        JSONObject o = new JSONObject();
        try {
            o.put("night_mode", sp.getInt("night_mode", 0));
            o.put("use_system_camera", sp.getBoolean("use_system_camera", false));
            o.put("shutter_sound", sp.getBoolean("shutter_sound", true));
            o.put("newest_first", sp.getBoolean("newest_first", true));
            o.put("finger_lock", false);
        } catch (Throwable ignored) {
        }
        return o.toString();
    }

    /** 恢复：合并导入，已存在的同名项目跳过 */
    static int[] importAll(Context c, InputStream in) throws Exception {
        File tmp = new File(dir(c), "incoming.zip");
        FileOutputStream fos = new FileOutputStream(tmp);
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) fos.write(buf, 0, n);
        fos.close();

        int projects = 0;
        int skipped = 0;
        File proj = projectsDir(c);
        if (!proj.exists()) proj.mkdirs();

        ZipFile zf = new ZipFile(tmp);
        try {
            List<String> roots = new ArrayList<>();
            Enumeration<? extends ZipEntry> en = zf.entries();
            while (en.hasMoreElements()) {
                ZipEntry e = en.nextElement();
                String name = e.getName();
                if (name.startsWith("projects/")) {
                    String rest = name.substring("projects/".length());
                    int slash = rest.indexOf('/');
                    String id = slash < 0 ? rest : rest.substring(0, slash);
                    if (id.length() > 0 && !roots.contains(id)) roots.add(id);
                }
            }

            if (roots.isEmpty()) throw new Exception("这不是分类相机的备份文件（没有找到项目）");

            for (String id : roots) {
                File target = new File(proj, id);
                if (target.exists()) {
                    skipped++;
                    continue;
                }
                target.mkdirs();
                Enumeration<? extends ZipEntry> e2 = zf.entries();
                String prefix = "projects/" + id + "/";
                while (e2.hasMoreElements()) {
                    ZipEntry e = e2.nextElement();
                    if (!e.getName().startsWith(prefix) || e.isDirectory()) continue;
                    String rel = e.getName().substring(prefix.length());
                    if (rel.contains("..")) continue;   // 防路径穿越
                    File dest = new File(target, rel);
                    File parent = dest.getParentFile();
                    if (parent != null && !parent.exists()) parent.mkdirs();
                    InputStream is = zf.getInputStream(e);
                    FileOutputStream os = new FileOutputStream(dest);
                    byte[] b = new byte[8192];
                    int r;
                    while ((r = is.read(b)) > 0) os.write(b, 0, r);
                    is.close();
                    os.close();
                }
                projects++;
            }

            // 设置
            ZipEntry pe = zf.getEntry("prefs.json");
            if (pe != null) {
                InputStream is = zf.getInputStream(pe);
                byte[] b = new byte[(int) Math.min(pe.getSize(), 4096)];
                int len = is.read(b);
                is.close();
                if (len > 0) {
                    JSONObject o = new JSONObject(new String(b, 0, len, "UTF-8"));
                    SharedPreferences.Editor ed = c.getSharedPreferences("projcam",
                            Context.MODE_PRIVATE).edit();
                    if (o.has("night_mode")) ed.putInt("night_mode", o.optInt("night_mode", 0));
                    if (o.has("use_system_camera"))
                        ed.putBoolean("use_system_camera", o.optBoolean("use_system_camera", false));
                    if (o.has("shutter_sound"))
                        ed.putBoolean("shutter_sound", o.optBoolean("shutter_sound", true));
                    if (o.has("newest_first"))
                        ed.putBoolean("newest_first", o.optBoolean("newest_first", true));
                    ed.apply();
                }
            }
        } finally {
            zf.close();
        }
        //noinspection ResultOfMethodCallIgnored
        tmp.delete();
        return new int[]{projects, skipped};
    }

    static void copy(InputStream in, OutputStream out) throws Exception {
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
    }
}
