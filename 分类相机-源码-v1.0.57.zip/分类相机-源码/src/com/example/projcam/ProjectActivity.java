package com.example.projcam;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.List;

/** 项目内页：照片网格 + 拍照入口 */
public class ProjectActivity extends Activity {

    private File dir;
    private GridView grid;
    private TextView countText;
    private final List<File> photos = new ArrayList<>();
    private boolean newestFirst = true;
    private ThumbAdapter adapter;
    private File pendingShot;
    private android.net.Uri pendingUri;
    private static final int REQ_SYS_CAMERA = 4101;
    private static final int REQ_IMPORT = 4102;

    // 多选
    private boolean selecting;
    private final java.util.Set<File> selected = new java.util.HashSet<>();
    private TextView selAll, selDelete, selCancel, actExport, actSelect, shootBtn;
    private LinearLayout photoBtnBar;
    private TextView modePhoto, modeDoc, sortBtnRef;
    private LinearLayout docPanel;
    private LinearLayout docList;
    private boolean docMode;
    private LinearLayout selectBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Night.init(this);
        String path = getIntent().getStringExtra("dir");
        if (path == null) {
            finish();
            return;
        }
        dir = new File(path);
        applyImmersive();
        build();
        reload();
    }

    private void applyImmersive() {
        Window w = getWindow();
        w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        w.setStatusBarColor(0x00000000);
        int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | (Night.dark ? 0 : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        w.getDecorView().setSystemUiVisibility(flags);
    }

    @Override
    protected void onResume() {
        super.onResume();
        Life.onResume();
        // 如果是从后台真正回到 App，先退回主页做指纹验证
        if (Life.pending && MainActivity.lockOn(this)) {
            Life.pending = false;
            MainActivity.resetLock();
            Intent mi = new Intent(this, MainActivity.class);
            mi.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(mi);
            finish();
            return;
        }
        reload();
        if (docMode) reloadDocs();

        // App 内相机回来：只新增了 1 张就顺手问一句备注
        if (cameraCountBefore >= 0) {
            if (photos.size() == cameraCountBefore + 1) {
                File latest = photos.get(photos.size() - 1);
                cameraCountBefore = -1;
                if (Notes.get(dir, latest).length() == 0) askQuickNote(latest);
            } else {
                cameraCountBefore = -1;
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        Life.onPause();
    }

    private int dp(int v) {
        return (int) android.util.TypedValue.applyDimension(
                android.util.TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private int statusBarHeight() {
        int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
        return id > 0 ? getResources().getDimensionPixelSize(id) : dp(24);
    }

    private GradientDrawable rounded(int color, float radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp((int) radiusDp));
        return d;
    }

    private void build() {
        FrameLayout outer = new FrameLayout(this);
        outer.setBackgroundColor(Night.page);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), statusBarHeight() + dp(10), dp(16), 0);

        // 顶栏
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);

        TextView back = new TextView(this);
        back.setText("‹");
        back.setTextSize(26);
        back.setTextColor(Night.accent);
        back.setGravity(Gravity.CENTER);
        back.setLayoutParams(new LinearLayout.LayoutParams(dp(34), dp(38)));
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        bar.addView(back);

        TextView title = new TextView(this);
        title.setText(Store.nameOf(dir));
        title.setTextSize(18);
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        title.setTextColor(Night.main);
        title.setSingleLine(true);
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        title.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        bar.addView(title);

        countText = new TextView(this);
        countText.setTextSize(11);
        countText.setTextColor(Night.faint);
        countText.setPadding(0, 0, dp(8), 0);
        bar.addView(countText);

        final TextView sortBtn = new TextView(this);
        sortBtn.setText("时间↓");
        sortBtn.setTextSize(12);
        sortBtn.setTextColor(Night.sub);
        sortBtn.setPadding(dp(4), dp(6), dp(8), dp(6));
        sortBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                newestFirst = !newestFirst;
                getSharedPreferences("projcam", MODE_PRIVATE).edit()
                        .putBoolean("newest_first", newestFirst).apply();
                sortBtn.setText(newestFirst ? "时间↓" : "时间↑");
                reload();
                grid.setSelection(0);
            }
        });
        bar.addView(sortBtn);

        TextView trashBtn = new TextView(this);
        trashBtn.setText("回收站");
        trashBtn.setTextSize(12);
        trashBtn.setTextColor(Night.sub);
        trashBtn.setPadding(dp(8), dp(6), dp(6), dp(6));
        trashBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showTrash();
            }
        });
        bar.addView(trashBtn);

        actExport = new TextView(this);
        actExport.setText("导出");
        actExport.setTextSize(12);
        actExport.setTextColor(Night.accent);
        actExport.setPadding(dp(8), dp(6), dp(8), dp(6));
        actExport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                askExport();
            }
        });
        bar.addView(actExport);

        actSelect = new TextView(this);
        actSelect.setText("选择");
        actSelect.setTextSize(12);
        actSelect.setTextColor(Night.accent);
        actSelect.setPadding(dp(8), dp(6), dp(4), dp(6));
        actSelect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setSelecting(true);
            }
        });
        bar.addView(actSelect);
        root.addView(bar);
        sortBtnRef = sortBtn;

        // 照片 / 文档 切换
        LinearLayout seg = new LinearLayout(this);
        seg.setOrientation(LinearLayout.HORIZONTAL);
        seg.setPadding(0, dp(8), 0, dp(2));
        LinearLayout.LayoutParams segLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        seg.setLayoutParams(segLp);

        modePhoto = new TextView(this);
        modePhoto.setText("照片");
        modeDoc = new TextView(this);
        modeDoc.setText("文档");
        TextView[] chips = new TextView[]{modePhoto, modeDoc};
        for (int i = 0; i < chips.length; i++) {
            TextView t = chips[i];
            t.setTextSize(13);
            t.setGravity(Gravity.CENTER);
            t.setPadding(dp(16), dp(7), dp(16), dp(7));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.rightMargin = dp(8);
            t.setLayoutParams(lp);
            seg.addView(t);
        }
        modePhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setDocMode(false);
            }
        });
        modeDoc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setDocMode(true);
            }
        });
        root.addView(seg);

        // 多选工具条（默认隐藏）
        selectBar = new LinearLayout(this);
        selectBar.setOrientation(LinearLayout.HORIZONTAL);
        selectBar.setGravity(Gravity.CENTER_VERTICAL);
        selectBar.setVisibility(View.GONE);
        LinearLayout.LayoutParams sbLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(40));
        selectBar.setLayoutParams(sbLp);

        selAll = new TextView(this);
        selAll.setText("全选");
        selAll.setTextSize(13);
        selAll.setTextColor(Night.accent);
        selAll.setPadding(dp(4), dp(8), dp(16), dp(8));
        selAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selected.size() == photos.size()) selected.clear();
                else selected.addAll(photos);
                updateSelectBar();
                adapter.notifyDataSetChanged();
            }
        });
        selectBar.addView(selAll);

        TextView spacer = new TextView(this);
        spacer.setLayoutParams(new LinearLayout.LayoutParams(0, 1, 1f));
        selectBar.addView(spacer);

        selDelete = new TextView(this);
        selDelete.setTextSize(13);
        selDelete.setTextColor(Night.danger);
        selDelete.setPadding(dp(12), dp(8), dp(12), dp(8));
        selDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                askDeleteSelected();
            }
        });
        selectBar.addView(selDelete);

        selCancel = new TextView(this);
        selCancel.setText("取消");
        selCancel.setTextSize(13);
        selCancel.setTextColor(Night.sub);
        selCancel.setPadding(dp(12), dp(8), dp(4), dp(8));
        selCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setSelecting(false);
            }
        });
        selectBar.addView(selCancel);
        root.addView(selectBar);

        // 照片网格
        grid = new GridView(this);
        grid.setNumColumns(3);
        int gap = dp(4);
        grid.setHorizontalSpacing(gap);
        grid.setVerticalSpacing(gap);
        grid.setPadding(0, dp(8), 0, dp(96));
        grid.setClipToPadding(false);
        adapter = new ThumbAdapter();
        grid.setAdapter(adapter);
        // 滑动多选：多选模式下按住并拖动，手指划过的整段都会被选中/取消
        grid.setOnTouchListener(new View.OnTouchListener() {
            private int anchor = -1;
            private boolean addMode = true;
            private int lastPos = -1;

            @Override
            public boolean onTouch(View v, android.view.MotionEvent e) {
                if (!selecting) return false;
                int pos = grid.pointToPosition((int) e.getX(), (int) e.getY());
                switch (e.getActionMasked()) {
                    case android.view.MotionEvent.ACTION_DOWN:
                        anchor = pos;
                        lastPos = pos;
                        if (pos >= 0 && pos < photos.size()) {
                            addMode = !selected.contains(photos.get(pos));
                            applyTo(pos, addMode);
                        }
                        return true;
                    case android.view.MotionEvent.ACTION_MOVE:
                        if (pos >= 0 && pos != lastPos && anchor >= 0) {
                            lastPos = pos;
                            int from = Math.min(anchor, pos);
                            int to = Math.max(anchor, pos);
                            for (int i = from; i <= to && i < photos.size(); i++) {
                                applyTo(i, addMode);
                            }
                        }
                        return true;
                    case android.view.MotionEvent.ACTION_UP:
                    case android.view.MotionEvent.ACTION_CANCEL:
                        anchor = -1;
                        lastPos = -1;
                        return true;
                }
                return false;
            }

            private void applyTo(int index, boolean add) {
                if (index < 0 || index >= photos.size()) return;
                File f = photos.get(index);
                if (add) {
                    if (!selected.contains(f)) selected.add(f);
                    else return; // 状态没变就不刷新，减少重绘
                } else {
                    if (!selected.remove(f)) return;
                }
                updateSelectBar();
                adapter.refreshCell(index);
            }
        });

        grid.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(android.widget.AdapterView<?> parent, View view, int position, long id) {
                File f = photos.get(position);
                if (selecting) {
                    if (selected.contains(f)) selected.remove(f);
                    else selected.add(f);
                    updateSelectBar();
                    adapter.refreshCell(position);
                } else {
                    showPhoto(f);
                }
            }
        });
        grid.setOnItemLongClickListener(new android.widget.AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(android.widget.AdapterView<?> parent, View view, int position, long id) {
                if (!selecting) {
                    setSelecting(true);
                    selected.add(photos.get(position));
                    updateSelectBar();
                    adapter.notifyDataSetChanged();
                }
                return true;
            }
        });
        root.addView(grid, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // 文档面板（与照片网格互斥显示）
        docPanel = new LinearLayout(this);
        docPanel.setOrientation(LinearLayout.VERTICAL);
        docPanel.setVisibility(View.GONE);
        docPanel.setPadding(0, dp(6), 0, dp(90));
        docPanel.setClipToPadding(false);

        LinearLayout docHead = new LinearLayout(this);
        docHead.setOrientation(LinearLayout.HORIZONTAL);
        docHead.setGravity(Gravity.CENTER_VERTICAL);

        TextView docHint = new TextView(this);
        docHint.setText("项目文档：文字 + 照片，随项目保存");
        docHint.setTextSize(11);
        docHint.setTextColor(Night.faint);
        docHint.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        docHead.addView(docHint);

        TextView newDoc = new TextView(this);
        newDoc.setText("＋ 新建");
        newDoc.setTextSize(13);
        newDoc.setTextColor(Night.accent);
        newDoc.setPadding(dp(10), dp(8), dp(4), dp(8));
        newDoc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                askNewDoc();
            }
        });
        docHead.addView(newDoc);
        docPanel.addView(docHead);

        android.widget.ScrollView docScroll = new android.widget.ScrollView(this);
        docList = new LinearLayout(this);
        docList.setOrientation(LinearLayout.VERTICAL);
        docList.setPadding(0, dp(6), 0, 0);
        docScroll.addView(docList);
        docPanel.addView(docScroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        root.addView(docPanel, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        outer.addView(root);
        paintModeChips();

        // 悬浮拍照按钮
        TextView shoot = new TextView(this);
        shootBtn = shoot;
        shoot.setText("📷  拍照");
        shoot.setTextSize(15);
        shoot.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        shoot.setTextColor(0xFFFFFFFF);
        shoot.setGravity(Gravity.CENTER);
        GradientDrawable sb = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                Night.dark ? new int[]{0xFF3E63D8, 0xFF5C86FF} : new int[]{0xFF2F6BFF, 0xFF4F8DFF});
        sb.setCornerRadius(dp(28));
        shoot.setBackground(sb);
        LinearLayout.LayoutParams shootLp = new LinearLayout.LayoutParams(dp(136), dp(54));
        shoot.setLayoutParams(shootLp);
        shoot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (useSystemCamera()) {
                    shootWithSystemCamera();
                } else {
                    Intent it = new Intent(ProjectActivity.this, CameraActivity.class);
                    it.putExtra("dir", dir.getAbsolutePath());
                    startActivity(it);
                }
            }
        });
        // 相册导入（次要按钮）
        TextView importBtn = new TextView(this);
        importBtn.setText("相册导入");
        importBtn.setTextSize(14);
        importBtn.setTextColor(Night.dark ? 0xFFD6E0FF : 0xFF2F6BFF);
        importBtn.setGravity(Gravity.CENTER);
        GradientDrawable ibg = new GradientDrawable();
        ibg.setColor(Night.dark ? 0xFF232C3E : 0xFFEDF2FF);
        ibg.setCornerRadius(dp(28));
        ibg.setStroke(dp(1), Night.dark ? 0xFF3A4763 : 0xFFD8E3FF);
        importBtn.setBackground(ibg);
        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(dp(112), dp(54));
        ilp.rightMargin = dp(12);
        importBtn.setLayoutParams(ilp);
        importBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pickFromGallery();
            }
        });

        LinearLayout photoBar = new LinearLayout(this);
        photoBar.setOrientation(LinearLayout.HORIZONTAL);
        photoBar.setGravity(Gravity.CENTER);
        photoBar.addView(importBtn);
        photoBar.addView(shoot);
        FrameLayout.LayoutParams pblp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        pblp.bottomMargin = dp(22);
        photoBar.setLayoutParams(pblp);
        outer.addView(photoBar);
        photoBtnBar = photoBar;

        setContentView(outer);
    }

    private void showTrash() {
        final List<Trash.Item> items = Trash.list(dir);
        if (items.isEmpty()) {
            new AlertDialog.Builder(this)
                    .setTitle("回收站")
                    .setMessage("回收站是空的。删除的照片和文档会先到这里，永久保留，可随时恢复。")
                    .setPositiveButton("知道了", null)
                    .show();
            return;
        }

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(14);
        box.setPadding(pad, dp(6), pad, dp(6));

        android.widget.ScrollView sv = new android.widget.ScrollView(this);
        LinearLayout listBox = new LinearLayout(this);
        listBox.setOrientation(LinearLayout.VERTICAL);
        int h = Math.min(items.size() * dp(64), dp(420));
        sv.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, h));
        sv.addView(listBox);
        box.addView(sv);

        java.text.SimpleDateFormat fmt =
                new java.text.SimpleDateFormat("MM-dd HH:mm", java.util.Locale.CHINA);
        final AlertDialog[] holder = new AlertDialog[1];

        for (int i = 0; i < items.size(); i++) {
            final Trash.Item it = items.get(i);
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, dp(8), 0, dp(8));

            LinearLayout texts = new LinearLayout(this);
            texts.setOrientation(LinearLayout.VERTICAL);
            texts.setLayoutParams(new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            TextView t1 = new TextView(this);
            t1.setText(("photo".equals(it.type) ? "照片 · " : "文档 · ") + it.name);
            t1.setTextSize(13);
            t1.setTextColor(Night.main);
            t1.setSingleLine(true);
            t1.setEllipsize(android.text.TextUtils.TruncateAt.END);
            texts.addView(t1);

            TextView t2 = new TextView(this);
            t2.setText("删除于 " + fmt.format(new java.util.Date(it.deletedAt)));
            t2.setTextSize(10);
            t2.setTextColor(Night.faint);
            texts.addView(t2);
            row.addView(texts);

            TextView restore = new TextView(this);
            restore.setText("恢复");
            restore.setTextSize(12);
            restore.setTextColor(Night.accent);
            restore.setPadding(dp(8), dp(6), dp(8), dp(6));
            restore.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    boolean ok = Trash.restore(dir, it);
                    Toast.makeText(ProjectActivity.this,
                            ok ? "已恢复到项目" : "恢复失败", Toast.LENGTH_SHORT).show();
                    reload();
                    if (docMode) reloadDocs();
                    if (holder[0] != null) holder[0].dismiss();
                    showTrash();
                }
            });
            row.addView(restore);

            TextView del = new TextView(this);
            del.setText("彻底删除");
            del.setTextSize(11);
            del.setTextColor(Night.danger);
            del.setPadding(dp(6), dp(6), 0, dp(6));
            del.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    new AlertDialog.Builder(ProjectActivity.this)
                            .setTitle("彻底删除")
                            .setMessage("「" + it.name + "」将被永久删除，无法恢复。")
                            .setPositiveButton("删除", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface d, int w) {
                                    Trash.purge(dir, it);
                                    if (holder[0] != null) holder[0].dismiss();
                                    showTrash();
                                }
                            })
                            .setNegativeButton("取消", null)
                            .show();
                }
            });
            row.addView(del);
            listBox.addView(row);
        }

        TextView clearAll = new TextView(this);
        clearAll.setText("清空回收站（永久删除）");
        clearAll.setTextSize(11);
        clearAll.setTextColor(Night.danger);
        clearAll.setPadding(0, dp(10), 0, 0);
        clearAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(ProjectActivity.this)
                        .setTitle("清空回收站")
                        .setMessage("回收站内 " + items.size() + " 个文件将被永久删除。")
                        .setPositiveButton("清空", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int w) {
                                Trash.clear(dir);
                                showTrash();
                            }
                        })
                        .setNegativeButton("取消", null)
                        .show();
            }
        });
        box.addView(clearAll);

        holder[0] = new AlertDialog.Builder(this)
                .setTitle("回收站（" + items.size() + "）")
                .setView(box)
                .setPositiveButton("关闭", null)
                .show();
    }

    private void setDocMode(boolean on) {
        docMode = on;
        if (on && selecting) setSelecting(false);
        if (grid != null) grid.setVisibility(on ? View.GONE : View.VISIBLE);
        if (docPanel != null) docPanel.setVisibility(on ? View.VISIBLE : View.GONE);
        if (photoBtnBar != null) photoBtnBar.setVisibility(on ? View.GONE : View.VISIBLE);
        else if (shootBtn != null) shootBtn.setVisibility(on ? View.GONE : View.VISIBLE);
        if (sortBtnRef != null) sortBtnRef.setVisibility(on ? View.GONE : View.VISIBLE);
        if (actExport != null) actExport.setVisibility(on ? View.GONE : View.VISIBLE);
        if (actSelect != null) actSelect.setVisibility(on ? View.GONE : View.VISIBLE);
        paintModeChips();
        if (on) reloadDocs();
    }

    private void paintModeChips() {
        TextView[] chips = new TextView[]{modePhoto, modeDoc};
        for (int i = 0; i < chips.length; i++) {
            boolean active = (i == 1) == docMode;
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(active
                    ? (Night.dark ? 0xFF2B3A55 : 0xFFE3ECFF)
                    : Night.soft);
            bg.setCornerRadius(dp(14));
            chips[i].setBackground(bg);
            chips[i].setTextColor(active ? Night.accent : Night.sub);
        }
    }

    private void reloadDocs() {
        if (docList == null) return;
        docList.removeAllViews();
        List<Docs.Doc> docs = Docs.list(dir);
        if (docs.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("还没有文档。点右上「＋ 新建」写第一篇。");
            empty.setTextSize(12);
            empty.setTextColor(Night.faint);
            empty.setPadding(0, dp(24), 0, dp(8));
            empty.setGravity(Gravity.CENTER);
            docList.addView(empty);
            return;
        }
        java.text.SimpleDateFormat fmt =
                new java.text.SimpleDateFormat("MM-dd HH:mm", java.util.Locale.CHINA);
        for (int i = 0; i < docs.size(); i++) {
            final Docs.Doc d = docs.get(i);
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            GradientDrawable bg = rounded(Night.card, 18);
            bg.setStroke(dp(1), Night.hair);
            row.setBackground(bg);
            row.setPadding(dp(16), dp(14), dp(14), dp(14));
            LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            rlp.bottomMargin = dp(10);
            row.setLayoutParams(rlp);

            LinearLayout texts = new LinearLayout(this);
            texts.setOrientation(LinearLayout.VERTICAL);
            texts.setLayoutParams(new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            TextView name = new TextView(this);
            name.setText(d.name);
            name.setTextSize(15);
            name.setTypeface(Typeface.DEFAULT_BOLD);
            name.setTextColor(Night.main);
            name.setSingleLine(true);
            name.setEllipsize(android.text.TextUtils.TruncateAt.END);
            texts.addView(name);

            TextView meta = new TextView(this);
            String pv = Docs.preview(d.file);
            meta.setText(fmt.format(new java.util.Date(d.updated))
                    + (pv.length() > 0 ? "　·　" + pv : ""));
            meta.setTextSize(11);
            meta.setTextColor(Night.sub);
            meta.setPadding(0, dp(5), 0, 0);
            meta.setSingleLine(true);
            meta.setEllipsize(android.text.TextUtils.TruncateAt.END);
            texts.addView(meta);

            row.addView(texts);

            TextView arrow = new TextView(this);
            arrow.setText("›");
            arrow.setTextSize(19);
            arrow.setTextColor(Night.faint);
            arrow.setPadding(dp(4), 0, dp(2), 0);
            row.addView(arrow);

            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent it = new Intent(ProjectActivity.this, DocActivity.class);
                    it.putExtra("dir", dir.getAbsolutePath());
                    it.putExtra("docId", d.id);
                    startActivity(it);
                }
            });
            row.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    new AlertDialog.Builder(ProjectActivity.this)
                            .setTitle(d.name)
                            .setItems(new String[]{"重命名", "删除文档"}, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    if (which == 0) askRenameDoc(d);
                                    else askDeleteDoc(d);
                                }
                            })
                            .show();
                    return true;
                }
            });
            docList.addView(row);
        }
    }

    private void askNewDoc() {
        final android.widget.EditText input = new android.widget.EditText(this);
        input.setHint("文档名称");
        input.setTextColor(Night.main);
        input.setHintTextColor(Night.faint);
        input.setSingleLine(true);
        new AlertDialog.Builder(this)
                .setTitle("新建文档")
                .setView(input)
                .setPositiveButton("创建", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String n = input.getText().toString().trim();
                        if (n.length() == 0) n = "未命名文档";
                        Docs.Doc d = Docs.create(dir, n);
                        reloadDocs();
                        Intent it = new Intent(ProjectActivity.this, DocActivity.class);
                        it.putExtra("dir", dir.getAbsolutePath());
                        it.putExtra("docId", d.id);
                        startActivity(it);
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void askRenameDoc(final Docs.Doc d) {
        final android.widget.EditText input = new android.widget.EditText(this);
        input.setText(d.name);
        input.setSelection(input.getText().length());
        input.setTextColor(Night.main);
        input.setHintTextColor(Night.faint);
        input.setSingleLine(true);
        new AlertDialog.Builder(this)
                .setTitle("重命名")
                .setView(input)
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String n = input.getText().toString().trim();
                        if (n.length() == 0) return;
                        Docs.rename(dir, d, n);
                        reloadDocs();
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void askDeleteDoc(final Docs.Doc d) {
        new AlertDialog.Builder(this)
                .setTitle("删除文档")
                .setMessage("「" + d.name + "」会移到回收站，可随时恢复。")
                .setPositiveButton("删除", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Trash.moveDoc(dir, d);
                        reloadDocs();
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void setSelecting(boolean on) {
        selecting = on;
        if (!on) selected.clear();
        if (selectBar != null) selectBar.setVisibility(on ? View.VISIBLE : View.GONE);
        if (actExport != null) actExport.setVisibility(on ? View.GONE : View.VISIBLE);
        if (actSelect != null) actSelect.setVisibility(on ? View.GONE : View.VISIBLE);
        if (photoBtnBar != null) photoBtnBar.setVisibility(on ? View.GONE : View.VISIBLE);
        else if (shootBtn != null) shootBtn.setVisibility(on ? View.GONE : View.VISIBLE);
        updateSelectBar();
        if (adapter != null) adapter.notifyDataSetChanged();
    }

    private void updateSelectBar() {
        if (selDelete != null) selDelete.setText("删除 (" + selected.size() + ")");
    }

    private void askDeleteSelected() {
        if (selected.isEmpty()) {
            Toast.makeText(this, "先选几张要删的照片", Toast.LENGTH_SHORT).show();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("删除 " + selected.size() + " 张照片")
                .setMessage("照片会移到回收站，可随时恢复。")
                .setPositiveButton("删除", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        for (File f : new java.util.ArrayList<>(selected)) {
                            Trash.movePhoto(dir, f);
                            Notes.remove(dir, f);
                        }
                        selected.clear();
                        setSelecting(false);
                        reload();
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    /** 批量导出到系统相册（App 内存储不变，属于主动复制出来） */
    /** 导出项目：美化版选项面板 */
    private void askExport() {
        final int docCount = Docs.list(dir).size();

        final String[] titles = new String[]{
                "打包 ZIP", "单文件 HTML", "合成 PDF", "导出照片到相册"
        };
        final String[] descs = new String[]{
                "照片原图 + 文档网页，解压即看，无损存档",
                "一个文件看全部，微信/QQ 直接发",
                "照片 + 文档合成一份，方便发送与打印",
                "只把 JPG 复制到系统相册 Pictures/分类相机"
        };
        final String[] badges = new String[]{"ZIP", "HTML", "PDF", "JPG"};
        final int[] tints = new int[]{0xFF2F6BFF, 0xFF1FA97D, 0xFFE3574F, 0xFFE59A1E};

        FrameLayout wrap = new FrameLayout(this);
        wrap.setPadding(dp(18), dp(24), dp(18), dp(24));

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(rounded(Night.card, 22));
        card.setPadding(0, dp(18), 0, dp(10));

        TextView title = new TextView(this);
        title.setText("导出项目");
        title.setTextSize(19);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(Night.main);
        title.setPadding(dp(20), 0, dp(20), dp(4));
        card.addView(title);

        TextView sub = new TextView(this);
        sub.setText(Store.nameOf(dir) + "　·　" + photos.size() + " 张照片　·　"
                + docCount + " 篇文档");
        sub.setTextSize(12.5f);
        sub.setTextColor(Night.sub);
        sub.setPadding(dp(20), 0, dp(20), dp(14));
        card.addView(sub);

        for (int i = 0; i < titles.length; i++) {
            final int which = i;
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(12), dp(11), dp(12), dp(11));
            row.setBackground(rowBackground(i == titles.length - 1));
            LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            rlp.leftMargin = dp(10);
            rlp.rightMargin = dp(10);
            rlp.bottomMargin = dp(4);
            row.setLayoutParams(rlp);

            // 左侧圆形徽标
            TextView badge = new TextView(this);
            badge.setText(badges[i]);
            badge.setTextSize(10.5f);
            badge.setLetterSpacing(0.04f);
            badge.setTypeface(Typeface.DEFAULT_BOLD);
            badge.setTextColor(tints[i]);
            badge.setGravity(Gravity.CENTER);
            GradientDrawable badgeBg = new GradientDrawable();
            badgeBg.setColor((tints[i] & 0x00FFFFFF) | 0x1A000000);
            badgeBg.setCornerRadius(dp(11));
            badge.setBackground(badgeBg);
            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(dp(46), dp(38));
            blp.rightMargin = dp(12);
            badge.setLayoutParams(blp);
            row.addView(badge);

            LinearLayout texts = new LinearLayout(this);
            texts.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            texts.setLayoutParams(tlp);

            TextView t = new TextView(this);
            t.setText(titles[i]);
            t.setTextSize(15);
            t.setTypeface(Typeface.DEFAULT_BOLD);
            t.setTextColor(Night.main);
            texts.addView(t);

            TextView d = new TextView(this);
            d.setText(descs[i]);
            d.setTextSize(11.5f);
            d.setTextColor(Night.sub);
            d.setPadding(0, dp(3), 0, 0);
            texts.addView(d);

            row.addView(texts);

            TextView arrow = new TextView(this);
            arrow.setText("›");
            arrow.setTextSize(20);
            arrow.setTextColor(Night.faint);
            arrow.setPadding(dp(6), 0, dp(2), 0);
            row.addView(arrow);

            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    exportDismiss();
                    if (which == 3) exportPhotosLegacy();
                    else runExport(which);
                }
            });
            card.addView(row);
        }

        TextView cancel = new TextView(this);
        cancel.setText("取消");
        cancel.setTextSize(14.5f);
        cancel.setTextColor(Night.sub);
        cancel.setGravity(Gravity.CENTER);
        cancel.setPadding(0, dp(12), 0, dp(10));
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                exportDismiss();
            }
        });
        card.addView(cancel);

        wrap.addView(card, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        exportDialog = new Dialog(this);
        exportDialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        exportDialog.setContentView(wrap);
        android.view.Window win = exportDialog.getWindow();
        if (win != null) {
            win.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0x00000000));
            win.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        exportDialog.show();
        android.view.Window w2 = exportDialog.getWindow();
        if (w2 != null) {
            w2.setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.92f),
                    ViewGroup.LayoutParams.WRAP_CONTENT);
        }
    }

    private Dialog exportDialog;

    private void exportDismiss() {
        try {
            if (exportDialog != null) exportDialog.dismiss();
        } catch (Throwable ignored) {
        }
        exportDialog = null;
    }

    /** 行背景：普通行浅灰卡片，最后一行为分隔色，点击有水波纹感 */
    private GradientDrawable rowBackground(boolean last) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(last ? (Night.dark ? 0xFF202834 : 0xFFF6F8FC) : Night.soft);
        d.setCornerRadius(dp(14));
        return d;
    }

    private void runExport(final int which) {
        final android.app.ProgressDialog pd = new android.app.ProgressDialog(this);
        pd.setMessage("正在导出…");
        pd.setCancelable(false);
        pd.show();

        new Thread(new Runnable() {
            @Override
            public void run() {
                File out = null;
                String mime = "application/zip";
                String name = "";
                try {
                    if (which == 0) {
                        out = Exporter.exportZip(ProjectActivity.this, dir);
                        mime = "application/zip";
                    } else if (which == 1) {
                        out = Exporter.exportHtml(ProjectActivity.this, dir);
                        mime = "text/html";
                    } else {
                        out = Exporter.exportPdf(ProjectActivity.this, dir);
                        mime = "application/pdf";
                    }
                    if (out != null) name = out.getName();
                } catch (Throwable t) {
                    final String msg = t.getMessage() == null
                            ? t.getClass().getSimpleName() : t.getMessage();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            pd.dismiss();
                            Toast.makeText(ProjectActivity.this, "导出失败：" + msg,
                                    Toast.LENGTH_LONG).show();
                        }
                    });
                    return;
                }

                final File res = out;
                final String resName = name;
                final String resMime = mime;
                final android.net.Uri uri = res == null ? null
                        : Exporter.publish(ProjectActivity.this, res, resMime, resName);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        pd.dismiss();
                        if (res == null || uri == null) {
                            Toast.makeText(ProjectActivity.this, "导出失败：无法写入下载目录",
                                    Toast.LENGTH_LONG).show();
                            return;
                        }
                        final android.net.Uri shareUri = uri;
                        long kb = res.length() / 1024;
                        new AlertDialog.Builder(ProjectActivity.this)
                                .setTitle("导出完成")
                                .setMessage(resName + "（" + kb + " KB）\n"
                                        + "已保存到 Download/分类相机导出/\n"
                                        + "用文件管理器或浏览器即可打开，也可以直接分享。")
                                .setPositiveButton("分享", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface d, int w) {
                                        try {
                                            Intent send = new Intent(Intent.ACTION_SEND);
                                            send.setType(resMime);
                                            send.putExtra(Intent.EXTRA_STREAM, shareUri);
                                            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                                            startActivity(Intent.createChooser(send, "分享导出文件"));
                                        } catch (Throwable t) {
                                            Toast.makeText(ProjectActivity.this, "分享失败：" + t.getMessage(),
                                                    Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                })
                                .setNegativeButton("知道了", null)
                                .show();
                    }
                });
            }
        }).start();
    }

    private void exportPhotosLegacy() {
        if (photos.isEmpty()) {
            Toast.makeText(this, "这个项目还没有照片", Toast.LENGTH_SHORT).show();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("导出 " + photos.size() + " 张照片")
                .setMessage("「" + Store.nameOf(dir) + "」的照片会复制到系统相册"
                        + "（Pictures/分类相机），App 里的原件保留。")
                .setPositiveButton("导出", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        exportAll();
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void exportAll() {
        final List<File> list = new ArrayList<>(photos);
        new Thread(new Runnable() {
            @Override
            public void run() {
                int ok = 0;
                if (Build.VERSION.SDK_INT >= 29) {
                    String folder = "Pictures/分类相机/" + safeName(Store.nameOf(dir));
                    for (File f : list) {
                        try {
                            android.content.ContentValues v = new android.content.ContentValues();
                            v.put(android.provider.MediaStore.Images.Media.DISPLAY_NAME, f.getName());
                            v.put(android.provider.MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                            v.put(android.provider.MediaStore.Images.Media.RELATIVE_PATH, folder);
                            android.net.Uri uri = getContentResolver().insert(
                                    android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
                            if (uri == null) continue;
                            java.io.OutputStream os = getContentResolver().openOutputStream(uri);
                            java.io.FileInputStream in = new java.io.FileInputStream(f);
                            byte[] buf = new byte[8192];
                            int n;
                            while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
                            in.close();
                            os.close();
                            ok++;
                        } catch (Throwable ignored) {
                        }
                    }
                }
                final int done = ok;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (done > 0) {
                            Toast.makeText(ProjectActivity.this,
                                    "已导出 " + done + " 张到 相册/Pictures/分类相机",
                                    Toast.LENGTH_LONG).show();
                        } else {
                            // 低版本或导出失败：直接多图分享
                            shareAll(list);
                        }
                    }
                });
            }
        }).start();
    }

    private String safeName(String name) {
        if (name == null || name.length() == 0) return "未命名项目";
        return name.replaceAll("[\\\\/:*?\"<>|]", "_");
    }

    private void shareAll(List<File> list) {
        try {
            ArrayList<android.net.Uri> uris = new ArrayList<>();
            for (File f : list) uris.add(PhotoProvider.uriFor(f));
            Intent send = new Intent(Intent.ACTION_SEND_MULTIPLE);
            send.setType("image/jpeg");
            send.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(send, "导出照片"));
        } catch (Throwable t) {
            Toast.makeText(this, "导出失败：" + t.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private boolean useSystemCamera() {
        return getSharedPreferences("projcam", MODE_PRIVATE)
                .getBoolean("use_system_camera", true);
    }

    /** 调系统相机拍一张：先借用 MediaStore 临时条目当输出，拍完立刻搬进项目并删掉临时条目 */
    private void shootWithSystemCamera() {
        try {
            pendingShot = Store.newPhoto(dir);
            Intent it = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
            pendingUri = null;

            if (Build.VERSION.SDK_INT >= 29) {
                // 走 MediaStore：厂商相机对自家媒体库的输出最配合，不容易写出空文件/坏文件
                android.content.ContentValues v = new android.content.ContentValues();
                v.put(android.provider.MediaStore.Images.Media.DISPLAY_NAME,
                        "projcam_tmp_" + System.currentTimeMillis() + ".jpg");
                v.put(android.provider.MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                v.put(android.provider.MediaStore.Images.Media.RELATIVE_PATH,
                        "DCIM/.projcam_tmp");
                // 注意：不能设 IS_PENDING=1，一加/OPPO 相机会认为目标不可写而直接不拍
                pendingUri = getContentResolver().insert(
                        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            }
            if (pendingUri == null) {
                pendingUri = PhotoProvider.uriFor(pendingShot);
            }

            it.putExtra(android.provider.MediaStore.EXTRA_OUTPUT, pendingUri);
            it.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);

            if (it.resolveActivity(getPackageManager()) == null) {
                startInnerCamera();
                return;
            }
            startActivityForResult(it, REQ_SYS_CAMERA);
        } catch (Throwable t) {
            Toast.makeText(this, "调不起系统相机：" + t.getMessage(), Toast.LENGTH_SHORT).show();
            pendingShot = null;
            pendingUri = null;
        }
    }

    /** 从系统相册（或文件）里选照片导入项目，支持多选 */
    private void pickFromGallery() {
        try {
            Intent it = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            it.addCategory(Intent.CATEGORY_OPENABLE);
            it.setType("image/*");
            it.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            it.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(Intent.createChooser(it, "选择要导入的照片"), REQ_IMPORT);
        } catch (Throwable t) {
            Toast.makeText(this, "打不开相册：" + t.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void importFrom(Uri src) {
        if (src == null) return;
        Map<String, Uri> uris = new LinkedHashMap<>();
        android.content.ClipData clip = null;
        if (importClip != null) clip = importClip;
        if (clip != null && clip.getItemCount() > 1) {
            for (int i = 0; i < clip.getItemCount(); i++) {
                Uri u = clip.getItemAt(i).getUri();
                if (u != null) uris.put(u.toString(), u);
            }
        } else {
            uris.put(src.toString(), src);
        }
        importClip = null;

        final List<Uri> list = new ArrayList<>(uris.values());
        final android.app.ProgressDialog pd = new android.app.ProgressDialog(this);
        pd.setMessage("正在导入 " + list.size() + " 张…");
        pd.setCancelable(false);
        pd.show();

        new Thread(new Runnable() {
            @Override
            public void run() {
                int ok = 0;
                File last = null;
                for (int i = 0; i < list.size(); i++) {
                    File out = new File(dir, "img_" + System.currentTimeMillis() + "_" + i + ".jpg");
                    try {
                        java.io.InputStream in = getContentResolver().openInputStream(list.get(i));
                        if (in == null) continue;
                        java.io.FileOutputStream fos = new java.io.FileOutputStream(out);
                        byte[] buf = new byte[8192];
                        int n;
                        while ((n = in.read(buf)) > 0) fos.write(buf, 0, n);
                        in.close();
                        fos.close();
                        // 校验能否解码，坏文件直接丢掉
                        android.graphics.BitmapFactory.Options bo = new android.graphics.BitmapFactory.Options();
                        bo.inJustDecodeBounds = true;
                        android.graphics.BitmapFactory.decodeFile(out.getAbsolutePath(), bo);
                        if (bo.outWidth <= 0) {
                            //noinspection ResultOfMethodCallIgnored
                            out.delete();
                            continue;
                        }
                        ok++;
                        last = out;
                    } catch (Throwable t) {
                        //noinspection ResultOfMethodCallIgnored
                        out.delete();
                    }
                }
                final int done = ok;
                final File lastFile = last;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        pd.dismiss();
                        reload();
                        if (done == 0) {
                            Toast.makeText(ProjectActivity.this, "导入失败：这些文件无法读取",
                                    Toast.LENGTH_LONG).show();
                        } else {
                            Toast.makeText(ProjectActivity.this, "已导入 " + done + " 张照片",
                                    Toast.LENGTH_SHORT).show();
                            if (done == 1 && lastFile != null) askQuickNote(lastFile);
                        }
                    }
                });
            }
        }).start();
    }

    private android.content.ClipData importClip;

    private void startInnerCamera() {
        cameraCountBefore = photos.size();
        Intent inner = new Intent(ProjectActivity.this, CameraActivity.class);
        inner.putExtra("dir", dir.getAbsolutePath());
        startActivity(inner);
    }

    private int cameraCountBefore = -1;

    /** 拍完一张立刻问一句备注，可跳过 */
    private void askQuickNote(final File photo) {
        final android.widget.EditText edit = new android.widget.EditText(this);
        edit.setSingleLine(true);
        String old = Notes.get(dir, photo);
        if (old.length() > 0) {
            edit.setText(old);
            edit.setSelection(old.length());
        }
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(dp(20), dp(10), dp(20), dp(2));
        wrap.addView(edit, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        new AlertDialog.Builder(this)
                .setTitle("给这张照片加个备注")
                .setView(wrap)
                .setPositiveButton("保存", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        Notes.set(dir, photo, edit.getText().toString());
                        reload();
                        Toast.makeText(ProjectActivity.this, "备注已保存", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("跳过", null)
                .show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, final Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_IMPORT) {
            android.content.ClipData clip = data == null ? null : data.getClipData();
            Uri single = data == null ? null : data.getData();
            importClip = clip;
            importFrom(single);
            return;
        }
        if (requestCode != REQ_SYS_CAMERA) return;

        final File target = pendingShot;
        final android.net.Uri src = pendingUri;
        pendingShot = null;
        pendingUri = null;

        if (src == null || target == null) {
            Toast.makeText(this, "系统相机没有返回可用的输出，请重试", Toast.LENGTH_SHORT).show();
            return;
        }

        new Thread(new Runnable() {
            @Override
            public void run() {
                boolean ok = copyToProject(src, target);
                cleanupTemp(src);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (ok) {
                            Toast.makeText(ProjectActivity.this, "已保存到项目",
                                    Toast.LENGTH_SHORT).show();
                            reload();
                            askQuickNote(target);
                        } else {
                            // 相机什么都没写：看看有没有回传缩略图可以救
                            boolean saved = false;
                            if (data != null) {
                                Object extra = data.getParcelableExtra("data");
                                if (extra instanceof android.graphics.Bitmap) {
                                    try {
                                        java.io.FileOutputStream fos = new java.io.FileOutputStream(target);
                                        ((android.graphics.Bitmap) extra)
                                                .compress(android.graphics.Bitmap.CompressFormat.JPEG, 92, fos);
                                        fos.close();
                                        saved = target.length() > 0;
                                    } catch (Throwable ignored) {
                                    }
                                }
                            }
                            if (saved) {
                                Toast.makeText(ProjectActivity.this,
                                        "已保存到项目（该相机只回传了小图）", Toast.LENGTH_LONG).show();
                            } else {
                                if (target.exists()) target.delete();
                                Toast.makeText(ProjectActivity.this,
                                        "系统相机没有写出照片，已切到 App 内相机",
                                        Toast.LENGTH_LONG).show();
                                startInnerCamera();
                            }
                        }
                        reload();
                    }
                });
            }
        }).start();
    }

    /** 把相机写出的内容搬进项目目录，并确认它真能解码成画面 */
    private boolean copyToProject(android.net.Uri src, File target) {
        try {
            java.io.InputStream in = getContentResolver().openInputStream(src);
            if (in == null) return false;
            java.io.FileOutputStream out = new java.io.FileOutputStream(target);
            byte[] buf = new byte[8192];
            int n;
            long total = 0;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
                total += n;
            }
            out.close();
            in.close();
            if (total < 1024) return false;

            // 有些相机输出 HEIF/HEVC 却挂在 .jpg 上，先按图片通用方式转成标准 JPEG
            if (!isJpeg(target)) {
                if (!transcodeToJpeg(target)) return false;
            }
            // 真正解码一次，确认不是坏图/全黑占位
            android.graphics.BitmapFactory.Options o = new android.graphics.BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            android.graphics.BitmapFactory.decodeFile(target.getAbsolutePath(), o);
            return o.outWidth > 0 && o.outHeight > 0;
        } catch (Throwable t) {
            return false;
        }
    }

    private boolean isJpeg(File f) {
        try {
            java.io.FileInputStream in = new java.io.FileInputStream(f);
            byte[] head = new byte[3];
            int n = in.read(head);
            in.close();
            return n == 3 && (head[0] & 0xFF) == 0xFF && (head[1] & 0xFF) == 0xD8
                    && (head[2] & 0xFF) == 0xFF;
        } catch (Throwable t) {
            return false;
        }
    }

    /** 用系统解码器把 HEIF 等格式重新编码成 JPEG（API 28+） */
    private boolean transcodeToJpeg(File f) {
        if (Build.VERSION.SDK_INT < 28) return false;
        try {
            android.graphics.Bitmap bmp = null;
            if (Build.VERSION.SDK_INT >= 28) {
                android.graphics.ImageDecoder.Source s = android.graphics.ImageDecoder.createSource(f);
                bmp = android.graphics.ImageDecoder.decodeBitmap(s);
            }
            if (bmp == null) {
                bmp = android.graphics.BitmapFactory.decodeFile(f.getAbsolutePath());
            }
            if (bmp == null || bmp.getWidth() <= 0) return false;
            java.io.FileOutputStream out = new java.io.FileOutputStream(f);
            bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 95, out);
            out.close();
            bmp.recycle();
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    /** 删掉借用的 MediaStore 临时条目，让照片只留在项目里 */
    private void cleanupTemp(android.net.Uri uri) {
        if (uri == null) return;
        if (!"content".equals(uri.getScheme())) return;
        try {
            getContentResolver().delete(uri, null, null);
        } catch (Throwable ignored) {
        }
    }

    private void reload() {
        photos.clear();
        photos.addAll(Store.photos(dir));
        newestFirst = getSharedPreferences("projcam", MODE_PRIVATE)
                .getBoolean("newest_first", true);
        java.util.Collections.sort(photos, new java.util.Comparator<File>() {
            @Override
            public int compare(File a, File b) {
                int r = Long.compare(a.lastModified(), b.lastModified());
                if (r == 0) r = a.getName().compareTo(b.getName());
                return newestFirst ? -r : r;
            }
        });
        if (adapter != null) adapter.notifyDataSetChanged();
        if (countText != null) countText.setText(photos.isEmpty() ? " 空" : " " + photos.size() + " 张");
    }

    private class ThumbAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return photos.size();
        }

        @Override
        public Object getItem(int position) {
            return photos.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            int size = (getResources().getDisplayMetrics().widthPixels - dp(16) * 2 - dp(8)) / 3;
            Holder h;
            if (convertView == null) {
                FrameLayout cell = new FrameLayout(ProjectActivity.this);
                cell.setLayoutParams(new GridView.LayoutParams(size, size));

                ImageView iv = new ImageView(ProjectActivity.this);
                iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
                iv.setLayoutParams(new FrameLayout.LayoutParams(size, size));
                iv.setBackground(rounded(Night.dark ? 0xFF232B36 : 0xFFEDF1F7, 10));
                cell.addView(iv);

                TextView time = new TextView(ProjectActivity.this);
                time.setTextSize(9);
                time.setTextColor(0xFFFFFFFF);
                time.setBackground(rounded(0x99000000, 4));
                time.setPadding(dp(4), dp(1), dp(4), dp(1));
                FrameLayout.LayoutParams tmlp = new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                        Gravity.BOTTOM | Gravity.START);
                tmlp.leftMargin = dp(4);
                tmlp.bottomMargin = dp(4);
                time.setLayoutParams(tmlp);
                cell.addView(time);

                TextView note = new TextView(ProjectActivity.this);
                note.setTextSize(10);
                note.setTextColor(0xFFFFFFFF);
                note.setMaxLines(2);
                note.setEllipsize(android.text.TextUtils.TruncateAt.END);
                note.setLineSpacing(0, 0.95f);
                note.setGravity(Gravity.BOTTOM | Gravity.START);
                note.setPadding(dp(5), dp(3), dp(5), dp(4));
                note.setBackground(rounded(0xD9000000, 8));
                FrameLayout.LayoutParams nlp = new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
                nlp.leftMargin = dp(3);
                nlp.rightMargin = dp(3);
                nlp.bottomMargin = dp(3);
                note.setLayoutParams(nlp);
                note.setVisibility(View.GONE);
                cell.addView(note);

                View veil = new View(ProjectActivity.this);
                veil.setBackgroundColor(0x332F6BFF);
                veil.setLayoutParams(new FrameLayout.LayoutParams(size, size));
                veil.setVisibility(View.GONE);
                cell.addView(veil);

                TextView tick = new TextView(ProjectActivity.this);
                tick.setText("✓");
                tick.setTextSize(12);
                tick.setTextColor(0xFFFFFFFF);
                tick.setGravity(Gravity.CENTER);
                FrameLayout.LayoutParams tlp = new FrameLayout.LayoutParams(dp(20), dp(20),
                        Gravity.TOP | Gravity.END);
                tlp.rightMargin = dp(4);
                tlp.topMargin = dp(4);
                tick.setLayoutParams(tlp);
                tick.setVisibility(View.GONE);
                cell.addView(tick);

                h = new Holder();
                h.img = iv;
                h.time = time;
                h.note = note;
                h.veil = veil;
                h.tick = tick;
                h.size = size;
                cell.setTag(h);
                convertView = cell;
            } else {
                h = (Holder) convertView.getTag();
            }

            File f = photos.get(position);
            h.img.setImageBitmap(thumb(f, h.size));
            h.time.setText(timeLabel(f));
            h.time.setVisibility(View.VISIBLE);
            String nt = Notes.get(dir, f);
            if (nt.length() > 0) {
                h.note.setText(nt);
                h.note.setVisibility(View.VISIBLE);
                h.time.setVisibility(View.GONE);   // 有备注时底部让给备注
            } else {
                h.note.setVisibility(View.GONE);
                h.time.setVisibility(View.VISIBLE);
                h.time.setText(timeLabel(f));
            }
            bindSelection(h, selecting && selected.contains(f), selecting);
            return convertView;
        }

        private void bindSelection(Holder h, boolean on, boolean showTick) {
            h.tick.setVisibility(showTick ? View.VISIBLE : View.GONE);
            h.tick.setBackground(on ? rounded(Night.accent, 9) : rounded(0x66000000, 9));
            h.veil.setVisibility(on ? View.VISIBLE : View.GONE);
        }

        void refreshCell(int index) {
            int child = index - grid.getFirstVisiblePosition();
            View v = grid.getChildAt(child);
            if (v != null && v.getTag() instanceof Holder) {
                Holder h = (Holder) v.getTag();
                File f = photos.get(index);
                bindSelection(h, selecting && selected.contains(f), selecting);
            }
        }
    }

    private static class Holder {
        ImageView img;
        TextView time;
        TextView note;
        View veil;
        TextView tick;
        int size;
    }

    /** 拍摄时间标签：当天只显示时分，跨天显示月-日+时分 */
    private String timeLabel(File f) {
        java.util.Calendar c = java.util.Calendar.getInstance();
        c.setTimeInMillis(f.lastModified());
        java.util.Calendar now = java.util.Calendar.getInstance();
        boolean sameDay = c.get(java.util.Calendar.YEAR) == now.get(java.util.Calendar.YEAR)
                && c.get(java.util.Calendar.DAY_OF_YEAR) == now.get(java.util.Calendar.DAY_OF_YEAR);
        String hm = String.format("%02d:%02d", c.get(java.util.Calendar.HOUR_OF_DAY),
                c.get(java.util.Calendar.MINUTE));
        if (sameDay) return hm;
        return (c.get(java.util.Calendar.MONTH) + 1) + "-" + c.get(java.util.Calendar.DAY_OF_MONTH)
                + " " + hm;
    }

    /** 缩略图缓存：同一张图不重复解码，避免滑动时卡顿 */
    private static android.util.LruCache<String, android.graphics.Bitmap> thumbCache;

    private android.graphics.Bitmap thumb(File f, int size) {
        if (thumbCache == null) {
            int max = (int) (Runtime.getRuntime().maxMemory() / 8);
            thumbCache = new android.util.LruCache<String, android.graphics.Bitmap>(max) {
                @Override
                protected int sizeOf(String key, android.graphics.Bitmap value) {
                    return value.getByteCount();
                }
            };
        }
        String key = f.getAbsolutePath() + "#" + size;
        android.graphics.Bitmap b = thumbCache.get(key);
        if (b != null) return b;
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(f.getAbsolutePath(), o);
            int sample = 1;
            int min = Math.min(o.outWidth, o.outHeight);
            while (min / sample > size * 1.4f) sample *= 2;

            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            b = BitmapFactory.decodeFile(f.getAbsolutePath(), o2);
            if (b != null) {
                android.graphics.Bitmap scaled = android.graphics.Bitmap.createScaledBitmap(b, size, size, true);
                if (scaled != b) b.recycle();
                b = scaled;
                thumbCache.put(key, b);
            }
        } catch (Throwable ignored) {
        }
        return b;
    }

    /** 全屏查看：双指缩放、双击放大、左右滑动切换、备注 / 分享 / 删除 */
    private void showPhoto(File start) {
        int index = photos.indexOf(start);
        if (index < 0) index = 0;
        openViewer(index);
    }

    private void openViewer(final int startIndex) {
        if (photos.isEmpty()) return;
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        FrameLayout page = new FrameLayout(this);
        page.setBackgroundColor(0xFF000000);

        final ZoomImageView ziv = new ZoomImageView(this);
        page.addView(ziv, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        final int[] cur = {Math.max(0, Math.min(photos.size() - 1, startIndex))};

        final TextView counter = new TextView(this);
        counter.setTextSize(12);
        counter.setTextColor(0xFFFFFFFF);
        counter.setBackground(rounded(0x99000000, 8));
        counter.setPadding(dp(8), dp(4), dp(8), dp(4));
        FrameLayout.LayoutParams clp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.END);
        clp.topMargin = dp(36);
        clp.rightMargin = dp(16);
        page.addView(counter, clp);

        final TextView noteView = new TextView(this);
        noteView.setTextSize(13);
        noteView.setTextColor(0xFFFFFFFF);
        noteView.setBackgroundColor(0xCC000000);
        noteView.setPadding(dp(16), dp(10), dp(16), dp(10));
        FrameLayout.LayoutParams nlp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM);
        nlp.bottomMargin = dp(120);
        page.addView(noteView, nlp);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER);
        actions.setPadding(0, 0, 0, dp(14));
        FrameLayout.LayoutParams alp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
        page.addView(actions, alp);

        final Runnable bind = new Runnable() {
            @Override
            public void run() {
                File f = photos.get(cur[0]);
                ziv.setBitmap(loadForView(f));
                String note = Notes.get(dir, f);
                noteView.setText(note);
                noteView.setVisibility(note.length() > 0 ? View.VISIBLE : View.GONE);
                counter.setText((cur[0] + 1) + " / " + photos.size());
            }
        };
        bind.run();

        ziv.setOnSwipeListener(new ZoomImageView.OnSwipeListener() {
            @Override
            public void onSwipeLeft() {
                if (cur[0] < photos.size() - 1) {
                    cur[0]++;
                    bind.run();
                }
            }

            @Override
            public void onSwipeRight() {
                if (cur[0] > 0) {
                    cur[0]--;
                    bind.run();
                }
            }
        });

        // 底部操作条：半透明胶囊，三格等宽，图标 + 文字
        actions.setPadding(dp(30), 0, dp(30), dp(52));
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER);
        GradientDrawable barBg = new GradientDrawable();
        barBg.setColor(0x0DFFFFFF);
        barBg.setCornerRadius(dp(26));
        bar.setBackground(barBg);
        LinearLayout.LayoutParams blp2 = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
        bar.setLayoutParams(blp2);
        actions.addView(bar);

        final String[] glyphs = new String[]{"✎", "⤴", "✕"};
        final String[] labels = new String[]{"备注", "分享", "删除"};
        final int[] colors = new int[]{0xFFFFFFFF, 0xFFFFFFFF, 0xFFFF9A92};
        final TextView[] btns = new TextView[3];

        for (int i = 0; i < 3; i++) {
            final int which = i;
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER);
            cell.setLayoutParams(new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.MATCH_PARENT, 1f));
            GradientDrawable cellBg = new GradientDrawable();
            cellBg.setColor(0x00000000);
            cell.setBackground(cellBg);

            TextView icon = new TextView(this);
            icon.setText(glyphs[i] + "  " + labels[i]);
            icon.setTextSize(14);
            icon.setTextColor(colors[i]);
            icon.setShadowLayer(dp(3), 0, dp(1), 0x8A000000);
            icon.setGravity(Gravity.CENTER);
            cell.addView(icon);

            if (i > 0) {
                TextView div = new TextView(this);
                div.setLayoutParams(new LinearLayout.LayoutParams(dp(1),
                        ViewGroup.LayoutParams.MATCH_PARENT));
                div.setBackgroundColor(0x1AFFFFFF);
                bar.addView(div);
            }
            bar.addView(cell);

            cell.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    File f = photos.get(cur[0]);
                    if (which == 0) {
                        askNote(f, noteView);
                    } else if (which == 1) {
                        sharePhoto(f);
                    } else {
                        dialog.dismiss();
                        askDelete(f);
                    }
                }
            });
            btns[i] = icon;
        }



        TextView close = new TextView(this);
        close.setText("关闭");
        close.setTextSize(14);
        close.setTextColor(0xFF96A0B0);
        close.setPadding(dp(18), dp(10), dp(18), dp(10));
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        actions.addView(close);

        // 左右半屏点击也能翻页（手指不方便滑动时）
        dialog.setContentView(page);
        Window w = dialog.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(0xFF000000));
            w.setLayout(WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT);
        }
        dialog.show();
    }

    /** 查看页用更大的采样但仍在后台解码 */
    private android.graphics.Bitmap loadForView(File f) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(f.getAbsolutePath(), o);
            int max = Math.max(getResources().getDisplayMetrics().widthPixels,
                    getResources().getDisplayMetrics().heightPixels) * 2;
            int sample = 1;
            int big = Math.max(o.outWidth, o.outHeight);
            while (big / sample > max) sample *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            return BitmapFactory.decodeFile(f.getAbsolutePath(), o2);
        } catch (Throwable t) {
            return null;
        }
    }

    /** 编辑这张照片的备注 */
    private void askNote(final File f, final TextView noteView) {
        final android.widget.EditText edit = new android.widget.EditText(this);
        edit.setText(Notes.get(dir, f));
        edit.setSelection(edit.getText().length());
        edit.setMinLines(2);
        LinearLayout wrap = new LinearLayout(this);
        wrap.setPadding(dp(20), dp(6), dp(20), dp(2));
        wrap.addView(edit, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        new AlertDialog.Builder(this)
                .setTitle("照片备注")
                .setView(wrap)
                .setPositiveButton("保存", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        String text = edit.getText().toString();
                        Notes.set(dir, f, text);
                        String saved = Notes.get(dir, f);
                        noteView.setText(saved);
                        noteView.setVisibility(saved.length() > 0 ? View.VISIBLE : View.GONE);
                        if (adapter != null) adapter.notifyDataSetChanged();
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void sharePhoto(File f) {
        try {
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("image/jpeg");
            send.putExtra(Intent.EXTRA_STREAM, PhotoProvider.uriFor(f));
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(send, "分享照片"));
        } catch (Throwable t) {
            Toast.makeText(this, "分享失败：" + t, Toast.LENGTH_SHORT).show();
        }
    }

    private void askDelete(final File f) {
        new AlertDialog.Builder(this)
                .setTitle("删除这张照片")
                .setMessage("照片会移到回收站，可随时恢复。")
                .setPositiveButton("删除", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        Trash.movePhoto(dir, f);
                        Notes.remove(dir, f);
                        reload();
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }
}
