package com.example.projcam;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashSet;
import java.util.Set;

/** 置顶标记：用 SharedPreferences 里的字符串集合保存，不污染项目目录 */
final class Pins {

    private static SharedPreferences sp(Context c) {
        return c.getSharedPreferences("projcam", Context.MODE_PRIVATE);
    }

    private static String key(String scope) {
        return "pin_" + scope;
    }

    static boolean has(Context c, String scope, String item) {
        Set<String> s = sp(c).getStringSet(key(scope), null);
        return s != null && s.contains(item);
    }

    static void set(Context c, String scope, String item, boolean on) {
        Set<String> cur = sp(c).getStringSet(key(scope), null);
        Set<String> next = cur == null ? new HashSet<String>() : new HashSet<String>(cur);
        if (on) next.add(item);
        else next.remove(item);
        sp(c).edit().putStringSet(key(scope), next).apply();
    }

    static int count(Context c, String scope) {
        Set<String> s = sp(c).getStringSet(key(scope), null);
        return s == null ? 0 : s.size();
    }

    // 作用域
    static String projectScope() {
        return "projects";
    }

    static String photoScope(String dirName) {
        return "photo:" + dirName;
    }

    static String docScope(String dirName) {
        return "doc:" + dirName;
    }
}
