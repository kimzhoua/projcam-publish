package com.example.projcam;

import android.content.Context;

/** 夜间模式调色板 */
final class Night {

    static boolean dark;
    static int page, card, main, sub, faint, soft, accent, hair, danger;

    static void init(Context c) {
        int mode = c.getSharedPreferences("projcam", Context.MODE_PRIVATE).getInt("night_mode", 0);
        boolean sys = (c.getResources().getConfiguration().uiMode
                & android.content.res.Configuration.UI_MODE_NIGHT_MASK)
                == android.content.res.Configuration.UI_MODE_NIGHT_YES;
        dark = mode == 2 || (mode == 0 && sys);
        if (dark) {
            page = 0xFF0E1218;
            card = 0xFF1A2028;
            main = 0xFFE8ECF3;
            sub = 0xFF96A0B0;
            faint = 0xFF8C97A8;
            soft = 0xFF232B36;
            accent = 0xFF7FA5FF;
            hair = 0xFF2E3A47;
            danger = 0xFFFF7B72;
        } else {
            page = 0xFFF6F7FB;
            card = 0xFFFFFFFF;
            main = 0xFF1B2230;
            sub = 0xFF6B7482;
            faint = 0xFF98A0AE;
            soft = 0xFFF3F5FA;
            accent = 0xFF2F6BFF;
            hair = 0xFFE3E8F2;
            danger = 0xFFE0455E;
        }
    }
}
