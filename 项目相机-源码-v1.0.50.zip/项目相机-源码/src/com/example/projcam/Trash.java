package com.example.projcam;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** 回收站：删除的照片 / 文档先移动到这里，永久保留，可随时恢复 */
final class Trash {

    static final class Item {
        String id;
        String type;   // photo / doc
        String name;   // 原文件名或文档名
        String stored; // 回收站里的文件名
        long deletedAt;
    }

    static File dirOf(File project) {
        File d = new File(project, "trash");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    private static File metaFile(File project) {
        return new File(dirOf(project), "meta.json");
    }

    private static JSONArray readMeta(File project) {
        File f = metaFile(project);
        if (!f.exists()) return new JSONArray();
        try {
            java.io.BufferedReader r = new java.io.BufferedReader(
                    new java.io.InputStreamReader(new java.io.FileInputStream(f), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
            r.close();
            return new JSONArray(sb.toString());
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    private static void writeMeta(File project, JSONArray arr) {
        try {
            FileOutputStream out = new FileOutputStream(metaFile(project));
            out.write(arr.toString().getBytes("UTF-8"));
            out.close();
        } catch (Exception ignored) {
        }
    }

    static List<Item> list(File project) {
        List<Item> out = new ArrayList<>();
        JSONArray arr = readMeta(project);
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            Item it = new Item();
            it.id = o.optString("id");
            it.type = o.optString("type");
            it.name = o.optString("name");
            it.stored = o.optString("stored");
            it.deletedAt = o.optLong("deletedAt");
            File f = new File(dirOf(project), it.stored);
            if (f.exists()) out.add(it);
        }
        Collections.sort(out, new Comparator<Item>() {
            @Override
            public int compare(Item a, Item b) {
                return Long.compare(b.deletedAt, a.deletedAt);
            }
        });
        return out;
    }

    private static String uniqueStored(File dir, String name) {
        String n = name;
        int i = 1;
        while (new File(dir, n).exists()) {
            int dot = name.lastIndexOf('.');
            n = (dot > 0 ? name.substring(0, dot) : name) + "_" + i
                    + (dot > 0 ? name.substring(dot) : "");
            i++;
        }
        return n;
    }

    private static void addEntry(File project, Item it) {
        JSONArray arr = readMeta(project);
        JSONObject o = new JSONObject();
        try {
            o.put("id", it.id);
            o.put("type", it.type);
            o.put("name", it.name);
            o.put("stored", it.stored);
            o.put("deletedAt", it.deletedAt);
            arr.put(o);
        } catch (Exception ignored) {
        }
        writeMeta(project, arr);
    }

    static void movePhoto(File project, File photo) {
        File dir = dirOf(project);
        String stored = uniqueStored(dir, photo.getName());
        File target = new File(dir, stored);
        if (!photo.renameTo(target)) {
            try {
                copy(photo, target);
                //noinspection ResultOfMethodCallIgnored
                photo.delete();
            } catch (Exception e) {
                return;
            }
        }
        Item it = new Item();
        it.id = "t_" + System.currentTimeMillis() + "_" + (int) (Math.random() * 1000);
        it.type = "photo";
        it.name = photo.getName();
        it.stored = stored;
        it.deletedAt = System.currentTimeMillis();
        addEntry(project, it);
    }

    static void moveDoc(File project, Docs.Doc doc) {
        File dir = dirOf(project);
        String stored = uniqueStored(dir, doc.file.getName());
        File target = new File(dir, stored);
        if (!doc.file.renameTo(target)) {
            try {
                copy(doc.file, target);
                //noinspection ResultOfMethodCallIgnored
                doc.file.delete();
            } catch (Exception e) {
                return;
            }
        }
        Docs.removeEntry(project, doc);
        Item it = new Item();
        it.id = "t_" + System.currentTimeMillis() + "_" + (int) (Math.random() * 1000);
        it.type = "doc";
        it.name = doc.name;
        it.stored = stored;
        it.deletedAt = System.currentTimeMillis();
        addEntry(project, it);
    }

    static boolean restore(File project, Item it) {
        File src = new File(dirOf(project), it.stored);
        if (!src.exists()) return false;
        if ("doc".equals(it.type)) {
            String docId = it.stored;
            if (docId.endsWith(".html")) docId = docId.substring(0, docId.length() - 5);
            File docsDir = Docs.dirOf(project);
            File dst = new File(docsDir, it.stored);
            if (!src.renameTo(dst)) {
                try {
                    copy(src, dst);
                    //noinspection ResultOfMethodCallIgnored
                    src.delete();
                } catch (Exception e) {
                    return false;
                }
            }
            Docs.addEntry(project, docId, it.name);
        } else {
            File dst = new File(project, it.name);
            if (dst.exists()) {
                int dot = it.name.lastIndexOf('.');
                dst = new File(project, (dot > 0 ? it.name.substring(0, dot) : it.name)
                        + "_" + System.currentTimeMillis() % 100000
                        + (dot > 0 ? it.name.substring(dot) : ""));
            }
            if (!src.renameTo(dst)) {
                try {
                    copy(src, dst);
                    //noinspection ResultOfMethodCallIgnored
                    src.delete();
                } catch (Exception e) {
                    return false;
                }
            }
        }
        removeEntry(project, it);
        return true;
    }

    static void purge(File project, Item it) {
        File f = new File(dirOf(project), it.stored);
        if (f.exists()) //noinspection ResultOfMethodCallIgnored
            f.delete();
        removeEntry(project, it);
    }

    private static void removeEntry(File project, Item it) {
        JSONArray arr = readMeta(project);
        JSONArray keep = new JSONArray();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            if (it.id.equals(o.optString("id"))) continue;
            keep.put(o);
        }
        writeMeta(project, keep);
    }

    static void clear(File project) {
        File[] fs = dirOf(project).listFiles();
        if (fs != null) for (File f : fs) {
            //noinspection ResultOfMethodCallIgnored
            f.delete();
        }
        writeMeta(project, new JSONArray());
    }

    private static void copy(File src, File dst) throws Exception {
        FileInputStream in = new FileInputStream(src);
        FileOutputStream out = new FileOutputStream(dst);
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        in.close();
        out.close();
    }
}
