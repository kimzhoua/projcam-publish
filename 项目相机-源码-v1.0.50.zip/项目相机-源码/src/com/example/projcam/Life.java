package com.example.projcam;

import android.os.Handler;
import android.os.Looper;

/** 记录 App 是否真的到了后台（页面之间切换不算），用于指纹锁只在退出 App 后才重新验证 */
final class Life {

    private static int count;
    private static boolean background = true;
    private static boolean back;

    /** 从后台回到前台，需要重新验证指纹（由主页负责弹指纹） */
    static boolean pending;

    static void onResume() {
        if (background) {
            background = false;
            back = true;
            pending = true;
        }
        count++;
    }

    static void onPause() {
        count--;
        if (count <= 0) {
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (count <= 0) background = true;
                }
            }, 300);
        }
    }

    /** 是否是「从后台真正回到 App」（页面互跳不算） */
    static boolean consumeBack() {
        boolean b = back;
        back = false;
        return b;
    }
}
