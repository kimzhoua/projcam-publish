package com.example.projcam;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** 项目文档仓库：每个项目下 docs/ 目录，doc_<毫秒>.html + meta.json */
final class Docs {

    static final class Doc {
        File file;
        String id;
        String name;
        long updated;
    }

    static File dirOf(File project) {
        File d = new File(project, "docs");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    private static File metaFile(File project) {
        return new File(dirOf(project), "meta.json");
    }

    static List<Doc> list(File project) {
        List<Doc> out = new ArrayList<>();
        JSONArray arr = readMeta(project);
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            Doc d = new Doc();
            d.id = o.optString("id");
            d.name = o.optString("name");
            d.updated = o.optLong("updated");
            d.file = new File(dirOf(project), d.id + ".html");
            if (d.file.exists()) out.add(d);
        }
        Collections.sort(out, new Comparator<Doc>() {
            @Override
            public int compare(Doc a, Doc b) {
                return Long.compare(b.updated, a.updated);
            }
        });
        return out;
    }

    private static JSONArray readMeta(File project) {
        File f = metaFile(project);
        if (!f.exists()) return new JSONArray();
        try {
            java.io.BufferedReader r = new java.io.BufferedReader(
                    new java.io.InputStreamReader(new java.io.FileInputStream(f), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
            r.close();
            return new JSONArray(sb.toString());
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    private static void writeMeta(File project, JSONArray arr) {
        try {
            FileOutputStream out = new FileOutputStream(metaFile(project));
            out.write(arr.toString().getBytes("UTF-8"));
            out.close();
        } catch (Exception ignored) {
        }
    }

    static Doc create(File project, String name) {
        Doc d = new Doc();
        d.id = "doc_" + System.currentTimeMillis();
        d.name = name;
        d.updated = System.currentTimeMillis();
        d.file = new File(dirOf(project), d.id + ".html");
        write(d.file, "");
        JSONArray arr = readMeta(project);
        JSONObject o = new JSONObject();
        try {
            o.put("id", d.id);
            o.put("name", d.name);
            o.put("updated", d.updated);
            arr.put(o);
        } catch (Exception ignored) {
        }
        writeMeta(project, arr);
        return d;
    }

    static void touch(File project, Doc doc) {
        doc.updated = System.currentTimeMillis();
        JSONArray arr = readMeta(project);
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            if (doc.id.equals(o.optString("id"))) {
                try {
                    o.put("updated", doc.updated);
                } catch (Exception ignored) {
                }
            }
        }
        writeMeta(project, arr);
    }

    static void rename(File project, Doc doc, String name) {
        doc.name = name;
        JSONArray arr = readMeta(project);
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            if (doc.id.equals(o.optString("id"))) {
                try {
                    o.put("name", name);
                } catch (Exception ignored) {
                }
            }
        }
        writeMeta(project, arr);
    }

    static void delete(File project, Doc doc) {
        if (doc.file.exists()) //noinspection ResultOfMethodCallIgnored
            doc.file.delete();
        JSONArray arr = readMeta(project);
        JSONArray keep = new JSONArray();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            if (doc.id.equals(o.optString("id"))) continue;
            keep.put(o);
        }
        writeMeta(project, keep);
    }

    /** 只移除元数据条目，不删文件（回收站用） */
    static void removeEntry(File project, Doc doc) {
        JSONArray arr = readMeta(project);
        JSONArray keep = new JSONArray();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            if (doc.id.equals(o.optString("id"))) continue;
            keep.put(o);
        }
        writeMeta(project, keep);
    }

    /** 从回收站恢复：把条目重新写回 meta */
    static void addEntry(File project, String id, String name) {
        JSONArray arr = readMeta(project);
        JSONObject o = new JSONObject();
        try {
            o.put("id", id);
            o.put("name", name);
            o.put("updated", System.currentTimeMillis());
            arr.put(o);
        } catch (Exception ignored) {
        }
        writeMeta(project, arr);
    }

    static String read(File file) {
        try {
            java.io.BufferedReader r = new java.io.BufferedReader(
                    new java.io.InputStreamReader(new java.io.FileInputStream(file), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line).append('\n');
            r.close();
            return sb.toString();
        } catch (Exception e) {
            return "";
        }
    }

    static void write(File file, String body) {
        try {
            FileOutputStream out = new FileOutputStream(file);
            out.write(body.getBytes("UTF-8"));
            out.close();
        } catch (Exception ignored) {
        }
    }

    /** 纯文本预览（去掉标签） */
    static String preview(File file) {
        String s = read(file).replaceAll("<[^>]+>", " ")
                .replace("&nbsp;", " ").replace("&amp;", "&")
                .replace("&lt;", "<").replace("&gt;", ">")
                .replaceAll("\\s+", " ").trim();
        return s.length() > 60 ? s.substring(0, 60) + "…" : s;
    }
}
