package com.example.projcam;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

/** 支持双指缩放、双击放大、放大后拖动；未放大时左右滑动切换照片 */
public class ZoomImageView extends View {

    interface OnSwipeListener {
        void onSwipeLeft();

        void onSwipeRight();
    }

    private Bitmap bitmap;
    private final Matrix matrix = new Matrix();
    private final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private float zoom = 1f;           // 相对“适应屏幕”的倍率
    private float dx, dy;              // 平移（像素）
    private float fitScale = 1f;
    private boolean ready;
    private OnSwipeListener swipeListener;

    private final ScaleGestureDetector scaleDetector;
    private final GestureDetector gestureDetector;

    public ZoomImageView(Context c) {
        super(c);
        scaleDetector = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector d) {
                float next = zoom * d.getScaleFactor();
                next = Math.max(1f, Math.min(6f, next));
                // 以手指焦点为中心缩放
                float fx = d.getFocusX(), fy = d.getFocusY();
                float ratio = next / zoom;
                dx = fx - (fx - dx) * ratio;
                dy = fy - (fy - dy) * ratio;
                zoom = next;
                clamp();
                invalidate();
                return true;
            }
        });
        gestureDetector = new GestureDetector(c, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onDoubleTap(MotionEvent e) {
                if (zoom > 1.05f) {
                    zoom = 1f;
                    dx = 0;
                    dy = 0;
                } else {
                    float ratio = 2.5f / zoom;
                    dx = e.getX() - (e.getX() - dx) * ratio;
                    dy = e.getY() - (e.getY() - dy) * ratio;
                    zoom = 2.5f;
                }
                clamp();
                invalidate();
                return true;
            }

            @Override
            public boolean onScroll(MotionEvent e1, MotionEvent e2, float dxRaw, float dyRaw) {
                if (zoom <= 1.05f) return false;
                dx -= dxRaw;
                dy -= dyRaw;
                clamp();
                invalidate();
                return true;
            }

            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2, float vx, float vy) {
                if (zoom > 1.05f) return false;
                if (e1 == null || e2 == null) return false;
                float ddx = e2.getX() - e1.getX();
                if (Math.abs(ddx) < 60 || Math.abs(vx) < 200) return false;
                // 已经在放大的边界还继续拖，不切换
                if (ddx < 0) {
                    if (swipeListener != null) swipeListener.onSwipeLeft();
                } else {
                    if (swipeListener != null) swipeListener.onSwipeRight();
                }
                return true;
            }
        });
    }

    public void setBitmap(Bitmap b) {
        bitmap = b;
        zoom = 1f;
        dx = 0;
        dy = 0;
        ready = false;
        requestLayout();
        invalidate();
    }

    public void setOnSwipeListener(OnSwipeListener l) {
        swipeListener = l;
    }

    private void computeFit() {
        if (bitmap == null || getWidth() == 0) return;
        float sx = getWidth() / (float) bitmap.getWidth();
        float sy = getHeight() / (float) bitmap.getHeight();
        fitScale = Math.min(sx, sy);
        ready = true;
    }

    /** 限制平移范围，避免图片被拖出屏幕 */
    private void clamp() {
        if (bitmap == null) return;
        float w = bitmap.getWidth() * fitScale * zoom;
        float h = bitmap.getHeight() * fitScale * zoom;
        float maxX = Math.max(0, (w - getWidth()) / 2f);
        float maxY = Math.max(0, (h - getHeight()) / 2f);
        if (zoom <= 1.02f) {
            dx = 0;
            dy = 0;
            return;
        }
        dx = Math.max(-maxX, Math.min(maxX, dx));
        dy = Math.max(-maxY, Math.min(maxY, dy));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (bitmap == null) return;
        if (!ready) computeFit();
        canvas.save();
        canvas.translate((getWidth() - bitmap.getWidth() * fitScale) / 2f,
                (getHeight() - bitmap.getHeight() * fitScale) / 2f);
        canvas.translate(dx, dy);
        canvas.scale(fitScale * zoom, fitScale * zoom);
        canvas.drawBitmap(bitmap, 0, 0, paint);
        canvas.restore();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        scaleDetector.onTouchEvent(event);
        gestureDetector.onTouchEvent(event);
        return true;
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        ready = false;
    }
}
