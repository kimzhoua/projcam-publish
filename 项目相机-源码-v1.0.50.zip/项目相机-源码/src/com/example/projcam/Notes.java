package com.example.projcam;

import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

/** 项目内每张照片的文字备注，存在项目目录的 notes.json 里 */
final class Notes {

    private static File file(File dir) {
        return new File(dir, "notes.json");
    }

    private static JSONObject load(File dir) {
        try {
            File f = file(dir);
            if (!f.exists()) return new JSONObject();
            FileInputStream in = new FileInputStream(f);
            byte[] buf = new byte[(int) f.length()];
            int n = in.read(buf);
            in.close();
            if (n <= 0) return new JSONObject();
            return new JSONObject(new String(buf, 0, n, "UTF-8"));
        } catch (Throwable t) {
            return new JSONObject();
        }
    }

    private static void save(File dir, JSONObject o) {
        try {
            FileOutputStream out = new FileOutputStream(file(dir));
            out.write(o.toString().getBytes("UTF-8"));
            out.close();
        } catch (Throwable ignored) {
        }
    }

    static String get(File dir, File photo) {
        return load(dir).optString(photo.getName(), "");
    }

    static void set(File dir, File photo, String note) {
        JSONObject o = load(dir);
        try {
            if (note == null || note.trim().length() == 0) o.remove(photo.getName());
            else o.put(photo.getName(), note.trim());
        } catch (Throwable ignored) {
        }
        save(dir, o);
    }

    static void remove(File dir, File photo) {
        set(dir, photo, "");
    }
}
