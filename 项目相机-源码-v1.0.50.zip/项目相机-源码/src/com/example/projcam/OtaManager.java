package com.example.projcam;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Base64;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.X509EncodedKeySpec;

/**
 * 应用内在线更新。
 *
 * <p>清单是单文件自包含签名：{"payload":"<清单原文>","sig":"<RSA-SHA256>"}。
 * 只有验签通过才会使用清单；下载完成后校验 sha256，不一致拒绝安装。
 */
public class OtaManager {

    private static final String MANIFEST_URL =
            "https://cdn.jsdelivr.net/gh/kimzhoua/projcam-publish@main/dist/update.json";

    private static final String MANIFEST_PUBKEY =
            "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA+IwWupZK5kkPnX9SOhWTWO1GEl5qxXG2Ewkr9lx1YtV14Ll3lKwG26nm+4GI2i3Gip+tIr3u4jPwWKbZnk9KvKBd2gnZZbYsylSf3N2U0dUN6y9CFcCfsGg4lMom/pc7r8Kco+QxUUzh2N6ZT0W7BkvzzqWws80V7btWg/t5LizDFTRtc1wdbk3rzaRnAiAEhPkyPgIM08sNQ25Oha5bk8KTrAfRgWf8LABAiIKfBEej2/sDwnJ+gnCpigWhHUXbD7RxS0wkfNw1OFHr5VNmOl8Jcc3r8wWZS8/n9GOS4TzOEVcfLvx1zV7HD2ScWwoclVkYnX4qJIiMm3w2y7tIQwIDAQAB";

    private final Activity activity;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private long downloadId = -1L;
    private String expectSha256;
    private boolean receiverRegistered;

    public OtaManager(Activity activity) {
        this.activity = activity;
    }

    private volatile String lastError = "";

    public void checkUpdate(final boolean manual) {
        if (manual) Toast.makeText(activity, "正在检查更新…", Toast.LENGTH_SHORT).show();
        new Thread(new Runnable() {
            @Override
            public void run() {
                String payload = null;
                for (String candidate : candidates(MANIFEST_URL)) {
                    boolean viaApi = candidate.startsWith("https://api.github.com/");
                    String wrapper = httpGet(candidate,
                            viaApi ? "application/vnd.github.raw,*/*" : "application/json,*/*");
                    if (wrapper == null) {
                        lastError = lastHttp != null ? lastHttp : "网络异常";
                        continue;
                    }
                    if (!wrapper.contains("payload")) {
                        lastError = "清单格式异常";
                        continue;
                    }
                    String body;
                    String sig;
                    try {
                        JSONObject w = new JSONObject(wrapper);
                        body = w.optString("payload", "");
                        sig = w.optString("sig", "");
                    } catch (Exception e) {
                        continue;
                    }
                    if (body.length() == 0) {
                        lastError = "清单为空";
                        continue;
                    }
                    if (!verify(body, sig)) {
                        lastError = "清单签名校验未通过";
                        continue;
                    }
                    payload = body;
                    break;
                }
                if (payload == null) {
                    ui.post(new Runnable() {
                        @Override
                        public void run() {
                            if (manual) {
                                Toast.makeText(activity,
                                        "检查更新失败：" + (lastError.length() > 0 ? lastError : "网络异常"),
                                        Toast.LENGTH_LONG).show();
                            }
                        }
                    });
                    return;
                }
                JSONObject obj;
                try {
                    obj = new JSONObject(payload);
                } catch (Exception e) {
                    return;
                }
                final int newCode = obj.optInt("versionCode", 0);
                final String newName = obj.optString("versionName", "");
                final String apkUrl = obj.optString("apkUrl", "");
                final String notes = obj.optString("notes", "");
                final String sha = obj.optString("sha256", "");
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        if (newCode > installedVersionCode() && apkUrl.length() > 0) {
                            showDialog(newName, newCode, apkUrl, notes, sha);
                        } else if (manual) {
                            Toast.makeText(activity,
                                    "已是最新版本 v" + installedVersionName(),
                                    Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        }).start();
    }

    private void showDialog(final String newName, final int newCode, final String apkUrl,
                            String notes, final String sha256) {
        String message = "当前版本 v" + installedVersionName()
                + "\n新版本 v" + newName + "（" + newCode + "）";
        if (notes != null && notes.length() > 0) message += "\n\n更新说明：\n" + notes;
        new AlertDialog.Builder(activity)
                .setTitle("发现新版本")
                .setMessage(message)
                .setPositiveButton("下载并安装", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        download(apkUrl, newName, sha256);
                    }
                })
                .setNegativeButton("以后再说", null)
                .show();
    }

    // 下载状态做成静态，切页面/重进 App 也能把进度重新调回前台
    private static volatile boolean downloading;
    private static volatile boolean cancelRequested;
    private static final String APP_LABEL = "项目相机";

    private static volatile int dlPct;
    private static volatile long dlDone;
    private static volatile long dlTotal;
    private static volatile String dlVersionName = "";
    private static volatile File dlFile;
    private static volatile String dlSha256 = "";
    private static volatile java.net.HttpURLConnection dlConn;

    private android.app.AlertDialog progressDialog;
    private android.widget.ProgressBar progressBar;
    private android.widget.TextView progressText;
    private final Handler uiHandler = new Handler(Looper.getMainLooper());
    private Runnable pollTask;

    private void download(final String apkUrl, final String versionName, final String sha256) {
        if (downloading) {
            Toast.makeText(activity, "已有下载在进行中", Toast.LENGTH_SHORT).show();
            showProgress();
            return;
        }
        downloading = true;
        cancelRequested = false;
        dlPct = 0;
        dlDone = 0;
        dlTotal = 0;
        dlVersionName = versionName;
        dlSha256 = sha256;

        // 多源尝试：jsDelivr（国内较稳）→ raw → ghproxy 镜像
        final java.util.List<String> sources = new java.util.ArrayList<>();
        String ts = String.valueOf(System.currentTimeMillis());
        String raw = toRawUrl(apkUrl);
        sources.add(withTs(toJsDelivr(apkUrl), ts));
        if (raw != null) {
            sources.add(withTs(raw, ts));
            sources.add("https://ghproxy.net/" + withTs(raw, ts));
        }
        sources.add(apkUrl);

        final File dir = new File(activity.getFilesDir(), "update");
        if (!dir.exists() && !dir.mkdirs()) {
            downloading = false;
            Toast.makeText(activity, "无法创建下载目录", Toast.LENGTH_SHORT).show();
            return;
        }
        dlFile = new File(dir, "项目相机-v" + versionName + ".apk");

        showProgress();

        new Thread(new Runnable() {
            @Override
            public void run() {
                String lastErr = "网络异常";
                for (String src : sources) {
                    if (cancelRequested) break;
                    try {
                        if (fetchToFile(src)) {
                            lastErr = null;
                            break;
                        }
                    } catch (Throwable t) {
                        lastErr = t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage();
                    }
                    dlPct = 0;
                    dlDone = 0;
                }

                if (cancelRequested) {
                    if (dlFile != null && dlFile.exists()) {
                        //noinspection ResultOfMethodCallIgnored
                        dlFile.delete();
                    }
                    recordDownload(versionName, 0, "已取消");
                    downloading = false;
                    uiHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            dismissProgress();
                            Toast.makeText(activity, "已取消下载", Toast.LENGTH_SHORT).show();
                        }
                    });
                    return;
                }

                if (lastErr != null) {
                    recordDownload(versionName, 0, "失败：" + lastErr);
                    downloading = false;
                    final String msg = lastErr;
                    uiHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            dismissProgress();
                            Toast.makeText(activity, "下载失败：" + msg, Toast.LENGTH_LONG).show();
                        }
                    });
                    return;
                }

                final boolean ok = sha256OfFile(dlFile).equalsIgnoreCase(dlSha256);
                final long fsize = dlFile != null ? dlFile.length() : 0;
                recordDownload(versionName, fsize, ok ? "已校验，可安装" : "校验失败");
                downloading = false;
                uiHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        dismissProgress();
                        if (ok) {
                            install(PhotoProvider.uriFor(dlFile));
                        } else {
                            //noinspection ResultOfMethodCallIgnored
                            dlFile.delete();
                            Toast.makeText(activity, "安装包校验失败，已取消安装",
                                    Toast.LENGTH_LONG).show();
                        }
                    }
                });
            }
        }).start();
    }

    /** 从单个源下载到本地文件，成功返回 true */
    private boolean fetchToFile(String src) throws Exception {
        java.io.FileOutputStream fos = null;
        java.io.InputStream in = null;
        try {
            java.net.URL url = new java.net.URL(src);
            dlConn = (java.net.HttpURLConnection) url.openConnection();
            dlConn.setConnectTimeout(12000);
            dlConn.setReadTimeout(25000);
            dlConn.setInstanceFollowRedirects(true);
            dlConn.setRequestProperty("User-Agent",
                    "Mozilla/5.0 (Linux; Android 14) ProjCam");
            dlConn.setRequestProperty("Accept", "*/*");
            dlConn.setRequestProperty("Accept-Encoding", "identity");
            int code = dlConn.getResponseCode();
            if (code != 200) throw new java.io.IOException("HTTP " + code);

            dlTotal = dlConn.getContentLength();
            in = dlConn.getInputStream();
            fos = new java.io.FileOutputStream(dlFile, false);
            byte[] buf = new byte[8192];
            long done = 0;
            int n;
            while ((n = in.read(buf)) > 0) {
                if (cancelRequested) break;
                fos.write(buf, 0, n);
                done += n;
                dlDone = done;
                if (dlTotal > 0) dlPct = (int) (done * 100 / dlTotal);
            }
            fos.close();
            fos = null;
            in.close();
            in = null;
            dlConn.disconnect();
            dlConn = null;
            if (cancelRequested) return false;
            if (dlTotal > 0 && done < dlTotal) throw new java.io.IOException("下载不完整");
            return dlFile.length() > 0;
        } finally {
            try {
                if (fos != null) fos.close();
            } catch (Exception ignored) {
            }
            try {
                if (in != null) in.close();
            } catch (Exception ignored) {
            }
            try {
                if (dlConn != null) dlConn.disconnect();
            } catch (Exception ignored) {
            }
            dlConn = null;
        }
    }


    // ============ 下载记录 ============

    private File updateDir() {
        File d = new File(activity.getFilesDir(), "update");
        if (!d.exists()) //noinspection ResultOfMethodCallIgnored
            d.mkdirs();
        return d;
    }

    /** 追加一条下载记录：时间 \t 版本 \t 字节数 \t 状态 */
    private void recordDownload(String version, long size, String status) {
        try {
            java.io.FileWriter w = new java.io.FileWriter(
                    new File(updateDir(), "history.txt"), true);
            String t = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm",
                    java.util.Locale.CHINA).format(new java.util.Date());
            w.write(t + "\t" + version + "\t" + size + "\t" + status + "\n");
            w.close();
        } catch (Exception ignored) {
        }
    }

    private java.util.List<String[]> readRecords() {
        java.util.List<String[]> list = new java.util.ArrayList<>();
        File f = new File(updateDir(), "history.txt");
        if (!f.exists()) return list;
        try {
            java.io.BufferedReader r = new java.io.BufferedReader(
                    new java.io.InputStreamReader(new java.io.FileInputStream(f), "UTF-8"));
            String line;
            while ((line = r.readLine()) != null) {
                String[] p = line.split("\t");
                if (p.length >= 4) list.add(p);
            }
            r.close();
        } catch (Exception ignored) {
        }
        // 最新的排前面
        java.util.Collections.reverse(list);
        return list;
    }

    private void rewriteRecords(java.util.List<String[]> keep) {
        try {
            java.io.FileWriter w = new java.io.FileWriter(
                    new File(updateDir(), "history.txt"), false);
            for (int i = keep.size() - 1; i >= 0; i--) {
                String[] p = keep.get(i);
                w.write(p[0] + "\t" + p[1] + "\t" + p[2] + "\t" + p[3] + "\n");
            }
            w.close();
        } catch (Exception ignored) {
        }
    }

    private File apkOfVersion(String version) {
        return new File(updateDir(), APP_LABEL + "-v" + version + ".apk");
    }

    /** 下载记录列表：可安装已下载包、可删除源文件 */
    public void showRecords() {
        final Activity a = activity;
        final int pad = (int) (16 * a.getResources().getDisplayMetrics().density);

        android.widget.LinearLayout box = new android.widget.LinearLayout(a);
        box.setOrientation(android.widget.LinearLayout.VERTICAL);
        box.setPadding(pad, pad, pad, pad);

        final java.util.List<String[]> recs = readRecords();

        android.widget.TextView empty = new android.widget.TextView(a);
        empty.setText("还没有下载记录。检查更新并下载后会在这里留下记录。");
        empty.setTextSize(12);
        empty.setPadding(0, pad, 0, pad);

        if (recs.isEmpty()) {
            box.addView(empty);
        } else {
            android.widget.ScrollView sv = new android.widget.ScrollView(a);
            android.widget.LinearLayout listBox = new android.widget.LinearLayout(a);
            listBox.setOrientation(android.widget.LinearLayout.VERTICAL);
            sv.addView(listBox);
            android.widget.LinearLayout.LayoutParams svlp =
                    new android.widget.LinearLayout.LayoutParams(
                            android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                            (int) (260 * a.getResources().getDisplayMetrics().density));
            box.addView(sv, svlp);

            final java.util.List<String[]> shown = new java.util.ArrayList<>(recs);
            for (int i = 0; i < shown.size(); i++) {
                final String[] p = shown.get(i);
                final File f = apkOfVersion(p[1]);

                android.widget.LinearLayout row = new android.widget.LinearLayout(a);
                row.setOrientation(android.widget.LinearLayout.HORIZONTAL);
                row.setGravity(android.view.Gravity.CENTER_VERTICAL);
                row.setPadding(0, pad / 2, 0, pad / 2);

                android.widget.LinearLayout texts = new android.widget.LinearLayout(a);
                texts.setOrientation(android.widget.LinearLayout.VERTICAL);
                texts.setLayoutParams(new android.widget.LinearLayout.LayoutParams(
                        0, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
                android.widget.TextView t1 = new android.widget.TextView(a);
                t1.setText("v" + p[1] + " · " + p[0]);
                t1.setTextSize(13);
                texts.addView(t1);
                android.widget.TextView t2 = new android.widget.TextView(a);
                String sizeTxt = p[2].equals("0") ? "" : (" · " + (Long.parseLong(p[2]) / 1024) + " KB");
                t2.setText(p[3] + sizeTxt + (f.exists() ? "" : " · 文件已删除"));
                t2.setTextSize(10);
                t2.setPadding(0, 4, 0, 0);
                texts.addView(t2);
                row.addView(texts);

                android.widget.TextView act = new android.widget.TextView(a);
                act.setText(f.exists() ? "安装" : "删除");
                act.setTextSize(12);
                act.setPadding(pad / 2, pad / 4, pad / 4, pad / 4);
                row.addView(act);

                final android.app.AlertDialog[] holder = new android.app.AlertDialog[1];

                act.setOnClickListener(new android.view.View.OnClickListener() {
                    @Override
                    public void onClick(android.view.View v) {
                        if (f.exists()) {
                            install(PhotoProvider.uriFor(f));
                            if (holder[0] != null) holder[0].dismiss();
                        } else {
                            shown.remove(p);
                            rewriteRecords(shown);
                            if (holder[0] != null) holder[0].dismiss();
                            showRecords();
                        }
                    }
                });

                android.widget.TextView del = new android.widget.TextView(a);
                del.setText("删除文件");
                del.setTextSize(11);
                del.setPadding(pad / 2, pad / 4, 0, pad / 4);
                if (f.exists()) {
                    del.setOnClickListener(new android.view.View.OnClickListener() {
                        @Override
                        public void onClick(android.view.View v) {
                            //noinspection ResultOfMethodCallIgnored
                            f.delete();
                            shown.remove(p);
                            rewriteRecords(shown);
                            Toast.makeText(a, "已删除源文件", Toast.LENGTH_SHORT).show();
                            if (holder[0] != null) holder[0].dismiss();
                            showRecords();
                        }
                    });
                } else {
                    del.setVisibility(android.view.View.GONE);
                }
                row.addView(del);

                listBox.addView(row);
            }
        }

        android.widget.TextView clean = new android.widget.TextView(a);
        clean.setText("清空记录并删除所有安装包");
        clean.setTextSize(12);
        clean.setPadding(0, pad, 0, 0);
        clean.setOnClickListener(new android.view.View.OnClickListener() {
            @Override
            public void onClick(android.view.View v) {
                File d = updateDir();
                File[] fs = d.listFiles();
                if (fs != null) for (File f : fs) {
                    //noinspection ResultOfMethodCallIgnored
                    f.delete();
                }
                Toast.makeText(a, "已清空下载记录并删除全部安装包", Toast.LENGTH_SHORT).show();
            }
        });
        box.addView(clean);

        new android.app.AlertDialog.Builder(a)
                .setTitle("OTA 下载记录")
                .setView(box)
                .setPositiveButton("关闭", null)
                .show();
    }

    /** 是否正在下载（设置页据此显示“下载进度”） */
    boolean isDownloading() {
        return downloading;
    }

    int progressPercent() {
        return dlPct;
    }

    /** 把进度框重新叫回前台（后台下载后使用） */
    void reopenProgress() {
        if (downloading) showProgress();
        else showRecords();
    }

    private void showProgress() {
        if (progressDialog != null && progressDialog.isShowing()) return;
        Activity a = activity;
        int pad = (int) (16 * a.getResources().getDisplayMetrics().density);

        android.widget.LinearLayout box = new android.widget.LinearLayout(a);
        box.setOrientation(android.widget.LinearLayout.VERTICAL);
        box.setPadding(pad, pad, pad, pad);

        progressText = new android.widget.TextView(a);
        progressText.setTextSize(13);
        box.addView(progressText);

        progressBar = new android.widget.ProgressBar(a, null,
                android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        android.widget.LinearLayout.LayoutParams lp =
                new android.widget.LinearLayout.LayoutParams(
                        android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                        (int) (10 * a.getResources().getDisplayMetrics().density));
        lp.topMargin = pad / 2;
        progressBar.setLayoutParams(lp);
        box.addView(progressBar);

        progressDialog = new android.app.AlertDialog.Builder(a)
                .setTitle("下载 v" + dlVersionName)
                .setView(box)
                .setPositiveButton("后台下载", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        stopPolling();
                        Toast.makeText(activity,
                                "已转到后台，可随时到「设置 → 下载进度」查看",
                                Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("取消下载", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        cancelDownload();
                    }
                })
                .show();

        startPolling();
    }

    private void startPolling() {
        stopPolling();
        pollTask = new Runnable() {
            @Override
            public void run() {
                if (progressText != null) {
                    String size = mb(dlDone) + " / " + (dlTotal > 0 ? mb(dlTotal) : "?");
                    progressText.setText("正在下载… " + dlPct + "%  (" + size + ")");
                }
                if (progressBar != null) progressBar.setProgress(dlPct);
                if (!downloading) {
                    stopPolling();
                    return;
                }
                poller();
            }

            private void poller() {
                uiHandler.postDelayed(this, 400);
            }
        };
        uiHandler.post(pollTask);
    }

    private void stopPolling() {
        if (pollTask != null) {
            uiHandler.removeCallbacks(pollTask);
            pollTask = null;
        }
    }

    private String mb(long bytes) {
        if (bytes <= 0) return "0MB";
        return String.format("%.1fMB", bytes / 1024.0 / 1024.0);
    }

    private void dismissProgress() {
        if (progressDialog != null && progressDialog.isShowing()) {
            try {
                progressDialog.dismiss();
            } catch (Exception ignored) {
            }
        }
        progressDialog = null;
        progressBar = null;
        progressText = null;
    }

    private void cancelDownload() {
        cancelRequested = true;
        stopPolling();
        dismissProgress();
        try {
            if (dlConn != null) dlConn.disconnect();
        } catch (Exception ignored) {
        }
    }

    private String sha256OfFile(File f) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            java.io.FileInputStream in = new java.io.FileInputStream(f);
            byte[] buf = new byte[8192];
            int len;
            while ((len = in.read(buf)) != -1) md.update(buf, 0, len);
            in.close();
            byte[] d = md.digest();
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return "";
        }
    }

    /** Activity 结束时收掉进度框；下载线程不中断，仍会在后台继续进行 */
    public void release() {
        stopPolling();
        dismissProgress();
    }

    private void install(final Uri uri) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                && !activity.getPackageManager().canRequestPackageInstalls()) {
            new AlertDialog.Builder(activity)
                    .setTitle("需要允许安装应用")
                    .setMessage("系统限制未知来源安装，请允许本应用安装应用后再试")
                    .setPositiveButton("去设置", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            try {
                                activity.startActivity(new Intent(
                                        Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                                        Uri.parse("package:" + activity.getPackageName())));
                            } catch (Exception ignored) {
                            }
                        }
                    })
                    .setNegativeButton("取消", null)
                    .show();
            return;
        }
        try {
            Intent it = new Intent(Intent.ACTION_VIEW);
            it.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            it.setDataAndType(uri, "application/vnd.android.package-archive");
            activity.startActivity(it);
        } catch (Exception e) {
            Toast.makeText(activity, "拉起安装界面失败：" + e.getMessage(),
                    Toast.LENGTH_LONG).show();
        }
    }

    /** 与澳门日历完全一致的取源顺序：API → raw+时间戳 → jsDelivr+时间戳 → jsDelivr */
    private static String[] candidates(String url) {
        String ts = String.valueOf(System.currentTimeMillis());
        String api = toApiUrl(url);
        String raw = toRawUrl(url);
        String busted = withTs(url, ts);
        if (api != null && raw != null) {
            return new String[]{api, withTs(raw, ts), busted, url};
        }
        if (api != null) return new String[]{api, busted, url};
        if (raw != null) return new String[]{withTs(raw, ts), busted, url};
        return new String[]{busted, url};
    }

    /** raw.githubusercontent.com/... → cdn.jsdelivr.net/gh/user/repo@main/path */
    private static String toJsDelivr(String url) {
        String marker = "raw.githubusercontent.com/";
        int i = url.indexOf(marker);
        if (i < 0) return url;
        String rest = url.substring(i + marker.length());
        int s1 = rest.indexOf('/');
        if (s1 < 0) return url;
        int s2 = rest.indexOf('/', s1 + 1);
        if (s2 < 0) return url;
        String userRepo = rest.substring(0, s1) + "/" + rest.substring(s1 + 1, s2);
        String branchAndPath = rest.substring(s2 + 1);
        return "https://cdn.jsdelivr.net/gh/" + userRepo + "@main/" + branchAndPath;
    }

    private static String withTs(String url, String ts) {
        return url + (url.contains("?") ? "&" : "?") + "_=" + ts;
    }

    /** cdn.jsdelivr.net/gh/user/repo@branch/path → api.github.com/repos/user/repo/contents/path?ref=branch */
    private static String toApiUrl(String url) {
        String marker = "cdn.jsdelivr.net/gh/";
        int i = url.indexOf(marker);
        if (i < 0) return null;
        String rest = url.substring(i + marker.length());
        int at = rest.indexOf('@');
        if (at < 0) return null;
        String userRepo = rest.substring(0, at);
        String branchAndPath = rest.substring(at + 1);
        int slash = branchAndPath.indexOf('/');
        if (slash < 0) return null;
        String branch = branchAndPath.substring(0, slash);
        String path = branchAndPath.substring(slash + 1);
        int q = path.indexOf('?');
        if (q >= 0) path = path.substring(0, q);
        return "https://api.github.com/repos/" + userRepo + "/contents/" + path + "?ref=" + branch;
    }

    /** cdn.jsdelivr.net/gh/user/repo@branch/path → raw.githubusercontent.com/user/repo/branch/path */
    private static String toRawUrl(String url) {
        String marker = "cdn.jsdelivr.net/gh/";
        int i = url.indexOf(marker);
        if (i < 0) return null;
        String rest = url.substring(i + marker.length());
        int at = rest.indexOf('@');
        int slash = rest.indexOf('/', at < 0 ? 0 : at);
        if (at < 0 || slash < 0) return null;
        String userRepo = rest.substring(0, at);
        String branch = rest.substring(at + 1, slash);
        String path = rest.substring(slash + 1);
        int q = path.indexOf('?');
        if (q >= 0) path = path.substring(0, q);
        return "https://raw.githubusercontent.com/" + userRepo + "/" + branch + "/" + path;
    }

    private boolean verify(String body, String sigBase64) {
        if (sigBase64 == null || sigBase64.trim().length() == 0) return false;
        try {
            byte[] der = Base64.decode(MANIFEST_PUBKEY, Base64.DEFAULT);
            PublicKey pub = KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(der));
            Signature sig = Signature.getInstance("SHA256withRSA");
            sig.initVerify(pub);
            sig.update(body.getBytes("UTF-8"));
            return sig.verify(Base64.decode(sigBase64.trim(), Base64.DEFAULT));
        } catch (Exception e) {
            return false;
        }
    }

    private String sha256Of(Uri uri) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            InputStream in = activity.getContentResolver().openInputStream(uri);
            if (in == null) return "";
            byte[] buf = new byte[8192];
            int len;
            while ((len = in.read(buf)) != -1) md.update(buf, 0, len);
            in.close();
            byte[] d = md.digest();
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return "";
        }
    }

    private static volatile String lastHttp;

    private static String httpGet(String address, String accept) {
        HttpURLConnection conn = null;
        try {
            URL url = new URL(address);
            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(12000);
            conn.setReadTimeout(18000);
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) IPCalc");
            conn.setRequestProperty("Accept", accept);
            conn.setRequestProperty("Accept-Encoding", "identity");
            int code = conn.getResponseCode();
            if (code != 200) {
                lastHttp = "HTTP " + code;
                return null;
            }
            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(conn.getInputStream(), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) sb.append(line).append('\n');
            reader.close();
            return sb.toString();
        } catch (Exception e) {
            lastHttp = "连接失败（" + e.getClass().getSimpleName() + "）";
            return null;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private int installedVersionCode() {
        try {
            PackageInfo info = activity.getPackageManager().getPackageInfo(
                    activity.getPackageName(), 0);
            return info.versionCode;
        } catch (Exception e) {
            return 0;
        }
    }

    private String installedVersionName() {
        try {
            PackageInfo info = activity.getPackageManager().getPackageInfo(
                    activity.getPackageName(), 0);
            return info.versionName;
        } catch (Exception e) {
            return "";
        }
    }
}
