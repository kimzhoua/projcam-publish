package com.example.projcam;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.List;

/** 分类相机 · 首页：项目管理 */
public class MainActivity extends Activity {

    private static final String PREF = "projcam";

    private LinearLayout listBox;
    private TextView emptyView;
    private ScrollView scroll;

    // 指纹锁
    private boolean locked;
    private TextView lockHint;
    private OtaManager ota;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        installCrashHandler();
        showLastCrashIfAny();
        try {
            Night.init(this);
            applyImmersive();
            if (lockEnabled() && !fingerUnlocked) {
                showLockScreen("");
            } else {
                build();
            }
        } catch (Throwable t) {
            Toast.makeText(this, "启动出错：" + t, Toast.LENGTH_LONG).show();
        }
    }

    /** 崩溃堆栈落盘，下次启动弹窗显示，便于定位 */
    private void installCrashHandler() {
        final Thread.UncaughtExceptionHandler old = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override
            public void uncaughtException(Thread t, Throwable e) {
                try {
                    java.io.StringWriter sw = new java.io.StringWriter();
                    e.printStackTrace(new java.io.PrintWriter(sw));
                    java.io.FileOutputStream fos = openFileOutput("crash.txt", MODE_PRIVATE);
                    fos.write(sw.toString().getBytes("UTF-8"));
                    fos.close();
                } catch (Throwable ignored) {
                }
                if (old != null) old.uncaughtException(t, e);
                else android.os.Process.killProcess(android.os.Process.myPid());
            }
        });
    }

    private void showLastCrashIfAny() {
        try {
            File f = new File(getFilesDir(), "crash.txt");
            if (!f.exists()) return;
            java.io.FileInputStream in = new java.io.FileInputStream(f);
            byte[] buf = new byte[(int) f.length()];
            int n = in.read(buf);
            in.close();
            f.delete();
            String trace = n > 0 ? new String(buf, 0, n, "UTF-8") : "";
            if (trace.length() == 0) return;
            android.widget.ScrollView sv = new android.widget.ScrollView(this);
            TextView tv = new TextView(this);
            tv.setTextSize(11);
            tv.setTextIsSelectable(true);
            tv.setText(trace.length() > 1500 ? trace.substring(0, 1500) + "\n…（已截断）" : trace);
            tv.setPadding(dp(16), dp(12), dp(16), dp(12));
            sv.addView(tv);
            new AlertDialog.Builder(this)
                    .setTitle("上次崩溃记录")
                    .setView(sv)
                    .setPositiveButton("知道了", null)
                    .show();
        } catch (Throwable ignored) {
        }
    }

    private void applyImmersive() {
        Window w = getWindow();
        w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        w.setStatusBarColor(0x00000000);
        int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | (Night.dark ? 0 : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        w.getDecorView().setSystemUiVisibility(flags);
    }

    @Override
    protected void onResume() {
        super.onResume();
        Life.onResume();
        try {
            // 只有真正退出过 App（切到别的 App / 回桌面）才重新验证指纹；
            // 在 App 内部页面之间来回切换不算
            if (Life.consumeBack() && lockEnabled()) {
                fingerUnlocked = false;
            }
            if (Life.pending && lockEnabled()) {
                Life.pending = false;
                fingerUnlocked = false;
            }
            if (lockEnabled() && !fingerUnlocked && !locked) {
                showLockScreen("");
                return;
            }
            if (!locked && scroll != null) render();
        } catch (Throwable t) {
            Toast.makeText(this, "界面出错：" + t, Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        // 注意：这里不再重置解锁状态。onUserLeaveHint 在 App 内部启动其他 Activity 时
        // 也会触发（例如进入项目），会导致「项目返回主页就要再验一次指纹」。
        // 真正的后台判断交给 Life（以全进程可见页面数为 0 为准）。
    }

    @Override
    protected void onPause() {
        super.onPause();
        Life.onPause();
    }

    // ============ 指纹锁 ============

    private boolean lockEnabled() {
        return getSharedPreferences(PREF, MODE_PRIVATE).getBoolean("finger_lock", false);
    }

    private TextView pinSub;

    void showPinBoxSub() {
        if (pinSub != null) pinSub.setText(hasPin() ? "已设置，指纹失灵时可用" : "未设置");
    }

    /** 本次进程内是否已解锁 */
    private static boolean fingerUnlocked = false;

    /** 其他页面判断是否开了指纹锁（供从后台回来时退回主页解锁） */
    static boolean lockOn(android.content.Context c) {
        return c.getSharedPreferences(PREF, MODE_PRIVATE).getBoolean("finger_lock", false);
    }

    static void resetLock() {
        fingerUnlocked = false;
    }

    private static final int PIN_LEN = 6;

    /** 6 个输入框的密码输入行 */
    private android.widget.HorizontalScrollView sixPinRow(final android.widget.EditText[] pins) {
        return sixPinRow(pins, null);
    }

    private android.widget.HorizontalScrollView sixPinRow(final android.widget.EditText[] pins,
                                                          final Runnable onComplete) {
        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        hs.setFillViewport(true);
        android.widget.LinearLayout row = new android.widget.LinearLayout(this);
        row.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        row.setPadding(dp(6), dp(12), dp(6), dp(6));
        for (int i = 0; i < PIN_LEN; i++) {
            final android.widget.EditText e = new android.widget.EditText(this);
            e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
            e.setFilters(new android.text.InputFilter[]{
                    new android.text.InputFilter.LengthFilter(1)});
            e.setGravity(Gravity.CENTER);
            e.setTextSize(20);
            e.setTextColor(Night.main);
            e.setPadding(0, 0, 0, 0);
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(Night.soft);
            bg.setCornerRadius(dp(12));
            bg.setStroke(dp(1), Night.hair);
            e.setBackground(bg);
            android.widget.LinearLayout.LayoutParams lp = new android.widget.LinearLayout.LayoutParams(
                    dp(38), dp(46));
            lp.leftMargin = dp(3);
            lp.rightMargin = dp(3);
            e.setLayoutParams(lp);
            pins[i] = e;
            final int idx = i;
            e.addTextChangedListener(new android.text.TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s1, int a, int b, int c) {
                }

                @Override
                public void onTextChanged(CharSequence s1, int a, int b, int c) {
                }

                @Override
                public void afterTextChanged(android.text.Editable ed) {
                    if (ed.length() == 1 && idx < PIN_LEN - 1) {
                        pins[idx + 1].requestFocus();
                    } else if (ed.length() == 0 && idx > 0) {
                        pins[idx - 1].requestFocus();
                    } else if (idx == PIN_LEN - 1 && ed.length() == 1 && onComplete != null) {
                        // 输满 6 位自动提交
                        e.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                if (pinValue(pins).length() == PIN_LEN) onComplete.run();
                            }
                        }, 120);
                    }
                }
            });
            row.addView(e);
        }
        hs.addView(row);
        return hs;
    }

    private String pinValue(android.widget.EditText[] pins) {
        StringBuilder sb = new StringBuilder();
        for (android.widget.EditText e : pins) sb.append(e.getText().toString().trim());
        return sb.toString();
    }

    private void clearPinRow(android.widget.EditText[] pins) {
        for (android.widget.EditText e : pins) e.setText("");
        pins[0].requestFocus();
    }

    private void askSetPin() {
        askSetPin(null);
    }

    /** 设置 / 修改解锁密码（6 位数字） */
    private void askSetPin(final Runnable onSaved) {
        final android.widget.EditText[] pins = new android.widget.EditText[PIN_LEN];
        android.widget.LinearLayout box = new android.widget.LinearLayout(this);
        box.setOrientation(android.widget.LinearLayout.VERTICAL);
        box.setPadding(dp(20), 0, dp(20), 0);
        android.widget.TextView tip = new android.widget.TextView(this);
        tip.setText(hasPin() ? "输入新的 6 位解锁密码" : "设置 6 位解锁密码，指纹失灵时用它进入");
        tip.setTextSize(12);
        tip.setTextColor(Night.sub);
        tip.setGravity(Gravity.CENTER);
        tip.setPadding(0, dp(12), 0, 0);
        box.addView(tip);
        box.addView(sixPinRow(pins));

        new AlertDialog.Builder(this)
                .setTitle(hasPin() ? "修改解锁密码" : "设置解锁密码")
                .setView(box)
                .setPositiveButton("保存", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        String pin = pinValue(pins);
                        if (pin.length() != PIN_LEN) {
                            Toast.makeText(MainActivity.this, "请输入完整的 6 位数字",
                                    Toast.LENGTH_SHORT).show();
                            return;
                        }
                        getSharedPreferences(PREF, MODE_PRIVATE).edit()
                                .putString("lock_pin", pin).apply();
                        showPinBoxSub();
                        Toast.makeText(MainActivity.this, "解锁密码已保存",
                                Toast.LENGTH_SHORT).show();
                        if (onSaved != null) onSaved.run();
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    /** 锁屏页：密码解锁（输满 6 位自动校验，无需点按钮） */
    private void askPinUnlock() {
        final android.widget.EditText[] pins = new android.widget.EditText[PIN_LEN];
        final AlertDialog[] holder = new AlertDialog[1];
        android.widget.LinearLayout box = new android.widget.LinearLayout(this);
        box.setOrientation(android.widget.LinearLayout.VERTICAL);
        box.setPadding(dp(20), 0, dp(20), 0);
        android.widget.TextView tip = new android.widget.TextView(this);
        tip.setText("输入 6 位解锁密码");
        tip.setTextSize(12);
        tip.setTextColor(Night.sub);
        tip.setGravity(Gravity.CENTER);
        tip.setPadding(0, dp(12), 0, 0);
        box.addView(tip);
        box.addView(sixPinRow(pins, new Runnable() {
            @Override
            public void run() {
                String saved = getSharedPreferences(PREF, MODE_PRIVATE).getString("lock_pin", "");
                String pin = pinValue(pins);
                if (saved != null && saved.equals(pin)) {
                    if (holder[0] != null) holder[0].dismiss();
                    onUnlocked();
                } else {
                    Toast.makeText(MainActivity.this, "密码不正确", Toast.LENGTH_SHORT).show();
                    if (lockHint != null) lockHint.setText("密码不正确");
                    clearPinRow(pins);
                }
            }
        }));

        holder[0] = new AlertDialog.Builder(this)
                .setTitle("密码解锁")
                .setView(box)
                .setPositiveButton("解锁", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        String saved = getSharedPreferences(PREF, MODE_PRIVATE)
                                .getString("lock_pin", "");
                        String pin = pinValue(pins);
                        if (saved != null && saved.equals(pin)) {
                            onUnlocked();
                        } else {
                            Toast.makeText(MainActivity.this, "密码不正确", Toast.LENGTH_SHORT).show();
                            if (lockHint != null) lockHint.setText("密码不正确");
                            clearPinRow(pins);
                        }
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    /** 先用指纹验证身份，通过后执行 ok（用于重置密码） */
    private void verifyFingerThen(final Runnable ok) {
        if (!hasFingerprintHardware()) {
            Toast.makeText(this, "这台手机没有可用的指纹硬件", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            if (Build.VERSION.SDK_INT >= 28) {
                java.util.concurrent.Executor exec = getMainExecutor();
                android.hardware.biometrics.BiometricPrompt prompt =
                        new android.hardware.biometrics.BiometricPrompt.Builder(this)
                                .setTitle("验证指纹")
                                .setSubtitle("通过后即可重置解锁密码")
                                .setNegativeButton("取消", exec, null)
                                .build();
                prompt.authenticate(new android.os.CancellationSignal(), exec,
                        new android.hardware.biometrics.BiometricPrompt.AuthenticationCallback() {
                            @Override
                            public void onAuthenticationSucceeded(
                                    android.hardware.biometrics.BiometricPrompt.AuthenticationResult r) {
                                ok.run();
                            }

                            @Override
                            public void onAuthenticationError(int code, CharSequence msg) {
                                Toast.makeText(MainActivity.this, "验证未通过：" + msg,
                                        Toast.LENGTH_SHORT).show();
                            }

                            @Override
                            public void onAuthenticationFailed() {
                                Toast.makeText(MainActivity.this, "指纹不匹配，请重试",
                                        Toast.LENGTH_SHORT).show();
                            }
                        });
            } else {
                android.hardware.fingerprint.FingerprintManager fm =
                        (android.hardware.fingerprint.FingerprintManager)
                                getSystemService(FINGERPRINT_SERVICE);
                if (fm == null) return;
                fm.authenticate(null, null, 0,
                        new android.hardware.fingerprint.FingerprintManager.AuthenticationCallback() {
                            @Override
                            public void onAuthenticationSucceeded(
                                    android.hardware.fingerprint.FingerprintManager.AuthenticationResult r) {
                                ok.run();
                            }

                            @Override
                            public void onAuthenticationError(int code, CharSequence msg) {
                                Toast.makeText(MainActivity.this, "验证未通过：" + msg,
                                        Toast.LENGTH_SHORT).show();
                            }
                        }, null);
                Toast.makeText(this, "请按指纹", Toast.LENGTH_SHORT).show();
            }
        } catch (Throwable t) {
            Toast.makeText(this, "调起指纹失败：" + t.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private boolean hasPin() {
        String pin = getSharedPreferences(PREF, MODE_PRIVATE).getString("lock_pin", "");
        return pin != null && pin.length() == PIN_LEN;
    }

    private boolean hasFingerprintHardware() {
        try {
            android.hardware.fingerprint.FingerprintManager fm =
                    (android.hardware.fingerprint.FingerprintManager)
                            getSystemService(FINGERPRINT_SERVICE);
            return fm != null && fm.isHardwareDetected();
        } catch (Throwable t) {
            return false;
        }
    }

    private void showLockScreen(String hint) {
        locked = true;
        FrameLayout page = new FrameLayout(this);
        page.setBackgroundColor(Night.page);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(32), dp(120), dp(32), dp(40));
        FrameLayout.LayoutParams clp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        page.addView(col, clp);

        TextView icon = new TextView(this);
        icon.setText("🔒");
        icon.setTextSize(46);
        icon.setGravity(Gravity.CENTER);
        col.addView(icon);

        TextView title = new TextView(this);
        title.setText("分类相机已锁定");
        title.setTextSize(19);
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        title.setTextColor(Night.main);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(16), 0, 0);
        col.addView(title);

        TextView sub = new TextView(this);
        sub.setText("用指纹解锁，或使用解锁密码进入");
        sub.setTextSize(12);
        sub.setTextColor(Night.sub);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, dp(8), 0, 0);
        col.addView(sub);

        lockHint = new TextView(this);
        lockHint.setText(hint);
        lockHint.setTextSize(12);
        lockHint.setTextColor(Night.danger);
        lockHint.setGravity(Gravity.CENTER);
        lockHint.setPadding(0, dp(12), 0, 0);
        col.addView(lockHint);

        TextView btn = new TextView(this);
        btn.setText("指纹解锁");
        btn.setTextSize(15);
        btn.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        btn.setTextColor(0xFFFFFFFF);
        btn.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                Night.dark ? new int[]{0xFF3E63D8, 0xFF5C86FF} : new int[]{0xFF2F6BFF, 0xFF4F8DFF});
        bg.setCornerRadius(dp(14));
        btn.setBackground(bg);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(48));
        blp.topMargin = dp(28);
        btn.setLayoutParams(blp);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startAuth();
            }
        });
        col.addView(btn);

        {
            TextView pinBtn = new TextView(this);
            pinBtn.setText("用密码解锁");
            pinBtn.setTextSize(14);
            pinBtn.setTextColor(Night.accent);
            pinBtn.setGravity(Gravity.CENTER);
            GradientDrawable pbg = new GradientDrawable();
            pbg.setColor(Night.soft);
            pbg.setCornerRadius(dp(14));
            pinBtn.setBackground(pbg);
            LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(46));
            plp.topMargin = dp(10);
            pinBtn.setLayoutParams(plp);
            pinBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (!hasPin()) {
                        Toast.makeText(MainActivity.this,
                                "还没有解锁密码：请在设置里开启指纹锁时会要求设置",
                                Toast.LENGTH_LONG).show();
                        return;
                    }
                    askPinUnlock();
                }
            });
            col.addView(pinBtn);
        }

        TextView tip = new TextView(this);
        tip.setText(hasPin()
                ? "指纹失灵时可用解锁密码；忘记密码只能重装 App"
                : "没录指纹？到「设置 → 指纹/生物识别」里添加后即可解锁");
        tip.setTextSize(11);
        tip.setTextColor(Night.faint);
        tip.setGravity(Gravity.CENTER);
        tip.setPadding(0, dp(16), 0, 0);
        col.addView(tip);

        setContentView(page);
        if (hasFingerprintHardware()) startAuth();
        else if (lockHint != null) lockHint.setText(
                hasPin() ? "这台手机没有可用指纹，请用密码解锁" : "这台手机没有可用的指纹硬件");
    }

    /** 调系统指纹验证：28+ 用 BiometricPrompt，24-27 用 FingerprintManager */
    private void startAuth() {
        if (!hasFingerprintHardware()) {
            if (lockHint != null) lockHint.setText("这台手机没有可用的指纹硬件");
            return;
        }
        try {
            if (Build.VERSION.SDK_INT >= 28) {
                java.util.concurrent.Executor exec = getMainExecutor();
                android.hardware.biometrics.BiometricPrompt prompt =
                        new android.hardware.biometrics.BiometricPrompt.Builder(this)
                                .setTitle("解锁分类相机")
                                .setSubtitle("请验证指纹")
                                .setNegativeButton("取消", exec,
                                        new android.content.DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(android.content.DialogInterface d, int w) {
                                                if (lockHint != null) lockHint.setText("已取消，需要指纹才能进入");
                                            }
                                        })
                                .build();
                prompt.authenticate(new android.os.CancellationSignal(), exec,
                        new android.hardware.biometrics.BiometricPrompt.AuthenticationCallback() {
                            @Override
                            public void onAuthenticationSucceeded(
                                    android.hardware.biometrics.BiometricPrompt.AuthenticationResult result) {
                                onUnlocked();
                            }

                            @Override
                            public void onAuthenticationError(int code, CharSequence msg) {
                                if (lockHint != null) lockHint.setText("验证未通过：" + msg);
                            }

                            @Override
                            public void onAuthenticationFailed() {
                                if (lockHint != null) lockHint.setText("指纹不匹配，请再试一次");
                            }
                        });
            } else {
                android.hardware.fingerprint.FingerprintManager fm =
                        (android.hardware.fingerprint.FingerprintManager)
                                getSystemService(FINGERPRINT_SERVICE);
                if (fm == null) {
                    if (lockHint != null) lockHint.setText("系统不支持指纹验证");
                    return;
                }
                if (!fm.isHardwareDetected()) {
                    if (lockHint != null) lockHint.setText("这台手机没有指纹硬件");
                    return;
                }
                if (!fm.hasEnrolledFingerprints()) {
                    if (lockHint != null) lockHint.setText("系统里还没有录入指纹，请先到设置里添加指纹");
                    return;
                }
                fm.authenticate(null, null, 0, new android.hardware.fingerprint.FingerprintManager.AuthenticationCallback() {
                    @Override
                    public void onAuthenticationSucceeded(
                            android.hardware.fingerprint.FingerprintManager.AuthenticationResult result) {
                        onUnlocked();
                    }

                    @Override
                    public void onAuthenticationFailed() {
                        if (lockHint != null) lockHint.setText("指纹不匹配，请再试一次");
                    }

                    @Override
                    public void onAuthenticationError(int code, CharSequence msg) {
                        if (lockHint != null) lockHint.setText(fingerprintError(code, msg));
                    }
                }, null);
            }
        } catch (Throwable t) {
            if (lockHint != null) lockHint.setText("调不起指纹验证：" + t.getMessage());
        }
    }

    /** 危险操作前的指纹验证（没有指纹硬件时退回二次确认） */
    private void authThen(final String title, final Runnable action) {
        if (hasFingerprintHardware()) {
            try {
                if (Build.VERSION.SDK_INT >= 28) {
                    java.util.concurrent.Executor exec = getMainExecutor();
                    new android.hardware.biometrics.BiometricPrompt.Builder(this)
                            .setTitle(title)
                            .setSubtitle("验证指纹后才会执行")
                            .setNegativeButton("取消", exec, null)
                            .build()
                            .authenticate(new android.os.CancellationSignal(), exec,
                                    new android.hardware.biometrics.BiometricPrompt.AuthenticationCallback() {
                                        @Override
                                        public void onAuthenticationSucceeded(
                                                android.hardware.biometrics.BiometricPrompt.AuthenticationResult result) {
                                            runOnUiThread(action);
                                        }

                                        @Override
                                        public void onAuthenticationError(int code, CharSequence msg) {
                                            runOnUiThread(new Runnable() {
                                                @Override
                                                public void run() {
                                                    Toast.makeText(MainActivity.this,
                                                            "验证未通过，未执行", Toast.LENGTH_SHORT).show();
                                                }
                                            });
                                        }
                                    });
                    return;
                }
                android.hardware.fingerprint.FingerprintManager fm =
                        (android.hardware.fingerprint.FingerprintManager)
                                getSystemService(FINGERPRINT_SERVICE);
                if (fm != null && fm.isHardwareDetected() && fm.hasEnrolledFingerprints()) {
                    fm.authenticate(null, null, 0,
                            new android.hardware.fingerprint.FingerprintManager.AuthenticationCallback() {
                                @Override
                                public void onAuthenticationSucceeded(
                                        android.hardware.fingerprint.FingerprintManager.AuthenticationResult result) {
                                    runOnUiThread(action);
                                }

                                @Override
                                public void onAuthenticationError(int code, CharSequence msg) {
                                    runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            Toast.makeText(MainActivity.this,
                                                    "验证失败：" + msg, Toast.LENGTH_SHORT).show();
                                        }
                                    });
                                }
                            }, null);
                    return;
                }
            } catch (Throwable ignored) {
            }
        }
        confirmFallback(title, action);
    }

    private void confirmFallback(String title, final Runnable action) {
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage("这台手机没有可用的指纹，确认删除后不可恢复。")
                .setPositiveButton("确认删除", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        action.run();
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void confirmWipe() {
        new AlertDialog.Builder(this)
                .setTitle("清空全部照片")
                .setMessage("所有项目和照片都会被永久删除，且不会进入系统相册回收，确定吗？")
                .setPositiveButton("继续", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        authThen("验证指纹以清空照片", new Runnable() {
                            @Override
                            public void run() {
                                wipeAll();
                            }
                        });
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void wipeAll() {
        try {
            File dir = new File(getFilesDir(), "projects");
            if (dir.exists()) deleteTree(dir);
            Toast.makeText(this, "已清空全部照片", Toast.LENGTH_SHORT).show();
            build();
        } catch (Throwable t) {
            Toast.makeText(this, "清空失败：" + t.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void deleteTree(File f) {
        if (f.isDirectory()) {
            File[] kids = f.listFiles();
            if (kids != null) {
                for (File k : kids) deleteTree(k);
            }
        }
        //noinspection ResultOfMethodCallIgnored
        f.delete();
    }

    private String fingerprintError(int code, CharSequence msg) {
        if (code == android.hardware.fingerprint.FingerprintManager.FINGERPRINT_ERROR_NO_FINGERPRINTS) {
            return "系统里还没有录入指纹";
        }
        return "验证未完成：" + msg;
    }

    private void onUnlocked() {
        fingerUnlocked = true;
        locked = false;
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                build();
                Toast.makeText(MainActivity.this, "已解锁", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private int dp(int v) {
        return (int) android.util.TypedValue.applyDimension(
                android.util.TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private int statusBarHeight() {
        int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
        return id > 0 ? getResources().getDimensionPixelSize(id) : dp(24);
    }

    private GradientDrawable rounded(int color, float radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp((int) radiusDp));
        return d;
    }

    private void build() {
        scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Night.page);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), statusBarHeight() + dp(14), dp(18), dp(26));
        scroll.addView(root, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        bar.setLayoutParams(blp);

        TextView title = new TextView(this);
        title.setText("分类相机");
        title.setTextSize(24);
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        title.setTextColor(Night.main);
        title.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        bar.addView(title);

        TextView gear = new TextView(this);
        gear.setText("⚙");
        gear.setTextSize(19);
        gear.setTextColor(Night.accent);
        gear.setGravity(Gravity.CENTER);
        gear.setBackground(rounded(Night.card, 12));
        LinearLayout.LayoutParams glp = new LinearLayout.LayoutParams(dp(38), dp(38));
        gear.setLayoutParams(glp);
        gear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showSettings();
            }
        });
        bar.addView(gear);
        root.addView(bar);

        TextView sub = new TextView(this);
        sub.setText("每个项目单独存照片 · 不写入系统相册");
        sub.setTextSize(11);
        sub.setTextColor(Night.sub);
        sub.setPadding(0, dp(6), 0, dp(16));
        root.addView(sub);

        TextView newBtn = new TextView(this);
        newBtn.setText("＋  新建项目");
        newBtn.setTextSize(15);
        newBtn.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        newBtn.setTextColor(0xFFFFFFFF);
        newBtn.setGravity(Gravity.CENTER);
        GradientDrawable nb = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                Night.dark ? new int[]{0xFF3E63D8, 0xFF5C86FF} : new int[]{0xFF2F6BFF, 0xFF4F8DFF});
        nb.setCornerRadius(dp(14));
        newBtn.setBackground(nb);
        LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(48));
        newBtn.setLayoutParams(nlp);
        newBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                askNewProject();
            }
        });
        root.addView(newBtn);

        listBox = new LinearLayout(this);
        listBox.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        llp.topMargin = dp(14);
        listBox.setLayoutParams(llp);
        root.addView(listBox);

        emptyView = new TextView(this);
        emptyView.setText("还没有项目\n点上面的「新建项目」，给这次拍的照片起个名字");
        emptyView.setTextSize(13);
        emptyView.setTextColor(Night.faint);
        emptyView.setGravity(Gravity.CENTER);
        emptyView.setPadding(0, dp(40), 0, dp(40));
        root.addView(emptyView);

        TextView tip = new TextView(this);
        tip.setText("提示：照片存在 App 内部目录，卸载 App 会一起删除；需要留存请用项目里的「分享」导出。");
        tip.setTextSize(11);
        tip.setTextColor(Night.faint);
        tip.setPadding(dp(2), dp(18), dp(2), 0);
        root.addView(tip);

        setContentView(scroll);
        render();
    }

    private void render() {
        listBox.removeAllViews();
        List<Store.Project> projects = Store.list(this);
        emptyView.setVisibility(projects.isEmpty() ? View.VISIBLE : View.GONE);
        for (final Store.Project p : projects) {
            listBox.addView(projectRow(p));
        }
    }

    /** 名称哈希取一组渐变色，同一项目每次颜色一致 */
    private GradientDrawable coverBg(String name) {
        int[][] palette = new int[][]{
                {0xFF5B7CFA, 0xFF8A5CFF},
                {0xFFFF7A59, 0xFFFF4D8D},
                {0xFF1FB877, 0xFF0FA3B1},
                {0xFF9B6BFF, 0xFFC15BFF},
                {0xFFF2A93B, 0xFFEF6C3B},
                {0xFF3B82F6, 0xFF06B6D4},
                {0xFF6A7B8C, 0xFF93A5B8}
        };
        int idx = name == null ? 0 : Math.abs(name.hashCode()) % palette.length;
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR, palette[idx]);
        d.setCornerRadius(dp(16));
        return d;
    }

    private View projectRow(final Store.Project p) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(10), dp(10), dp(14), dp(10));
        GradientDrawable bg = rounded(Night.card, 18);
        bg.setStroke(dp(1), Night.hair);
        card.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(10);
        card.setLayoutParams(lp);

        // 封面：用项目名称做渐变文字块
        FrameLayout coverBox = new FrameLayout(this);
        int size = dp(74);
        coverBox.setBackground(coverBg(p.name));
        coverBox.setClipToOutline(true);
        String label = p.name == null ? "" : p.name.trim();
        TextView coverText = new TextView(this);
        coverText.setText(label);
        coverText.setGravity(Gravity.CENTER);
        coverText.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        coverText.setTextColor(0xFFFFFFFF);
        coverText.setShadowLayer(dp(4), 0, dp(1), 0x40000000);
        coverText.setLetterSpacing(0.02f);
        int len = label.length();
        coverText.setTextSize(len <= 4 ? 16 : (len <= 8 ? 12.5f : 10.5f));
        coverText.setMaxLines(3);
        coverText.setEllipsize(android.text.TextUtils.TruncateAt.END);
        coverText.setPadding(dp(8), dp(6), dp(8), dp(6));
        coverText.setLineSpacing(dp(1), 1f);
        coverBox.addView(coverText, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(size, size);
        clp.rightMargin = dp(14);
        coverBox.setLayoutParams(clp);
        card.addView(coverBox);

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView name = new TextView(this);
        name.setText(p.name);
        name.setTextSize(15);
        name.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        name.setTextColor(Night.main);
        texts.addView(name);

        TextView meta = new TextView(this);
        meta.setText(p.count + " 张 · "
                + new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault())
                .format(new java.util.Date(p.created)));
        meta.setTextSize(11);
        meta.setTextColor(Night.faint);
        meta.setPadding(0, dp(4), 0, 0);
        texts.addView(meta);
        card.addView(texts);

        TextView arrow = new TextView(this);
        arrow.setText("›");
        arrow.setTextSize(20);
        arrow.setTextColor(Night.faint);
        card.addView(arrow);

        card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(MainActivity.this, ProjectActivity.class);
                it.putExtra("dir", p.dir.getAbsolutePath());
                startActivity(it);
            }
        });
        card.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                showProjectMenu(p);
                return true;
            }
        });
        return card;
    }

    private void showProjectMenu(final Store.Project p) {
        new AlertDialog.Builder(this)
                .setTitle(p.name)
                .setItems(new String[]{"重命名", "删除项目"}, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        if (which == 0) {
                            askName("重命名项目", p.name, new NameCallback() {
                                @Override
                                public void onName(String name) {
                                    Store.rename(p.dir, name);
                                    render();
                                }
                            });
                        } else {
                            new AlertDialog.Builder(MainActivity.this)
                                    .setTitle("删除项目")
                                    .setMessage("会连同 " + p.count + " 张照片一起删除，无法恢复。确定吗？")
                                    .setPositiveButton("删除", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface d2, int w2) {
                                            Store.delete(p.dir);
                                            render();
                                        }
                                    })
                                    .setNegativeButton("取消", null)
                                    .show();
                        }
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private interface NameCallback {
        void onName(String name);
    }

    private void askName(String title, String preset, final NameCallback cb) {
        final EditText edit = new EditText(this);
        edit.setSingleLine(true);
        edit.setInputType(InputType.TYPE_CLASS_TEXT);
        if (preset != null) {
            edit.setText(preset);
            edit.setSelection(preset.length());
        }
        LinearLayout wrap = new LinearLayout(this);
        wrap.setPadding(dp(20), dp(6), dp(20), dp(2));
        wrap.addView(edit, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(wrap)
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        String name = edit.getText().toString().trim();
                        if (name.length() == 0) name = "未命名项目";
                        cb.onName(name);
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void askNewProject() {
        askName("新建项目", null, new NameCallback() {
            @Override
            public void onName(String name) {
                Store.Project p = Store.create(MainActivity.this, name);
                Intent it = new Intent(MainActivity.this, ProjectActivity.class);
                it.putExtra("dir", p.dir.getAbsolutePath());
                startActivity(it);
                render();
            }
        });
    }

    // ---------------- 设置 ----------------

    /** 防误卸载：给用户讲清楚，再跳到系统应用锁 */
    private void askAppLock() {
        new AlertDialog.Builder(this)
                .setTitle("防误卸载")
                .setMessage("开启后，别人卸载「分类相机」时需要验证指纹或隐私密码。\n\n"
                        + "路径：设置 > 权限与隐私 > 应用锁 → 找到「分类相机」打开开关\n"
                        + "（部分 ColorOS 版本是：设置 > 隐私 > 应用锁）\n\n"
                        + "指纹/密码校验由系统提供，App 本身不申请任何管控权限；"
                        + "随时可以在系统设置里关掉。")
                .setPositiveButton("去打开", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        openAppLock();
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void openAppLock() {
        String[][] cands = new String[][]{
                {"com.coloros.safecenter",
                        "com.coloros.safecenter.privacy.applock.AppLockActivity"},
                {"com.coloros.safecenter",
                        "com.coloros.safecenter.privacy.applock.AppLockSettingsActivity"},
                {"com.oplus.safecenter",
                        "com.oplus.safecenter.privacy.applock.AppLockActivity"},
                {"com.coloros.privacyguard",
                        "com.coloros.privacyguard.applock.AppLockActivity"},
                {"com.coloros.privacyguard",
                        "com.coloros.privacyguard.setup.PrivacyPasswordActivity"}
        };
        for (String[] c : cands) {
            try {
                Intent it = new Intent();
                it.setComponent(new android.content.ComponentName(c[0], c[1]));
                it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                if (getPackageManager().resolveActivity(it, 0) != null) {
                    startActivity(it);
                    return;
                }
            } catch (Throwable ignored) {
            }
        }
        try {
            Intent it = new Intent(android.provider.Settings.ACTION_SECURITY_SETTINGS);
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(it);
            Toast.makeText(this, "请在系统设置里搜索「应用锁」，给分类相机上锁",
                    Toast.LENGTH_LONG).show();
            return;
        } catch (Throwable ignored) {
        }
        try {
            Intent it = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            it.setData(android.net.Uri.parse("package:" + getPackageName()));
            startActivity(it);
            Toast.makeText(this, "请在系统设置里搜索「应用锁」，给分类相机上锁",
                    Toast.LENGTH_LONG).show();
        } catch (Throwable t) {
            Toast.makeText(this, "打不开系统设置，请手动进入：设置 > 权限与隐私 > 应用锁",
                    Toast.LENGTH_LONG).show();
        }
    }

    private void showSettings() {
        final android.app.Dialog dialog = new android.app.Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(rounded(Night.card, 22));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(18), dp(14), dp(18), dp(4));
        TextView t = new TextView(this);
        t.setText("设置");
        t.setTextSize(17);
        t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        t.setTextColor(Night.main);
        header.addView(t);
        TextView st = new TextView(this);
        st.setText("分类相机 v" + versionName());
        st.setTextSize(10);
        st.setTextColor(Night.faint);
        st.setPadding(0, dp(4), 0, 0);
        header.addView(st);
        card.addView(header);

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(14), dp(6), dp(14), dp(4));

        LinearLayout nightBox = new LinearLayout(this);
        nightBox.setOrientation(LinearLayout.VERTICAL);
        nightBox.setBackground(rounded(Night.soft, 14));
        nightBox.setPadding(dp(12), dp(10), dp(12), dp(10));

        TextView nt = new TextView(this);
        nt.setText("夜间模式");
        nt.setTextSize(13);
        nt.setTextColor(Night.main);
        nightBox.addView(nt);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rlp.topMargin = dp(8);
        row.setLayoutParams(rlp);
        nightBox.addView(row);

        final int cur = getSharedPreferences(PREF, MODE_PRIVATE).getInt("night_mode", 0);
        String[] names = {"跟随系统", "浅色", "深色"};
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            TextView chip = new TextView(this);
            chip.setText(names[i]);
            chip.setTextSize(12);
            chip.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(32), 1f);
            lp.leftMargin = dp(4);
            lp.rightMargin = dp(4);
            chip.setLayoutParams(lp);
            if (i == cur) {
                chip.setBackground(rounded(Night.accent, 11));
                chip.setTextColor(0xFFFFFFFF);
            } else {
                GradientDrawable bg = rounded(Night.dark ? 0xFF2C3644 : 0xFFFFFFFF, 11);
                bg.setStroke(dp(1), Night.hair);
                chip.setBackground(bg);
                chip.setTextColor(Night.sub);
            }
            chip.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    getSharedPreferences(PREF, MODE_PRIVATE).edit()
                            .putInt("night_mode", idx).apply();
                    dialog.dismiss();
                    recreate();
                }
            });
            row.addView(chip);
        }
        body.addView(nightBox);

        // 拍照方式
        LinearLayout shootBox = new LinearLayout(this);
        shootBox.setOrientation(LinearLayout.HORIZONTAL);
        shootBox.setGravity(Gravity.CENTER_VERTICAL);
        shootBox.setBackground(rounded(Night.soft, 14));
        shootBox.setPadding(dp(12), dp(12), dp(10), dp(12));
        LinearLayout.LayoutParams shlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        shlp.topMargin = dp(10);
        shootBox.setLayoutParams(shlp);

        LinearLayout shTexts = new LinearLayout(this);
        shTexts.setOrientation(LinearLayout.VERTICAL);
        shTexts.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView shTitle = new TextView(this);
        shTitle.setText("使用系统相机");
        shTitle.setTextSize(13);
        shTitle.setTextColor(Night.main);
        shTexts.addView(shTitle);
        TextView shSub = new TextView(this);
        shSub.setText("关掉则用 App 内相机，可连续快速拍");
        shSub.setTextSize(10);
        shSub.setTextColor(Night.faint);
        shSub.setPadding(0, dp(2), 0, 0);
        shTexts.addView(shSub);
        shootBox.addView(shTexts);

        final android.widget.Switch shSwitch = new android.widget.Switch(this);
        shSwitch.setChecked(getSharedPreferences(PREF, MODE_PRIVATE)
                .getBoolean("use_system_camera", true));
        shSwitch.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(android.widget.CompoundButton b, boolean checked) {
                getSharedPreferences(PREF, MODE_PRIVATE).edit()
                        .putBoolean("use_system_camera", checked).apply();
            }
        });
        shootBox.addView(shSwitch);
        body.addView(shootBox);

        // 快门声
        LinearLayout soundBox = new LinearLayout(this);
        soundBox.setOrientation(LinearLayout.HORIZONTAL);
        soundBox.setGravity(Gravity.CENTER_VERTICAL);
        soundBox.setBackground(rounded(Night.soft, 14));
        soundBox.setPadding(dp(12), dp(12), dp(10), dp(12));
        LinearLayout.LayoutParams sblp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sblp.topMargin = dp(10);
        soundBox.setLayoutParams(sblp);

        LinearLayout sTexts = new LinearLayout(this);
        sTexts.setOrientation(LinearLayout.VERTICAL);
        sTexts.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView sTitle = new TextView(this);
        sTitle.setText("快门声音");
        sTitle.setTextSize(13);
        sTitle.setTextColor(Night.main);
        sTexts.addView(sTitle);
        TextView sSub = new TextView(this);
        sSub.setText("仅对 App 内相机有效，部分手机系统强制保留快门声");
        sSub.setTextSize(10);
        sSub.setTextColor(Night.faint);
        sSub.setPadding(0, dp(2), 0, 0);
        sTexts.addView(sSub);
        soundBox.addView(sTexts);

        final android.widget.Switch sSwitch = new android.widget.Switch(this);
        sSwitch.setChecked(getSharedPreferences(PREF, MODE_PRIVATE)
                .getBoolean("shutter_sound", true));
        sSwitch.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(android.widget.CompoundButton b, boolean checked) {
                getSharedPreferences(PREF, MODE_PRIVATE).edit()
                        .putBoolean("shutter_sound", checked).apply();
            }
        });
        soundBox.addView(sSwitch);
        body.addView(soundBox);

        // 指纹解锁
        LinearLayout lockBox = new LinearLayout(this);
        lockBox.setOrientation(LinearLayout.HORIZONTAL);
        lockBox.setGravity(Gravity.CENTER_VERTICAL);
        lockBox.setBackground(rounded(Night.soft, 14));
        lockBox.setPadding(dp(12), dp(12), dp(10), dp(12));
        LinearLayout.LayoutParams lklp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lklp.topMargin = dp(10);
        lockBox.setLayoutParams(lklp);

        LinearLayout lTexts = new LinearLayout(this);
        lTexts.setOrientation(LinearLayout.VERTICAL);
        lTexts.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView lTitle = new TextView(this);
        lTitle.setText("指纹解锁");
        lTitle.setTextSize(13);
        lTitle.setTextColor(Night.main);
        lTexts.addView(lTitle);
        TextView lSub = new TextView(this);
        lSub.setText("打开后每次进入 App 需验证系统指纹");
        lSub.setTextSize(10);
        lSub.setTextColor(Night.faint);
        lSub.setPadding(0, dp(2), 0, 0);
        lTexts.addView(lSub);
        lockBox.addView(lTexts);

        final android.widget.Switch lSwitch = new android.widget.Switch(this);
        lSwitch.setChecked(getSharedPreferences(PREF, MODE_PRIVATE)
                .getBoolean("finger_lock", false));
        lSwitch.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(android.widget.CompoundButton b, boolean checked) {
                if (checked && !hasPin()) {
                    // 开启指纹锁前先强制设置一个解锁密码，保证指纹失灵时能进
                    b.setChecked(false);
                    askSetPin(new Runnable() {
                        @Override
                        public void run() {
                            getSharedPreferences(PREF, MODE_PRIVATE).edit()
                                    .putBoolean("finger_lock", true).apply();
                            fingerUnlocked = false;
                            showPinBoxSub();
                            Toast.makeText(MainActivity.this,
                                    "已开启：指纹或解锁密码可进入", Toast.LENGTH_SHORT).show();
                        }
                    });
                    return;
                }
                getSharedPreferences(PREF, MODE_PRIVATE).edit()
                        .putBoolean("finger_lock", checked).apply();
                if (checked) {
                    fingerUnlocked = false;
                    Toast.makeText(MainActivity.this,
                            "已开启，下次进入 App 需要指纹或密码验证", Toast.LENGTH_SHORT).show();
                }
            }
        });
        lockBox.addView(lSwitch);
        body.addView(lockBox);

        // 解锁密码（指纹失效兜底）
        LinearLayout pinBox = new LinearLayout(this);
        pinBox.setOrientation(LinearLayout.HORIZONTAL);
        pinBox.setGravity(Gravity.CENTER_VERTICAL);
        pinBox.setBackground(rounded(Night.soft, 14));
        pinBox.setPadding(dp(12), dp(12), dp(12), dp(12));
        LinearLayout.LayoutParams pklp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        pklp.topMargin = dp(10);
        pinBox.setLayoutParams(pklp);

        LinearLayout pkTexts = new LinearLayout(this);
        pkTexts.setOrientation(LinearLayout.VERTICAL);
        pkTexts.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView pkTitle = new TextView(this);
        pkTitle.setText("解锁密码");
        pkTitle.setTextSize(13);
        pkTitle.setTextColor(Night.main);
        pkTexts.addView(pkTitle);
        TextView pkSub = new TextView(this);
        pinSub = pkSub;
        pkSub.setText(hasPin() ? "已设置，指纹失灵时可用" : "未设置：开启指纹锁时会要求设置");
        pkSub.setTextSize(10);
        pkSub.setTextColor(Night.faint);
        pkSub.setPadding(0, dp(2), 0, 0);
        pkTexts.addView(pkSub);
        pinBox.addView(pkTexts);

        TextView pkAct = new TextView(this);
        pkAct.setText(hasPin() ? "修改" : "设置");
        pkAct.setTextSize(12);
        pkAct.setTextColor(Night.accent);
        pkAct.setPadding(dp(10), dp(8), dp(6), dp(8));
        pkAct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                askSetPin();
            }
        });
        pinBox.addView(pkAct);

        body.addView(pinBox);

        // 防误卸载：引导开启系统应用锁
        LinearLayout appLockBox = new LinearLayout(this);
        appLockBox.setOrientation(LinearLayout.HORIZONTAL);
        appLockBox.setGravity(Gravity.CENTER_VERTICAL);
        appLockBox.setBackground(rounded(Night.soft, 14));
        appLockBox.setPadding(dp(12), dp(12), dp(12), dp(12));
        LinearLayout.LayoutParams alblp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        alblp.topMargin = dp(10);
        appLockBox.setLayoutParams(alblp);

        LinearLayout alTexts = new LinearLayout(this);
        alTexts.setOrientation(LinearLayout.VERTICAL);
        alTexts.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView alTitle = new TextView(this);
        alTitle.setText("防误卸载");
        alTitle.setTextSize(13);
        alTitle.setTextColor(Night.main);
        alTexts.addView(alTitle);
        TextView alSub = new TextView(this);
        alSub.setText("开启系统应用锁后，卸载本 App 需验证指纹或隐私密码");
        alSub.setTextSize(10);
        alSub.setTextColor(Night.faint);
        alSub.setPadding(0, dp(2), 0, 0);
        alTexts.addView(alSub);
        appLockBox.addView(alTexts);

        TextView alAct = new TextView(this);
        alAct.setText("去设置");
        alAct.setTextSize(12);
        alAct.setTextColor(Night.accent);
        alAct.setPadding(dp(10), dp(8), dp(6), dp(8));
        alAct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                askAppLock();
            }
        });
        appLockBox.addView(alAct);
        body.addView(appLockBox);

        // 检查更新
        LinearLayout otaBox = new LinearLayout(this);
        otaBox.setOrientation(LinearLayout.HORIZONTAL);
        otaBox.setGravity(Gravity.CENTER_VERTICAL);
        otaBox.setBackground(rounded(Night.soft, 14));
        otaBox.setPadding(dp(12), dp(12), dp(12), dp(12));
        LinearLayout.LayoutParams olp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        olp.topMargin = dp(10);
        otaBox.setLayoutParams(olp);

        LinearLayout oTexts = new LinearLayout(this);
        oTexts.setOrientation(LinearLayout.VERTICAL);
        oTexts.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView oTitle = new TextView(this);
        oTitle.setText("检查更新");
        oTitle.setTextSize(13);
        oTitle.setTextColor(Night.main);
        oTexts.addView(oTitle);
        TextView oSub = new TextView(this);
        oSub.setText("当前 v" + versionName());
        oSub.setTextSize(10);
        oSub.setTextColor(Night.faint);
        oSub.setPadding(0, dp(2), 0, 0);
        oTexts.addView(oSub);
        otaBox.addView(oTexts);

        TextView oBtn = new TextView(this);
        oBtn.setText("检查");
        oBtn.setTextSize(12);
        oBtn.setTextColor(Night.accent);
        oBtn.setPadding(dp(10), dp(6), dp(4), dp(6));
        oBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ota == null) ota = new OtaManager(MainActivity.this);
                ota.checkUpdate(true);
            }
        });
        otaBox.addView(oBtn);
        body.addView(otaBox);

        // 下载进度（后台下载后可重新调回前台）
        LinearLayout dlBox = new LinearLayout(this);
        dlBox.setOrientation(LinearLayout.HORIZONTAL);
        dlBox.setGravity(Gravity.CENTER_VERTICAL);
        dlBox.setBackground(rounded(Night.soft, 14));
        dlBox.setPadding(dp(12), dp(12), dp(12), dp(12));
        LinearLayout.LayoutParams dllp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dllp.topMargin = dp(10);
        dlBox.setLayoutParams(dllp);

        LinearLayout dTexts = new LinearLayout(this);
        dTexts.setOrientation(LinearLayout.VERTICAL);
        dTexts.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView dTitle = new TextView(this);
        dTitle.setText("下载进度");
        dTitle.setTextSize(13);
        dTitle.setTextColor(Night.main);
        dTexts.addView(dTitle);
        final TextView dSub = new TextView(this);
        String dlState = (ota != null && ota.isDownloading())
                ? ("正在下载 " + ota.progressPercent() + "%") : "没有进行中的下载";
        dSub.setText(dlState);
        dSub.setTextSize(10);
        dSub.setTextColor(Night.faint);
        dSub.setPadding(0, dp(2), 0, 0);
        dTexts.addView(dSub);
        dlBox.addView(dTexts);

        TextView dBtn = new TextView(this);
        dBtn.setText("查看");
        dBtn.setTextSize(12);
        dBtn.setTextColor(Night.accent);
        dBtn.setPadding(dp(10), dp(6), dp(4), dp(6));
        dBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ota == null) ota = new OtaManager(MainActivity.this);
                ota.reopenProgress();
                dialog.dismiss();
            }
        });
        dlBox.addView(dBtn);
        body.addView(dlBox);

        TextView hint = new TextView(this);
        hint.setText("照片保存在 App 私有目录（files/projects），不会出现在系统相册。"
                + "卸载时若想保留照片，请在系统卸载弹窗里勾选「保留应用数据」；"
                + "不勾选则照片会被系统一并清除。");
        hint.setTextSize(11);
        hint.setTextColor(Night.faint);
        hint.setPadding(dp(6), dp(14), dp(6), dp(6));
        body.addView(hint);
        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(true);
        sv.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);
        sv.setClipToPadding(false);
        sv.addView(body, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        card.addView(sv, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        TextView done = new TextView(this);
        done.setText("完成");
        done.setTextSize(14);
        done.setTextColor(Night.accent);
        done.setGravity(Gravity.CENTER);
        done.setBackground(rounded(Night.dark ? 0xFF232C3E : 0xFFF1F5FF, 14));
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(44));
        dlp.setMargins(dp(14), dp(6), dp(14), dp(14));
        done.setLayoutParams(dlp);
        done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        card.addView(done);

        card.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        dialog.setContentView(card);
        Window w = dialog.getWindow();
        int maxH = (int) (getResources().getDisplayMetrics().heightPixels * 0.82f);
        if (w != null) {
            w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0x00000000));
            w.setLayout(getResources().getDisplayMetrics().widthPixels - dp(44), maxH);
        }
        dialog.show();
    }

    private String versionName() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Throwable t) {
            return "?";
        }
    }

    @Override
    protected void onDestroy() {
        if (ota != null) ota.release();
        super.onDestroy();
    }
}
