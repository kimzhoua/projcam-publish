package com.example.projcam;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * 项目导出：ZIP（原图+文档网页）/ 单文件 HTML / PDF。
 * 生成的文件会写入公共目录 Download/分类相机导出/，任何设备不装 App 也能看。
 */
final class Exporter {

    static File exportDir(Context c) {
        File d = new File(c.getCacheDir(), "export");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    static String safe(String s) {
        return s.replaceAll("[\\\\/:*?\"<>|]", "_");
    }

    // ===================== ZIP =====================

    static File exportZip(Context c, File project) throws Exception {
        String name = safe(Store.nameOf(project));
        File out = new File(exportDir(c), name + "-项目导出.zip");
        ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(out));
        List<File> photos = photosOf(project);
        List<Docs.Doc> docs = Docs.list(project);

        for (File p : photos) {
            zos.putNextEntry(new ZipEntry("照片/" + p.getName()));
            writeFileToZip(zos, p);
            zos.closeEntry();
        }
        for (Docs.Doc d : docs) {
            zos.putNextEntry(new ZipEntry("文档/" + safe(d.name) + ".html"));
            String html = fullDocPage(d);
            zos.write(html.getBytes("UTF-8"));
            zos.closeEntry();
        }
        zos.putNextEntry(new ZipEntry("说明.html"));
        zos.write(indexHtml(project, photos, docs).getBytes("UTF-8"));
        zos.closeEntry();
        zos.close();
        return out;
    }

    private static void writeFileToZip(ZipOutputStream zos, File f) throws Exception {
        FileInputStream in = new FileInputStream(f);
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) zos.write(buf, 0, n);
        in.close();
    }

    private static String fullDocPage(Docs.Doc d) {
        return "<!DOCTYPE html><html><head><meta charset=\"utf-8\">"
                + "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
                + "<title>" + esc(d.name) + "</title><style>"
                + "body{font-family:-apple-system,'Noto Sans CJK SC',sans-serif;max-width:760px;"
                + "margin:24px auto;padding:0 16px;line-height:1.8;color:#1b2230;}"
                + "img{max-width:100%;border-radius:10px;margin:10px 0;}"
                + "h2{font-size:22px;}hr{border:none;border-top:1px solid #e3e8f2;margin:6px 0;}"
                + "</style></head><body><h1>" + esc(d.name) + "</h1>" + Docs.read(d.file)
                + "</body></html>";
    }

    private static String indexHtml(File project, List<File> photos, List<Docs.Doc> docs) {
        StringBuilder sb = new StringBuilder();
        sb.append("<!DOCTYPE html><html><head><meta charset=\"utf-8\">")
                .append("<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">")
                .append("<title>").append(esc(Store.nameOf(project))).append("</title>")
                .append("<style>body{font-family:-apple-system,'Noto Sans CJK SC',sans-serif;")
                .append("max-width:860px;margin:0 auto;padding:20px;line-height:1.6;color:#1b2230;}")
                .append("h1{font-size:24px;}h2{font-size:18px;margin-top:28px;border-left:4px solid #2f6bff;")
                .append("padding-left:10px;}a{color:#2f6bff;text-decoration:none;}")
                .append(".grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:8px;}")
                .append(".grid img{width:100%;border-radius:8px;}")
                .append(".p{overflow:hidden;border-radius:8px;}")
                .append("</style></head><body>")
                .append("<h1>").append(esc(Store.nameOf(project))).append("</h1>")
                .append("<div style=\"color:#6b7482;font-size:13px\">")
                .append(photos.size()).append(" 张照片 · ").append(docs.size()).append(" 篇文档</div>");

        if (!docs.isEmpty()) {
            sb.append("<h2>文档</h2><ul>");
            for (Docs.Doc d : docs) {
                sb.append("<li><a href=\"文档/").append(esc(safe(d.name)).replace(" ", "%20"))
                        .append(".html\">").append(esc(d.name)).append("</a></li>");
            }
            sb.append("</ul>");
        }
        if (!photos.isEmpty()) {
            sb.append("<h2>照片</h2><div class=\"grid\">");
            for (File p : photos) {
                sb.append("<div class=\"p\"><a href=\"照片/").append(esc(p.getName()))
                        .append("\"><img src=\"照片/").append(esc(p.getName())).append("\"></a></div>");
            }
            sb.append("</div>");
        }
        sb.append("</body></html>");
        return sb.toString();
    }

    // ===================== 单文件 HTML =====================

    static File exportHtml(Context c, File project) throws Exception {
        String name = safe(Store.nameOf(project));
        File out = new File(exportDir(c), name + "-项目.html");
        List<File> photos = photosOf(project);
        List<Docs.Doc> docs = Docs.list(project);

        StringBuilder sb = new StringBuilder();
        sb.append("<!DOCTYPE html><html><head><meta charset=\"utf-8\">")
                .append("<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">")
                .append("<title>").append(esc(Store.nameOf(project))).append("</title>")
                .append("<style>body{font-family:-apple-system,'Noto Sans CJK SC',sans-serif;")
                .append("max-width:820px;margin:0 auto;padding:18px;color:#1b2230;line-height:1.8;}")
                .append("h2{font-size:19px;margin-top:30px;border-left:4px solid #2f6bff;padding-left:10px;}")
                .append("img{max-width:100%;border-radius:10px;margin:10px 0;display:block;}")
                .append("hr{border:none;border-top:1px solid #e3e8f2;margin:2px 0;}")
                .append(".doc{border:1px solid #e3e8f2;border-radius:12px;padding:14px;margin:12px 0;}")
                .append(".cap{color:#6b7482;font-size:12px;}")
                .append("</style></head><body>")
                .append("<h1>").append(esc(Store.nameOf(project))).append("</h1>");

        if (!docs.isEmpty()) {
            sb.append("<h2>文档</h2>");
            for (Docs.Doc d : docs) {
                sb.append("<div class=\"doc\"><h3>").append(esc(d.name)).append("</h3>")
                        .append(Docs.read(d.file)).append("</div>");
            }
        }
        if (!photos.isEmpty()) {
            sb.append("<h2>照片</h2>");
            for (File p : photos) {
                String b64 = jpegBase64(p, 1440, 80);
                if (b64 == null) continue;
                sb.append("<figure style=\"margin:14px 0\"><img src=\"data:image/jpeg;base64,")
                        .append(b64).append("\"><div class=\"cap\">").append(esc(p.getName()))
                        .append("</div></figure>");
            }
        }
        sb.append("</body></html>");

        FileOutputStream fos = new FileOutputStream(out);
        fos.write(sb.toString().getBytes("UTF-8"));
        fos.close();
        return out;
    }

    private static String jpegBase64(File f, int maxW, int quality) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(f.getAbsolutePath(), o);
            int scale = 1;
            while (o.outWidth / scale > maxW) scale *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = scale;
            Bitmap b = BitmapFactory.decodeFile(f.getAbsolutePath(), o2);
            if (b == null) return null;
            if (b.getWidth() > maxW) {
                b = Bitmap.createScaledBitmap(b, maxW, b.getHeight() * maxW / b.getWidth(), true);
            }
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            b.compress(Bitmap.CompressFormat.JPEG, quality, bo);
            b.recycle();
            return Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP);
        } catch (Throwable t) {
            return null;
        }
    }

    // ===================== PDF =====================

    /** 每一页先画成图片，再以 JPEG 塞进极简 PDF（无需第三方库，中文由系统字体渲染） */
    static File exportPdf(Context c, File project) throws Exception {
        String name = safe(Store.nameOf(project));
        File out = new File(exportDir(c), name + "-项目.pdf");
        List<File> photos = photosOf(project);
        List<Docs.Doc> docs = Docs.list(project);

        List<byte[]> pages = new ArrayList<>();
        List<int[]> sizes = new ArrayList<>();

        // 封面
        Bitmap cover = pageBitmap();
        Canvas cc = new Canvas(cover);
        cc.drawColor(Color.WHITE);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(0xFF1B2230);
        p.setTextSize(64);
        p.setFakeBoldText(true);
        cc.drawText(Store.nameOf(project), 80, 260, p);
        p.setTextSize(32);
        p.setFakeBoldText(false);
        p.setColor(0xFF6B7482);
        cc.drawText(photos.size() + " 张照片 · " + docs.size() + " 篇文档", 80, 320, p);
        p.setTextSize(26);
        cc.drawText(new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm",
                java.util.Locale.CHINA).format(new java.util.Date()), 80, 360, p);
        addPage(pages, sizes, cover);

        // 文档
        for (Docs.Doc d : docs) {
            renderDoc(d, pages, sizes);
        }
        // 照片
        for (File f : photos) {
            Bitmap b = BitmapFactory.decodeFile(f.getAbsolutePath());
            if (b == null) continue;
            Bitmap page = pageBitmap();
            Canvas cv = new Canvas(page);
            cv.drawColor(Color.WHITE);
            int margin = 60;
            float maxW = page.getWidth() - margin * 2f;
            float maxH = page.getHeight() - margin * 2f - 60;
            float sc = Math.min(maxW / b.getWidth(), maxH / b.getHeight());
            int w = (int) (b.getWidth() * sc), h = (int) (b.getHeight() * sc);
            cv.drawBitmap(Bitmap.createScaledBitmap(b, w, h, true),
                    (page.getWidth() - w) / 2f, margin, null);
            Paint cp = new Paint(Paint.ANTI_ALIAS_FLAG);
            cp.setColor(0xFF8C97A8);
            cp.setTextSize(24);
            cv.drawText(f.getName(), margin, page.getHeight() - margin + 10, cp);
            b.recycle();
            addPage(pages, sizes, page);
        }

        PdfBuilder pdf = new PdfBuilder();
        for (int i = 0; i < pages.size(); i++) {
            ByteArrayOutputStream jpg = new ByteArrayOutputStream();
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            // pages 里已经是 jpeg 字节
            pdf.addJpegPage(pages.get(i), sizes.get(i)[0], sizes.get(i)[1]);
        }
        pdf.write(out);
        return out;
    }

    private static Bitmap pageBitmap() {
        return Bitmap.createBitmap(1240, 1754, Bitmap.Config.ARGB_8888);
    }

    private static void addPage(List<byte[]> pages, List<int[]> sizes, Bitmap bmp) {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, 82, bo);
        pages.add(bo.toByteArray());
        sizes.add(new int[]{bmp.getWidth(), bmp.getHeight()});
        bmp.recycle();
    }

    /** 文档渲染成若干页：文字自动换行，图片按宽度缩放 */
    private static void renderDoc(Docs.Doc d, List<byte[]> pages, List<int[]> sizes) {
        Bitmap page = pageBitmap();
        Canvas cv = new Canvas(page);
        cv.drawColor(Color.WHITE);
        Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
        tp.setColor(0xFF1B2230);
        tp.setTextSize(30);

        int margin = 70;
        float y = margin + 40;
        float maxW = page.getWidth() - margin * 2f;

        // 标题
        tp.setFakeBoldText(true);
        tp.setTextSize(46);
        cv.drawText(d.name, margin, y, tp);
        y += 60;
        tp.setFakeBoldText(false);
        tp.setTextSize(30);

        for (Object block : parseDoc(Docs.read(d.file))) {
            if (block instanceof Bitmap) {
                Bitmap img = (Bitmap) block;
                float sc = maxW / img.getWidth();
                int w = (int) maxW, h = (int) (img.getHeight() * sc);
                if (y + h > page.getHeight() - margin) {
                    addPage(pages, sizes, page);
                    page = pageBitmap();
                    cv = new Canvas(page);
                    cv.drawColor(Color.WHITE);
                    y = margin;
                }
                cv.drawBitmap(Bitmap.createScaledBitmap(img, w, h, true), margin, y, null);
                y += h + 16;
                img.recycle();
            } else {
                String text = (String) block;
                String[] lines = text.split("\n");
                for (String line : lines) {
                    if (line.trim().length() == 0) {
                        y += 18;
                        continue;
                    }
                    int start = 0;
                    while (start < line.length()) {
                        int count = tp.breakText(line, start, line.length(), true, maxW, null);
                        if (count <= 0) break;
                        if (y > page.getHeight() - margin) {
                            addPage(pages, sizes, page);
                            page = pageBitmap();
                            cv = new Canvas(page);
                            cv.drawColor(Color.WHITE);
                            y = margin;
                        }
                        cv.drawText(line.substring(start, start + count), margin, y, tp);
                        y += 44;
                        start += count;
                    }
                }
            }
        }
        addPage(pages, sizes, page);
    }

    /** 把文档 HTML 拆成「文字块 / 图片块」序列 */
    private static List<Object> parseDoc(String html) {
        List<Object> out = new ArrayList<>();
        String s = html.replace("<br>", "\n").replace("<br/>", "\n")
                .replace("</div>", "\n").replace("</p>", "\n")
                .replace("</h2>", "\n").replace("</h3>", "\n")
                .replace("</li>", "\n").replace("<hr>", "\n")
                .replace("<hr/>", "\n");
        int pos = 0;
        while (true) {
            int i = s.indexOf("base64,", pos);
            if (i < 0) break;
            int startQ = s.lastIndexOf("data:image", i);
            int endQ = s.indexOf('"', i);
            if (startQ < 0 || endQ < 0) break;
            String text = s.substring(pos, startQ);
            String cleaned = stripTags(text);
            if (cleaned.trim().length() > 0) out.add(cleaned);
            String b64 = s.substring(i + 7, endQ);
            try {
                byte[] raw = Base64.decode(b64, Base64.DEFAULT);
                Bitmap b = BitmapFactory.decodeByteArray(raw, 0, raw.length);
                if (b != null) out.add(b);
            } catch (Throwable ignored) {
            }
            pos = endQ;
        }
        String rest = stripTags(s.substring(Math.min(pos, s.length())));
        if (rest.trim().length() > 0) out.add(rest);
        return out;
    }

    private static String stripTags(String s) {
        String t = s.replaceAll("<[^>]*>", "")
                .replace("&nbsp;", " ").replace("&amp;", "&")
                .replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"");
        return t.replaceAll("[ \\t]+\\n", "\n").replaceAll("\\n{3,}", "\n\n");
    }

    // ===================== 极简 PDF 写入 =====================

    private static final class PdfBuilder {
        private final List<byte[]> jpegs = new ArrayList<>();
        private final List<int[]> dims = new ArrayList<>();

        void addJpegPage(byte[] data, int w, int h) {
            jpegs.add(data);
            dims.add(new int[]{w, h});
        }

        void write(File out) throws Exception {
            buildAll(out);
        }

        private void buildAll(File out) throws Exception {
            ByteArrayOutputStream buf = new ByteArrayOutputStream();
            List<Long> offsets = new ArrayList<>();
            int n = jpegs.size();
            final float PW = 595f, PH = 842f;

            write(buf, "%PDF-1.4\n");
            long off;
            off = buf.size();
            offsets.add(off);
            write(buf, "1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n");

            off = buf.size();
            offsets.add(off);
            StringBuilder kids = new StringBuilder();
            for (int i = 0; i < n; i++) kids.append(3 + i).append(" 0 R ");
            write(buf, "2 0 obj\n<< /Type /Pages /Count " + n + " /Kids ["
                    + kids.toString().trim() + "] >>\nendobj\n");

            // 页面对象：编号 3..3+n-1；内容流：3+n..；图片：3+2n..
            for (int i = 0; i < n; i++) {
                off = buf.size();
                offsets.add(off);
                int contentId = 3 + n + i;
                int imgId = 3 + n * 2 + i;
                write(buf, (3 + i) + " 0 obj\n<< /Type /Page /Parent 2 0 R "
                        + "/MediaBox [0 0 " + PW + " " + PH + "] "
                        + "/Resources << /XObject << /Im" + i + " " + imgId + " 0 R >> >> "
                        + "/Contents " + contentId + " 0 R >>\nendobj\n");
            }

            // 内容流：整页铺满并保持比例
            for (int i = 0; i < n; i++) {
                int[] wh = dims.get(i);
                float scale = Math.min((PW - 48) / wh[0], (PH - 48) / wh[1]);
                float w = wh[0] * scale, h = wh[1] * scale;
                float x = (PW - w) / 2f, y = (PH - h) / 2f;
                String content = "q " + w + " 0 0 " + h + " " + x + " " + y + " cm /Im" + i + " Do Q\n";
                off = buf.size();
                offsets.add(off);
                write(buf, (3 + n + i) + " 0 obj\n<< /Length " + content.length() + " >>\nstream\n"
                        + content + "endstream\nendobj\n");
            }

            // 图片对象
            for (int i = 0; i < n; i++) {
                int[] wh = dims.get(i);
                byte[] data = jpegs.get(i);
                off = buf.size();
                offsets.add(off);
                write(buf, (3 + n * 2 + i) + " 0 obj\n<< /Type /XObject /Subtype /Image "
                        + "/Width " + wh[0] + " /Height " + wh[1]
                        + " /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode "
                        + "/Length " + data.length + " >>\nstream\n");
                buf.write(data);
                write(buf, "\nendstream\nendobj\n");
            }

            long xref = buf.size();
            int total = offsets.size() + 1;
            write(buf, "xref\n0 " + total + "\n");
            write(buf, "0000000000 65535 f \n");
            for (long o : offsets) {
                write(buf, String.format(java.util.Locale.US, "%010d 00000 n \n", o));
            }
            write(buf, "trailer\n<< /Size " + total + " /Root 1 0 R >>\nstartxref\n"
                    + xref + "\n%%EOF\n");

            FileOutputStream fos = new FileOutputStream(out);
            fos.write(buf.toByteArray());
            fos.close();
        }

        private static void write(ByteArrayOutputStream b, String s) throws Exception {
            b.write(s.getBytes("ISO-8859-1"));
        }
    }

    // ===================== 保存到公共目录 =====================

    static Uri publish(Context c, File src, String mime, String displayName) {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                ContentResolver cr = c.getContentResolver();
                ContentValues v = new ContentValues();
                v.put(MediaStore.Downloads.DISPLAY_NAME, displayName);
                v.put(MediaStore.Downloads.MIME_TYPE, mime);
                v.put(MediaStore.Downloads.RELATIVE_PATH, "Download/分类相机导出");
                Uri uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (uri == null) return null;
                OutputStream os = cr.openOutputStream(uri);
                if (os == null) return null;
                FileInputStream in = new FileInputStream(src);
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
                in.close();
                os.close();
                return uri;
            } else {
                File dir = new File(Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_DOWNLOADS), "分类相机导出");
                if (!dir.exists()) dir.mkdirs();
                File dst = new File(dir, displayName);
                FileInputStream in = new FileInputStream(src);
                FileOutputStream os = new FileOutputStream(dst);
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
                in.close();
                os.close();
                return Uri.fromFile(dst);
            }
        } catch (Throwable t) {
            return null;
        }
    }

    private static List<File> photosOf(File project) {
        List<File> out = new ArrayList<>();
        File[] fs = project.listFiles();
        if (fs == null) return out;
        for (File f : fs) {
            if (f.isFile() && f.getName().endsWith(".jpg")) out.add(f);
        }
        java.util.Collections.sort(out, new java.util.Comparator<File>() {
            @Override
            public int compare(File a, File b) {
                return Long.compare(a.lastModified(), b.lastModified());
            }
        });
        return out;
    }

    private static String esc(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;");
    }
}
