package com.example.projcam;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Base64;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.X509EncodedKeySpec;

/**
 * 应用内在线更新。
 *
 * <p>清单是单文件自包含签名：{"payload":"<清单原文>","sig":"<RSA-SHA256>"}。
 * 只有验签通过才会使用清单；下载完成后校验 sha256，不一致拒绝安装。
 */
public class OtaManager {

    private static final String MANIFEST_URL =
            "https://cdn.jsdelivr.net/gh/kimzhoua/projcam-publish@main/dist/update.json";

    private static final String MANIFEST_PUBKEY =
            "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA+IwWupZK5kkPnX9SOhWTWO1GEl5qxXG2Ewkr9lx1YtV14Ll3lKwG26nm+4GI2i3Gip+tIr3u4jPwWKbZnk9KvKBd2gnZZbYsylSf3N2U0dUN6y9CFcCfsGg4lMom/pc7r8Kco+QxUUzh2N6ZT0W7BkvzzqWws80V7btWg/t5LizDFTRtc1wdbk3rzaRnAiAEhPkyPgIM08sNQ25Oha5bk8KTrAfRgWf8LABAiIKfBEej2/sDwnJ+gnCpigWhHUXbD7RxS0wkfNw1OFHr5VNmOl8Jcc3r8wWZS8/n9GOS4TzOEVcfLvx1zV7HD2ScWwoclVkYnX4qJIiMm3w2y7tIQwIDAQAB";

    private final Activity activity;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private long downloadId = -1L;
    private String expectSha256;
    private boolean receiverRegistered;

    public OtaManager(Activity activity) {
        this.activity = activity;
    }

    private volatile String lastError = "";

    public void checkUpdate(final boolean manual) {
        if (manual) Toast.makeText(activity, "正在检查更新…", Toast.LENGTH_SHORT).show();
        new Thread(new Runnable() {
            @Override
            public void run() {
                String payload = null;
                for (String candidate : candidates(MANIFEST_URL)) {
                    boolean viaApi = candidate.startsWith("https://api.github.com/");
                    String wrapper = httpGet(candidate,
                            viaApi ? "application/vnd.github.raw,*/*" : "application/json,*/*");
                    if (wrapper == null) {
                        lastError = lastHttp != null ? lastHttp : "网络异常";
                        continue;
                    }
                    if (!wrapper.contains("payload")) {
                        lastError = "清单格式异常";
                        continue;
                    }
                    String body;
                    String sig;
                    try {
                        JSONObject w = new JSONObject(wrapper);
                        body = w.optString("payload", "");
                        sig = w.optString("sig", "");
                    } catch (Exception e) {
                        continue;
                    }
                    if (body.length() == 0) {
                        lastError = "清单为空";
                        continue;
                    }
                    if (!verify(body, sig)) {
                        lastError = "清单签名校验未通过";
                        continue;
                    }
                    payload = body;
                    break;
                }
                if (payload == null) {
                    ui.post(new Runnable() {
                        @Override
                        public void run() {
                            if (manual) {
                                Toast.makeText(activity,
                                        "检查更新失败：" + (lastError.length() > 0 ? lastError : "网络异常"),
                                        Toast.LENGTH_LONG).show();
                            }
                        }
                    });
                    return;
                }
                JSONObject obj;
                try {
                    obj = new JSONObject(payload);
                } catch (Exception e) {
                    return;
                }
                final int newCode = obj.optInt("versionCode", 0);
                final String newName = obj.optString("versionName", "");
                final String apkUrl = obj.optString("apkUrl", "");
                final String notes = obj.optString("notes", "");
                final String sha = obj.optString("sha256", "");
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        if (newCode > installedVersionCode() && apkUrl.length() > 0) {
                            showDialog(newName, newCode, apkUrl, notes, sha);
                        } else if (manual) {
                            Toast.makeText(activity,
                                    "已是最新版本 v" + installedVersionName(),
                                    Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        }).start();
    }

    private void showDialog(final String newName, final int newCode, final String apkUrl,
                            String notes, final String sha256) {
        String message = "当前版本 v" + installedVersionName()
                + "\n新版本 v" + newName + "（" + newCode + "）";
        if (notes != null && notes.length() > 0) message += "\n\n更新说明：\n" + notes;
        new AlertDialog.Builder(activity)
                .setTitle("发现新版本")
                .setMessage(message)
                .setPositiveButton("下载并安装", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        download(apkUrl, newName, sha256);
                    }
                })
                .setNegativeButton("以后再说", null)
                .show();
    }

    private android.app.AlertDialog progressDialog;
    private android.widget.ProgressBar progressBar;
    private android.widget.TextView progressText;
    private final Handler poller = new Handler(Looper.getMainLooper());
    private Runnable pollTask;

    private void download(String apkUrl, String versionName, String sha256) {
        expectSha256 = sha256;
        try {
            String ts = String.valueOf(System.currentTimeMillis());
            String raw = toRawUrl(apkUrl);
            String target = withTs(raw != null ? raw : apkUrl, ts);
            DownloadManager.Request req = new DownloadManager.Request(Uri.parse(target));
            req.setTitle("项目相机 v" + versionName);
            req.setDescription("正在下载新版本");
            req.setMimeType("application/vnd.android.package-archive");
            // 不再占用通知栏，进度改在 App 内显示
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_HIDDEN);
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,
                    "项目相机-v" + versionName + ".apk");
            DownloadManager dm = (DownloadManager) activity.getSystemService(Context.DOWNLOAD_SERVICE);
            if (dm == null) {
                Toast.makeText(activity, "系统下载服务不可用", Toast.LENGTH_SHORT).show();
                return;
            }
            registerReceiver();
            downloadId = dm.enqueue(req);
            showProgress(versionName);
        } catch (Exception e) {
            Toast.makeText(activity, "下载失败：" + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    /** 前台进度弹窗：可取消，也可转为后台静默下载 */
    private void showProgress(final String versionName) {
        Activity a = activity;
        android.widget.LinearLayout box = new android.widget.LinearLayout(a);
        box.setOrientation(android.widget.LinearLayout.VERTICAL);
        int pad = (int) (16 * a.getResources().getDisplayMetrics().density);
        box.setPadding(pad, pad, pad, pad);

        progressText = new android.widget.TextView(a);
        progressText.setText("正在下载 v" + versionName + "… 0%");
        progressText.setTextSize(13);
        box.addView(progressText);

        progressBar = new android.widget.ProgressBar(a, null,
                android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setProgress(0);
        android.widget.LinearLayout.LayoutParams lp =
                new android.widget.LinearLayout.LayoutParams(
                        android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                        (int) (10 * a.getResources().getDisplayMetrics().density));
        lp.topMargin = pad / 2;
        progressBar.setLayoutParams(lp);
        box.addView(progressBar);

        progressDialog = new android.app.AlertDialog.Builder(a)
                .setTitle("下载新版本")
                .setView(box)
                .setPositiveButton("后台下载", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        Toast.makeText(activity, "已转到后台下载，完成后会提示安装",
                                Toast.LENGTH_SHORT).show();
                        stopPolling();
                    }
                })
                .setNegativeButton("取消下载", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        cancelDownload();
                    }
                })
                .setCancelable(true)
                .show();

        startPolling();
    }

    private void startPolling() {
        stopPolling();
        pollTask = new Runnable() {
            @Override
            public void run() {
                updateProgress();
                if (pollTask != null) poller.postDelayed(this, 500);
            }
        };
        poller.post(pollTask);
    }

    private void stopPolling() {
        if (pollTask != null) {
            poller.removeCallbacks(pollTask);
            pollTask = null;
        }
    }

    private void updateProgress() {
        try {
            DownloadManager dm = (DownloadManager) activity.getSystemService(Context.DOWNLOAD_SERVICE);
            if (dm == null || downloadId < 0) return;
            DownloadManager.Query q = new DownloadManager.Query();
            q.setFilterById(downloadId);
            android.database.Cursor c = dm.query(q);
            if (c == null) return;
            try {
                if (!c.moveToFirst()) return;
                int status = c.getInt(c.getColumnIndex(DownloadManager.COLUMN_STATUS));
                long total = c.getLong(c.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));
                long done = c.getLong(c.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
                int pct = total > 0 ? (int) (done * 100 / total) : 0;
                if (progressBar != null) progressBar.setProgress(pct);
                if (progressText != null) {
                    progressText.setText("正在下载… " + pct + "%  ("
                            + mb(done) + " / " + mb(total) + ")");
                }
                if (status == DownloadManager.STATUS_FAILED) {
                    dismissProgress();
                    stopPolling();
                    Toast.makeText(activity, "下载失败，请重试", Toast.LENGTH_SHORT).show();
                } else if (status == DownloadManager.STATUS_SUCCESSFUL) {
                    dismissProgress();
                    stopPolling();
                }
            } finally {
                c.close();
            }
        } catch (Exception ignored) {
        }
    }

    private String mb(long bytes) {
        if (bytes <= 0) return "?";
        return String.format("%.1fMB", bytes / 1024.0 / 1024.0);
    }

    private void dismissProgress() {
        if (progressDialog != null && progressDialog.isShowing()) {
            try {
                progressDialog.dismiss();
            } catch (Exception ignored) {
            }
        }
        progressDialog = null;
        progressBar = null;
        progressText = null;
    }

    private void cancelDownload() {
        stopPolling();
        dismissProgress();
        try {
            DownloadManager dm = (DownloadManager) activity.getSystemService(Context.DOWNLOAD_SERVICE);
            if (dm != null && downloadId >= 0) dm.remove(downloadId);
        } catch (Exception ignored) {
        }
        downloadId = -1L;
        Toast.makeText(activity, "已取消下载", Toast.LENGTH_SHORT).show();
    }

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            long id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L);
            if (id != downloadId) return;
            stopPolling();
            dismissProgress();
            DownloadManager dm = (DownloadManager) activity.getSystemService(Context.DOWNLOAD_SERVICE);
            if (dm == null) return;
            final Uri uri = dm.getUriForDownloadedFile(id);
            if (uri == null) {
                Toast.makeText(activity, "下载失败，请重试", Toast.LENGTH_SHORT).show();
                return;
            }
            final String expect = expectSha256;
            if (expect == null || expect.length() == 0) {
                install(uri);
                return;
            }
            new Thread(new Runnable() {
                @Override
                public void run() {
                    final boolean ok = expect.equalsIgnoreCase(sha256Of(uri));
                    ui.post(new Runnable() {
                        @Override
                        public void run() {
                            if (ok) install(uri);
                            else Toast.makeText(activity,
                                    "安装包校验失败，已取消安装", Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }).start();
        }
    };

    private void registerReceiver() {
        if (receiverRegistered) return;
        IntentFilter filter = new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE);
        // 下载完成广播由系统下载服务发出，Android 13+ 必须显式声明导出
        if (Build.VERSION.SDK_INT >= 33) {
            activity.registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED);
        } else {
            activity.registerReceiver(receiver, filter);
        }
        receiverRegistered = true;
    }

    public void release() {
        stopPolling();
        dismissProgress();
        if (receiverRegistered) {
            try {
                activity.unregisterReceiver(receiver);
            } catch (Exception ignored) {
            }
            receiverRegistered = false;
        }
    }

    private void install(final Uri uri) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                && !activity.getPackageManager().canRequestPackageInstalls()) {
            new AlertDialog.Builder(activity)
                    .setTitle("需要允许安装应用")
                    .setMessage("系统限制未知来源安装，请允许本应用安装应用后再试")
                    .setPositiveButton("去设置", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            try {
                                activity.startActivity(new Intent(
                                        Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                                        Uri.parse("package:" + activity.getPackageName())));
                            } catch (Exception ignored) {
                            }
                        }
                    })
                    .setNegativeButton("取消", null)
                    .show();
            return;
        }
        try {
            Intent it = new Intent(Intent.ACTION_VIEW);
            it.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            it.setDataAndType(uri, "application/vnd.android.package-archive");
            activity.startActivity(it);
        } catch (Exception e) {
            Toast.makeText(activity, "拉起安装界面失败：" + e.getMessage(),
                    Toast.LENGTH_LONG).show();
        }
    }

    /** 与澳门日历完全一致的取源顺序：API → raw+时间戳 → jsDelivr+时间戳 → jsDelivr */
    private static String[] candidates(String url) {
        String ts = String.valueOf(System.currentTimeMillis());
        String api = toApiUrl(url);
        String raw = toRawUrl(url);
        String busted = withTs(url, ts);
        if (api != null && raw != null) {
            return new String[]{api, withTs(raw, ts), busted, url};
        }
        if (api != null) return new String[]{api, busted, url};
        if (raw != null) return new String[]{withTs(raw, ts), busted, url};
        return new String[]{busted, url};
    }

    private static String withTs(String url, String ts) {
        return url + (url.contains("?") ? "&" : "?") + "_=" + ts;
    }

    /** cdn.jsdelivr.net/gh/user/repo@branch/path → api.github.com/repos/user/repo/contents/path?ref=branch */
    private static String toApiUrl(String url) {
        String marker = "cdn.jsdelivr.net/gh/";
        int i = url.indexOf(marker);
        if (i < 0) return null;
        String rest = url.substring(i + marker.length());
        int at = rest.indexOf('@');
        if (at < 0) return null;
        String userRepo = rest.substring(0, at);
        String branchAndPath = rest.substring(at + 1);
        int slash = branchAndPath.indexOf('/');
        if (slash < 0) return null;
        String branch = branchAndPath.substring(0, slash);
        String path = branchAndPath.substring(slash + 1);
        int q = path.indexOf('?');
        if (q >= 0) path = path.substring(0, q);
        return "https://api.github.com/repos/" + userRepo + "/contents/" + path + "?ref=" + branch;
    }

    /** cdn.jsdelivr.net/gh/user/repo@branch/path → raw.githubusercontent.com/user/repo/branch/path */
    private static String toRawUrl(String url) {
        String marker = "cdn.jsdelivr.net/gh/";
        int i = url.indexOf(marker);
        if (i < 0) return null;
        String rest = url.substring(i + marker.length());
        int at = rest.indexOf('@');
        int slash = rest.indexOf('/', at < 0 ? 0 : at);
        if (at < 0 || slash < 0) return null;
        String userRepo = rest.substring(0, at);
        String branch = rest.substring(at + 1, slash);
        String path = rest.substring(slash + 1);
        int q = path.indexOf('?');
        if (q >= 0) path = path.substring(0, q);
        return "https://raw.githubusercontent.com/" + userRepo + "/" + branch + "/" + path;
    }

    private boolean verify(String body, String sigBase64) {
        if (sigBase64 == null || sigBase64.trim().length() == 0) return false;
        try {
            byte[] der = Base64.decode(MANIFEST_PUBKEY, Base64.DEFAULT);
            PublicKey pub = KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(der));
            Signature sig = Signature.getInstance("SHA256withRSA");
            sig.initVerify(pub);
            sig.update(body.getBytes("UTF-8"));
            return sig.verify(Base64.decode(sigBase64.trim(), Base64.DEFAULT));
        } catch (Exception e) {
            return false;
        }
    }

    private String sha256Of(Uri uri) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            InputStream in = activity.getContentResolver().openInputStream(uri);
            if (in == null) return "";
            byte[] buf = new byte[8192];
            int len;
            while ((len = in.read(buf)) != -1) md.update(buf, 0, len);
            in.close();
            byte[] d = md.digest();
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return "";
        }
    }

    private static volatile String lastHttp;

    private static String httpGet(String address, String accept) {
        HttpURLConnection conn = null;
        try {
            URL url = new URL(address);
            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(12000);
            conn.setReadTimeout(18000);
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) IPCalc");
            conn.setRequestProperty("Accept", accept);
            conn.setRequestProperty("Accept-Encoding", "identity");
            int code = conn.getResponseCode();
            if (code != 200) {
                lastHttp = "HTTP " + code;
                return null;
            }
            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(conn.getInputStream(), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) sb.append(line).append('\n');
            reader.close();
            return sb.toString();
        } catch (Exception e) {
            lastHttp = "连接失败（" + e.getClass().getSimpleName() + "）";
            return null;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private int installedVersionCode() {
        try {
            PackageInfo info = activity.getPackageManager().getPackageInfo(
                    activity.getPackageName(), 0);
            return info.versionCode;
        } catch (Exception e) {
            return 0;
        }
    }

    private String installedVersionName() {
        try {
            PackageInfo info = activity.getPackageManager().getPackageInfo(
                    activity.getPackageName(), 0);
            return info.versionName;
        } catch (Exception e) {
            return "";
        }
    }
}
